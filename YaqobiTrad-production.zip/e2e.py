import json,time,urllib.request
BASE="https://api.binance.com"
SYMBOL="BTCUSDT"
INTERVAL="1m"
try:
    url=f"{BASE}/api/v3/klines?symbol={SYMBOL}&interval={INTERVAL}&limit=2"
    req=urllib.request.Request(url,headers={"User-Agent":"YaqobiTrad-Termux-E2E/1.0"})
    with urllib.request.urlopen(req,timeout=10) as r:
        rows=json.loads(r.read().decode())
    now=int(time.time()*1000)
    closed=[x for x in rows if int(x[6])<=now]
    if not closed: raise RuntimeError("no_closed_candle")
    c=closed[-1]
    print(json.dumps({"verified":True,"status":"VERIFIED","provider":"BinancePublicProvider","symbol":SYMBOL,"interval":INTERVAL,"open_time":int(c[0]),"close_time":int(c[6]),"read_only":True,"orders_submitted":False},indent=2))
    print("E2E=VERIFIED")
except Exception as e:
    print(json.dumps({"verified":False,"status":"BLOCKED","reason":f"{type(e).__name__}: {e}","read_only":True,"orders_submitted":False},indent=2))
    print("E2E=BLOCKED")
