"""Fail-closed authentication, RBAC, and secret lifecycle primitives."""
from __future__ import annotations
import hashlib, hmac, secrets
from dataclasses import dataclass

@dataclass(frozen=True)
class Principal:
    subject: str
    roles: frozenset[str]
    token: str

class Authenticator:
    def __init__(self, users: dict[str, tuple[str, set[str]]] | None = None):
        self._users = users or {}
        self._revoked: set[str] = set()

    @staticmethod
    def _hash(password: str, salt: bytes) -> str:
        return hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 120_000).hex()

    def add_user(self, subject: str, password: str, roles: set[str]):
        if not subject or not password or not roles:
            raise ValueError("subject, password and roles are required")
        salt = secrets.token_bytes(16)
        self._users[subject] = (salt.hex() + ":" + self._hash(password, salt), set(roles))

    def authenticate(self, subject: str, password: str) -> Principal:
        rec = self._users.get(subject)
        if not rec:
            raise PermissionError("authentication failed")
        stored, roles = rec
        salt_hex, expected = stored.split(":", 1)
        actual = self._hash(password, bytes.fromhex(salt_hex))
        if not hmac.compare_digest(actual, expected):
            raise PermissionError("authentication failed")
        token = secrets.token_urlsafe(24)
        return Principal(subject, frozenset(roles), token)

    def authorize(self, principal: Principal, required_role: str) -> bool:
        return bool(principal.token) and principal.token not in self._revoked and required_role in principal.roles

    def revoke(self, principal: Principal):
        self._revoked.add(principal.token)

class SecretVault:
    def __init__(self):
        self._secrets: dict[str, tuple[int, str]] = {}
        self._revoked_versions: set[tuple[str, int]] = set()

    def put(self, name: str, value: str) -> int:
        if not name or not value:
            raise ValueError("secret name and value are required")
        version = self._secrets.get(name, (0, ""))[0] + 1
        self._secrets[name] = (version, value)
        return version

    def get(self, name: str) -> str:
        rec = self._secrets.get(name)
        if not rec or (name, rec[0]) in self._revoked_versions:
            raise KeyError("secret unavailable")
        return rec[1]

    def rotate(self, name: str, value: str) -> int:
        return self.put(name, value)

    def revoke(self, name: str, version: int | None = None):
        current = self._secrets.get(name)
        if not current:
            raise KeyError("secret unavailable")
        self._revoked_versions.add((name, version or current[0]))
