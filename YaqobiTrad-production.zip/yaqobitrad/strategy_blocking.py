from dataclasses import dataclass

@dataclass(frozen=True)
class StrategyFinding:
    finding_id: str
    control: str
    status: str
    activation_impact: bool
    rationale: str

STRATEGY_FINDINGS = (
    StrategyFinding(
        "STR-001", "strategy-interface-boundary", "CONTROLLED", False,
        "The baseline keeps strategy concerns separate from risk and execution."
    ),
    StrategyFinding(
        "STR-002", "decision-safety-boundary", "CONTROLLED", False,
        "Execution cannot bypass the activation gate."
    ),
    StrategyFinding(
        "STR-003", "production-strategy-engine", "CONTROLLED", True,
        "Versioned deterministic 1m strategy engine is implemented for paper/backtest use."
    ),
    StrategyFinding(
        "STR-004", "backtest-validation", "CONTROLLED", True,
        "Executable strategy replay validation covers deterministic decision generation."
    ),
    StrategyFinding(
        "STR-005", "parameter-governance", "CONTROLLED", True,
        "Strategy parameters are immutable, versioned and included in decision provenance."
    ),
    StrategyFinding(
        "STR-006", "strategy-regime-validation", "CONTROLLED", True,
        "Executable edge-case validation covers HOLD behavior and deterministic replay."
    ),
)

def strategy_findings():
    return STRATEGY_FINDINGS

def strategy_blocks_activation():
    return any(f.status == "OPEN" and f.activation_impact for f in STRATEGY_FINDINGS)
