"""Audit/observability evidence continuity primitives for YaqobiTrad v2.02.13."""
from __future__ import annotations

import hashlib
import json
from typing import Any

from .audit import AuditLog
from .monitoring import MonitoringState


def record_observation(audit: AuditLog, event: str, data: dict[str, Any] | None = None) -> dict[str, Any]:
    if not event:
        raise ValueError("event is required")
    return audit.append(event, data or {})


def evidence_integrity(audit: AuditLog) -> bool:
    return audit.verify()


def evidence_digest(audit: AuditLog) -> str:
    payload = json.dumps(audit.entries, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(payload).hexdigest()


def observability_release_state(monitoring: MonitoringState, audit: AuditLog) -> dict[str, str]:
    if not monitoring.healthy or not audit.verify():
        return {
            "state": "BLOCKED",
            "live_trading": "SAFE_OFF",
            "activation_gate": "LOCKED",
        }
    return {
        "state": "OBSERVABLE",
        "live_trading": "SAFE_OFF",
        "activation_gate": "LOCKED",
    }
