"""Hash-chained audit log with optional durable atomic persistence."""
from __future__ import annotations
import hashlib, json, os, tempfile, time

class AuditLog:
    def __init__(self, path: str | None = None):
        self.path = path
        self.entries = []
        self.prev_hash = "GENESIS"
        if path and os.path.exists(path):
            self._load()

    @staticmethod
    def _digest(record):
        base = {k: record[k] for k in ("ts", "event", "data", "prev_hash")}
        raw = json.dumps(base, sort_keys=True, separators=(",", ":")).encode()
        return hashlib.sha256(raw).hexdigest()

    def append(self, event, data=None):
        record = {"ts": time.time(), "event": event, "data": data or {}, "prev_hash": self.prev_hash}
        record["hash"] = self._digest(record)
        self.entries.append(record)
        self.prev_hash = record["hash"]
        if self.path:
            self._save()
        return record

    def verify(self):
        prev = "GENESIS"
        for r in self.entries:
            if r.get("prev_hash") != prev or self._digest(r) != r.get("hash"):
                return False
            prev = r["hash"]
        return True

    def completeness(self, required_events):
        if not self.verify():
            return False
        seen = {r.get("event") for r in self.entries}
        return all(event in seen for event in required_events)

    def _save(self):
        directory = os.path.dirname(os.path.abspath(self.path))
        os.makedirs(directory, exist_ok=True)
        payload = {"entries": self.entries, "prev_hash": self.prev_hash}
        fd, tmp = tempfile.mkstemp(prefix=".audit-", dir=directory)
        try:
            with os.fdopen(fd, "w") as f:
                json.dump(payload, f, sort_keys=True, separators=(",", ":"))
                f.flush(); os.fsync(f.fileno())
            os.replace(tmp, self.path)
        finally:
            if os.path.exists(tmp): os.unlink(tmp)

    def _load(self):
        with open(self.path) as f:
            payload = json.load(f)
        self.entries = list(payload["entries"])
        self.prev_hash = payload.get("prev_hash", self.entries[-1]["hash"] if self.entries else "GENESIS")
        if not self.verify() or (self.entries and self.prev_hash != self.entries[-1]["hash"]):
            raise ValueError("audit ledger integrity failure")
