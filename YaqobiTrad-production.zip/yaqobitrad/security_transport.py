"""Durable local security-evidence export with integrity manifest.

This is a local deployment primitive; it does not claim remote/production
transport or immutable third-party retention.
"""
from __future__ import annotations
import hashlib, json, os, tempfile
from pathlib import Path
from .audit import AuditLog
from .security_evidence import security_evidence_digest


def export_security_evidence(audit: AuditLog, directory: str, bundle_id: str) -> Path:
    if not bundle_id or not audit.verify():
        raise ValueError("valid bundle_id and intact audit evidence required")
    root = Path(directory)
    root.mkdir(parents=True, exist_ok=True)
    target = root / f"{bundle_id}.json"
    payload = {"bundle_id": bundle_id, "entries": audit.entries,
               "evidence_digest": security_evidence_digest(audit)}
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    fd, tmp = tempfile.mkstemp(prefix=f".{bundle_id}-", dir=root)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(raw); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, target)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)
    digest = hashlib.sha256(raw).hexdigest()
    manifest = root / f"{bundle_id}.manifest.json"
    manifest.write_text(json.dumps({"bundle_id": bundle_id, "sha256": digest,
                                    "evidence_digest": payload["evidence_digest"]},
                                   sort_keys=True, separators=(",", ":")))
    return target


def verify_security_export(path: str) -> bool:
    p = Path(path)
    m = p.with_name(p.stem + ".manifest.json")
    if not p.exists() or not m.exists():
        return False
    try:
        payload = json.loads(p.read_bytes())
        manifest = json.loads(m.read_text())
    except (OSError, ValueError, TypeError):
        return False
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return (manifest.get("sha256") == hashlib.sha256(raw).hexdigest()
            and manifest.get("evidence_digest") == payload.get("evidence_digest"))
