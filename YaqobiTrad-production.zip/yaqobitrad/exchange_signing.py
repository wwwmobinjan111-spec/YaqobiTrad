import hashlib
import hmac
from urllib.parse import urlencode


def build_signed_query(params: dict, api_secret: str) -> tuple[str, str]:
    if not api_secret:
        raise ValueError("API_SECRET_REQUIRED")

    query_string = urlencode(params)
    signature = hmac.new(
        api_secret.encode("utf-8"),
        query_string.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

    return query_string, signature


def build_headers(api_key: str) -> dict:
    if not api_key:
        raise ValueError("API_KEY_REQUIRED")
    return {"X-MBX-APIKEY": api_key}
