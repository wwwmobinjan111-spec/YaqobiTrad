from dataclasses import dataclass
from time import time

@dataclass
class RiskLimits:
    max_order_value: float = 1000.0
    max_position_value: float = 5000.0
    max_portfolio_exposure: float = 5000.0
    max_drawdown_pct: float = 20.0
    max_orders_per_window: int = 5
    frequency_window_seconds: float = 60.0

class RiskEngine:
    def __init__(self, limits=None):
        self.limits = limits or RiskLimits()
        self._order_times = []
        self._circuit_breaker = False

    def set_circuit_breaker(self, tripped: bool) -> None:
        self._circuit_breaker = bool(tripped)

    def circuit_breaker_active(self) -> bool:
        return self._circuit_breaker

    def record_order(self, now=None) -> None:
        ts = time() if now is None else float(now)
        self._order_times.append(ts)
        self._prune_frequency(ts)

    def _prune_frequency(self, now: float) -> None:
        cutoff = now - self.limits.frequency_window_seconds
        self._order_times = [ts for ts in self._order_times if ts >= cutoff]

    def approve(
        self,
        order_value,
        current_position_value=0.0,
        portfolio_exposure=0.0,
        drawdown_pct=0.0,
        now=None,
    ):
        if self._circuit_breaker:
            return False, "CIRCUIT_BREAKER"
        if order_value <= 0:
            return False, "INVALID_ORDER_VALUE"
        if order_value > self.limits.max_order_value:
            return False, "ORDER_LIMIT"
        if current_position_value + order_value > self.limits.max_position_value:
            return False, "POSITION_LIMIT"
        if portfolio_exposure + order_value > self.limits.max_portfolio_exposure:
            return False, "EXPOSURE_LIMIT"
        if drawdown_pct > self.limits.max_drawdown_pct:
            return False, "DRAWDOWN_LIMIT"
        ts = time() if now is None else float(now)
        self._prune_frequency(ts)
        if len(self._order_times) >= self.limits.max_orders_per_window:
            return False, "FREQUENCY_LIMIT"
        return True, "APPROVED"
