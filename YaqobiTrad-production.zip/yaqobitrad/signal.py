"""Deterministic 1-minute signal engine; no live execution side effects."""
from __future__ import annotations
from dataclasses import dataclass
from math import inf
from .market import Candle, validate_candle

@dataclass(frozen=True)
class Signal:
    symbol: str
    close_time: int
    action: str
    price: float
    ema_fast: float
    ema_slow: float
    rsi: float
    atr: float
    provenance: str


def _ema(values, period):
    if not values: return 0.0
    k = 2.0 / (period + 1)
    e = float(values[0])
    for x in values[1:]: e = float(x) * k + e * (1-k)
    return e


def _rsi(values, period=14):
    if len(values) < 2: return 50.0
    gains=[]; losses=[]
    for a,b in zip(values[:-1], values[1:]):
        d=b-a; gains.append(max(d,0.0)); losses.append(max(-d,0.0))
    g=sum(gains[-period:])/min(period,len(gains)); l=sum(losses[-period:])/min(period,len(losses))
    if l == 0: return 100.0 if g > 0 else 50.0
    return 100.0 - 100.0/(1.0 + g/l)


def _atr(candles, period=14):
    if len(candles) < 2: return 0.0
    trs=[]
    for prev,c in zip(candles[:-1], candles[1:]):
        trs.append(max(c.high-c.low, abs(c.high-prev.close), abs(c.low-prev.close)))
    return sum(trs[-period:])/min(period,len(trs))

class SignalEngine:
    def __init__(self, fast=9, slow=21, rsi_period=14, atr_period=14):
        if not (0 < fast < slow): raise ValueError("fast/slow periods invalid")
        self.fast, self.slow = int(fast), int(slow)
        self.rsi_period, self.atr_period = int(rsi_period), int(atr_period)

    def evaluate(self, symbol: str, candles: list[Candle]) -> Signal:
        if len(candles) < self.slow: raise ValueError("INSUFFICIENT_CANDLES")
        for c in candles:
            ok, reason = validate_candle(c)
            if not ok: raise ValueError(reason)
        closes=[c.close for c in candles]
        ema_fast=_ema(closes[-self.slow:], self.fast)
        ema_slow=_ema(closes[-self.slow:], self.slow)
        rsi=_rsi(closes, self.rsi_period); atr=_atr(candles, self.atr_period)
        if ema_fast > ema_slow and rsi >= 50: action="BUY"
        elif ema_fast < ema_slow and rsi <= 50: action="SELL"
        else: action="HOLD"
        c=candles[-1]
        provenance=f"signal:v1|symbol={symbol.upper()}|close_time={c.close_time}|source=validated_closed_candles"
        return Signal(symbol.upper(), c.close_time, action, c.close, ema_fast, ema_slow, rsi, atr, provenance)
