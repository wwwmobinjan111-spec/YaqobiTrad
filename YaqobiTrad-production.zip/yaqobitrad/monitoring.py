"""Minimal fail-closed observability primitives for YaqobiTrad v2.02.12."""
from dataclasses import dataclass, field
from time import time

@dataclass
class MonitoringState:
    healthy: bool = True
    last_heartbeat: float | None = None
    metrics: dict[str, float] = field(default_factory=dict)
    alerts: list[str] = field(default_factory=list)

    def heartbeat(self, now: float | None = None) -> None:
        self.last_heartbeat = time() if now is None else now
        self.healthy = True

    def metric(self, name: str, value: float) -> None:
        if not name:
            raise ValueError("metric name is required")
        self.metrics[name] = float(value)

    def alert(self, message: str) -> None:
        if not message:
            raise ValueError("alert message is required")
        self.alerts.append(message)
        self.healthy = False

    def stale(self, now: float, max_age: float) -> bool:
        if max_age < 0:
            raise ValueError("max_age must be non-negative")
        if self.last_heartbeat is None or now - self.last_heartbeat > max_age:
            self.healthy = False
            return True
        return False

    def fail_closed_action(self) -> dict[str, str]:
        return {
            "action": "SHUTDOWN",
            "live_trading": "SAFE_OFF",
            "activation_gate": "LOCKED",
        }

def monitoring_inventory() -> dict[str, object]:
    return {
        "controlled": [
            "structured_logging",
            "health_readiness",
            "metrics",
            "alerting",
            "heartbeat_freshness",
            "fail_closed_monitoring",
            "audit_traceability",
        ],
        "activation_blockers": [
            "production telemetry backend",
            "production alert routing",
            "retention and immutable evidence policy",
            "external incident notification integration",
        ],
    }
