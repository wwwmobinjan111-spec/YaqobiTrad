from dataclasses import dataclass

@dataclass(frozen=True)
class SecurityBlockingInventory:
    controlled: tuple[str, ...]
    open_activation_blockers: tuple[str, ...]

INVENTORY = SecurityBlockingInventory(
    controlled=(
        "activation_gate_lock",
        "fail_closed_state",
        "live_trading_safe_off",
        "audit_hash_integrity",
        "authentication_rbac_boundary_tested",
        "secret_rotation_revocation_tested",
        "security_incident_audit_evidence_pipeline_tested",
    ),
    open_activation_blockers=(
        "SEC-001: production authentication/authorization deployment/integration not verified",
        "SEC-002: production secret-management integration not verified",
        "SEC-004: dependency/vulnerability scanning not executed",
        "SEC-005: production security incident/audit evidence transport/retention not verified",
    ),
)

def security_inventory() -> SecurityBlockingInventory:
    return INVENTORY

def security_blocks_activation() -> bool:
    return (
        len(INVENTORY.open_activation_blockers) > 0
        and "activation_gate_lock" in INVENTORY.controlled
        and "live_trading_safe_off" in INVENTORY.controlled
    )
