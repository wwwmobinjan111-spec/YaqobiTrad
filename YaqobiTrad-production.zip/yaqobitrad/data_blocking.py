from dataclasses import dataclass

@dataclass(frozen=True)
class DataFinding:
    finding_id: str
    control: str
    status: str
    activation_impact: bool
    rationale: str

DATA_FINDINGS = (
    DataFinding("DATA-001", "closed-candle", "CONTROLLED", False,
                "Open candles are rejected by market validation."),
    DataFinding("DATA-002", "ohlcv-integrity", "CONTROLLED", False,
                "Invalid OHLCV relationships are rejected."),
    DataFinding("DATA-003", "volume-integrity", "CONTROLLED", False,
                "Non-positive volume is rejected."),
    DataFinding("DATA-004", "provider-freshness", "OPEN", True,
                "No real provider freshness/continuity monitor exists in the reconstructed baseline."),
    DataFinding("DATA-005", "persistence-recovery", "OPEN", True,
                "No production-grade persistent market-data recovery path is included."),
)

def data_findings():
    return DATA_FINDINGS

def data_blocks_activation():
    return any(f.status == "OPEN" and f.activation_impact for f in DATA_FINDINGS)
