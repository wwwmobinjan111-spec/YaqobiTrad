from __future__ import annotations

from .order_provider import BinanceOrderProvider


def order_provider_e2e_check() -> dict[str, object]:
    """
    Verification boundary for the production order provider.

    This intentionally does NOT submit a real order.
    Until an independently executed production-order verification
    exists, the gate remains fail-closed.
    """
    provider = BinanceOrderProvider(live_enabled=False)

    result = provider.submit_order(
        symbol="BTCUSDT",
        side="BUY",
        quantity=0.001,
        price=100000.0,
        client_order_id="verification-only",
    )

    return {
        "verified": False,
        "status": "BLOCKED",
        "reason": result.reason or "LIVE_ORDER_PROVIDER_NOT_VERIFIED",
    }


def order_provider_blocks_activation() -> bool:
    return not bool(order_provider_e2e_check().get("verified"))
