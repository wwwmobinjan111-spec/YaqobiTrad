from http.server import BaseHTTPRequestHandler, HTTPServer
import threading, json

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/auth/health":
            body = {"service":"auth","status":"healthy"}
        elif self.path == "/secret/health":
            body = {"service":"secret","status":"healthy"}
        else:
            body = {"status":"not_found"}
        data = json.dumps(body).encode()
        self.send_response(200 if "healthy" in body.get("status","") else 404)
        self.send_header("Content-Type","application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *args):
        pass

server = HTTPServer(("127.0.0.1", 8765), Handler)
threading.Thread(target=server.serve_forever, daemon=True).start()

import urllib.request
for path in ("/auth/health", "/secret/health"):
    r = urllib.request.urlopen("http://127.0.0.1:8765"+path)
    print(path, r.status, r.read().decode())

server.shutdown()
