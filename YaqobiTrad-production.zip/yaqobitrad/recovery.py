import hashlib
import json
from dataclasses import dataclass


@dataclass(frozen=True)
class RecoveryCheckpoint:
    sequence: int
    state: dict
    digest: str


def _digest(sequence: int, state: dict) -> str:
    payload = json.dumps({"sequence": sequence, "state": state}, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode()).hexdigest()


def create_checkpoint(sequence: int, state: dict) -> RecoveryCheckpoint:
    if sequence < 0:
        raise ValueError("sequence must be non-negative")
    if not isinstance(state, dict):
        raise TypeError("state must be a dict")
    frozen = dict(state)
    return RecoveryCheckpoint(sequence, frozen, _digest(sequence, frozen))


def restore_checkpoint(checkpoint: RecoveryCheckpoint, *, expected_sequence: int | None = None) -> dict:
    if not isinstance(checkpoint, RecoveryCheckpoint):
        raise TypeError("invalid checkpoint")
    if expected_sequence is not None and checkpoint.sequence != expected_sequence:
        raise ValueError("checkpoint sequence mismatch")
    if _digest(checkpoint.sequence, checkpoint.state) != checkpoint.digest:
        raise ValueError("checkpoint integrity failure")
    restored = dict(checkpoint.state)
    restored["live_trading"] = "SAFE_OFF"
    restored["activation_gate"] = "LOCKED"
    return restored
