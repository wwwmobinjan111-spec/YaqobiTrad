from __future__ import annotations

import json
import os
import time
from typing import Any


class EventJournal:
    """Durable append-only operational journal for the Paper AutoTrader."""

    def __init__(self, path: str):
        self.path = path

    def record(self, event: str, **data: Any) -> dict[str, Any]:
        entry = {
            "timestamp": time.time(),
            "event": event,
            **data,
        }

        directory = os.path.dirname(self.path)
        if directory:
            os.makedirs(directory, exist_ok=True)

        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, sort_keys=True) + "\n")
            f.flush()
            os.fsync(f.fileno())

        return entry

    def read(self) -> list[dict[str, Any]]:
        if not os.path.exists(self.path):
            return []

        events = []
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    events.append(json.loads(line))

        return events
