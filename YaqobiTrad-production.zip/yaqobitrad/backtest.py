from dataclasses import dataclass
from .strategy import StrategyEngine

@dataclass
class BacktestResult:
    initial_balance: float
    final_balance: float
    net_pnl: float
    return_pct: float
    fees: float
    trades: int
    wins: int
    losses: int
    win_rate: float
    profit_factor: float
    max_drawdown_pct: float

class BacktestEngine:
    def __init__(self, initial_balance=1000.0, fee_rate=0.001):
        self.initial_balance=float(initial_balance)
        self.fee_rate=float(fee_rate)
        self.strategy=StrategyEngine()

    def run(self,symbol,candles,quantity=0.001):
        balance=self.initial_balance
        position=0.0
        entry=0.0
        fees=0.0
        trades=wins=losses=0
        gross_profit=gross_loss=0.0
        peak=balance
        max_dd=0.0

        decisions=self.strategy.replay(symbol,candles)

        for d in decisions:
            price=float(d.price)

            if d.action=="BUY" and position==0:
                cost=quantity*price
                fee=cost*self.fee_rate
                if balance>=cost+fee:
                    balance-=cost+fee
                    fees+=fee
                    position=quantity
                    entry=price

            elif d.action=="SELL" and position>0:
                proceeds=position*price
                fee=proceeds*self.fee_rate
                pnl=(price-entry)*position-fee
                balance+=proceeds-fee
                fees+=fee
                trades+=1
                if pnl>=0:
                    wins+=1
                    gross_profit+=pnl
                else:
                    losses+=1
                    gross_loss+=abs(pnl)
                position=0.0
                entry=0.0

            equity=balance+position*price
            peak=max(peak,equity)
            max_dd=max(max_dd,((peak-equity)/peak*100) if peak else 0)

        if position>0 and decisions:
            price=float(decisions[-1].price)
            proceeds=position*price
            fee=proceeds*self.fee_rate
            pnl=(price-entry)*position-fee
            balance+=proceeds-fee
            fees+=fee
            trades+=1
            if pnl>=0:
                wins+=1
                gross_profit+=pnl
            else:
                losses+=1
                gross_loss+=abs(pnl)

        net_pnl=balance-self.initial_balance

        return BacktestResult(
            self.initial_balance,balance,net_pnl,
            net_pnl/self.initial_balance*100,
            fees,trades,wins,losses,
            wins/trades*100 if trades else 0.0,
            gross_profit/gross_loss if gross_loss else (
                float("inf") if gross_profit else 0.0
            ),
            max_dd
        )
