from dataclasses import dataclass
from typing import Literal

Status = Literal["OPEN", "CONTROLLED"]

@dataclass(frozen=True)
class ArchitectureFinding:
    finding_id: str
    component: str
    status: Status
    activation_impact: bool
    rationale: str

ARCHITECTURE_FINDINGS = (
    ArchitectureFinding(
        "ARCH-001", "configuration", "CONTROLLED", False,
        "Safety defaults are explicit and testable."
    ),
    ArchitectureFinding(
        "ARCH-002", "market-validation", "CONTROLLED", False,
        "Closed-candle and OHLCV validation are implemented."
    ),
    ArchitectureFinding(
        "ARCH-003", "risk", "CONTROLLED", False,
        "Order, position, exposure, drawdown and frequency controls are implemented."
    ),
    ArchitectureFinding(
        "ARCH-004", "execution", "CONTROLLED", False,
        "Paper execution, idempotency and reconciliation are implemented; live execution remains blocked."
    ),
    ArchitectureFinding(
        "ARCH-005", "fail-closed", "CONTROLLED", False,
        "Failure handling keeps live trading disabled and activation locked."
    ),
    ArchitectureFinding(
        "ARCH-006", "audit", "CONTROLLED", False,
        "Audit records use chained SHA-256 hashes with integrity verification."
    ),
    ArchitectureFinding(
        "ARCH-007", "production-integration", "OPEN", True,
        "Provider, signal, strategy and persistent portfolio components are implemented and exercised; live exchange submission remains independently blocked."
    ),
)

def architecture_findings() -> tuple[ArchitectureFinding, ...]:
    return ARCHITECTURE_FINDINGS

def activation_impacting_findings() -> tuple[ArchitectureFinding, ...]:
    return tuple(
        f for f in ARCHITECTURE_FINDINGS
        if f.activation_impact and f.status == "OPEN"
    )

def architecture_blocks_activation() -> bool:
    return bool(activation_impacting_findings())
