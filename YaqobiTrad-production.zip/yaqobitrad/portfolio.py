"""Durable paper portfolio ledger with hash-chained journal and reconciliation."""
from __future__ import annotations
import hashlib, json, os, tempfile
from dataclasses import dataclass, asdict

@dataclass(frozen=True)
class LedgerEntry:
    sequence: int
    event: str
    balance: float
    positions: dict
    previous_digest: str
    digest: str

def _digest(seq, event, balance, positions, previous):
    payload=json.dumps({"sequence":seq,"event":event,"balance":balance,"positions":positions,"previous_digest":previous},sort_keys=True,separators=(",",":"))
    return hashlib.sha256(payload.encode()).hexdigest()

class DurablePortfolio:
    def __init__(self, path: str, balance: float = 0.0):
        self.path=path
        self.balance=float(balance)
        self.positions={}
        self.entries=[]
        if os.path.exists(path): self._load()

    def append(self, event: str, balance: float, positions: dict):
        seq=len(self.entries)+1
        prev=self.entries[-1].digest if self.entries else ""
        positions=dict(positions)
        digest=_digest(seq,event,float(balance),positions,prev)
        entry=LedgerEntry(seq,event,float(balance),positions,prev,digest)
        self.entries.append(entry); self.balance=entry.balance; self.positions=dict(entry.positions)
        self._save(); return entry

    def reconcile(self):
        prev=""
        for expected,e in enumerate(self.entries,1):
            if e.sequence!=expected or e.previous_digest!=prev: return False
            if _digest(e.sequence,e.event,e.balance,e.positions,e.previous_digest)!=e.digest: return False
            prev=e.digest
        if self.entries:
            last=self.entries[-1]
            return self.balance==last.balance and self.positions==last.positions
        return True

    def _save(self):
        os.makedirs(os.path.dirname(os.path.abspath(self.path)),exist_ok=True)
        data={"balance":self.balance,"positions":self.positions,"entries":[asdict(e) for e in self.entries]}
        fd,tmp=tempfile.mkstemp(prefix=".portfolio-",dir=os.path.dirname(os.path.abspath(self.path)))
        try:
            with os.fdopen(fd,"w") as f: json.dump(data,f,sort_keys=True,separators=(",",":")); f.flush(); os.fsync(f.fileno())
            os.replace(tmp,self.path)
        finally:
            if os.path.exists(tmp): os.unlink(tmp)

    def _load(self):
        with open(self.path) as f: data=json.load(f)
        self.balance=float(data["balance"]); self.positions=dict(data["positions"])
        self.entries=[LedgerEntry(**e) for e in data["entries"]]
        if not self.reconcile(): raise ValueError("portfolio ledger integrity/reconciliation failure")
