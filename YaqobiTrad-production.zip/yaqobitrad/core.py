from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from .config import LIVE_TRADING, ACTIVATION_GATE, FAIL_CLOSED
from .provider import BinancePublicProvider
from .strategy import StrategyEngine
from .risk import RiskEngine
from .execution import ExecutionEngine
from .portfolio import DurablePortfolio
from .monitoring import MonitoringState


@dataclass
class CoreCycleResult:
    symbol: str
    action: str
    price: float
    strategy_version: str
    risk_approved: bool
    execution: dict[str, Any]
    portfolio_balance: float
    portfolio_positions: dict[str, float]
    monitoring: dict[str, Any]
    safety: dict[str, Any]
    provenance: str = ""


class YaqobiTradCore:
    """
    Central orchestration layer for the 1-minute paper-trading pipeline.

    Live trading is intentionally unavailable here:
    LIVE_TRADING must remain SAFE_OFF and the activation gate LOCKED.
    """

    def __init__(
        self,
        portfolio_path: str,
        initial_balance: float = 1000.0,
        provider: BinancePublicProvider | None = None,
        strategy: StrategyEngine | None = None,
        risk: RiskEngine | None = None,
        execution=None,
        monitoring: MonitoringState | None = None,
    ):
        self.provider = provider or BinancePublicProvider()
        self.strategy = strategy or StrategyEngine()
        self.risk = risk or RiskEngine()

        if execution is None:
            self.execution = ExecutionEngine(self.risk)
        else:
            self.execution = execution

        self.portfolio = DurablePortfolio(
            portfolio_path,
            balance=initial_balance,
        )

        self.monitoring = monitoring or MonitoringState()

    def safety_state(self) -> dict[str, Any]:
        # Central fail-closed safety boundary.
        # Any unsafe/unknown state is represented as unsafe.
        live_safe = LIVE_TRADING is False
        gate_locked = ACTIVATION_GATE == "LOCKED"
        fail_closed_active = FAIL_CLOSED is True

        return {
            "live_trading": "SAFE_OFF" if live_safe else "LIVE",
            "activation_gate": "LOCKED" if gate_locked else str(ACTIVATION_GATE),
            "fail_closed": "ACTIVE" if fail_closed_active else "INACTIVE",
        }

    def _enforce_safety_guard(self) -> dict[str, Any]:
        safety = self.safety_state()

        if safety["live_trading"] != "SAFE_OFF":
            raise RuntimeError("SAFETY_BLOCK_LIVE_TRADING")

        if safety["activation_gate"] != "LOCKED":
            raise RuntimeError("SAFETY_BLOCK_ACTIVATION_GATE")

        if safety["fail_closed"] != "ACTIVE":
            raise RuntimeError("SAFETY_BLOCK_FAIL_CLOSED")

        return safety

    def _load_closed_candles(self, symbol: str, count: int = 24):
        """
        Obtain real closed 1m candle history through the read-only provider.
        """
        if not hasattr(self.provider, "fetch_closed_candles"):
            raise RuntimeError("PROVIDER_HISTORY_UNAVAILABLE")

        candles = self.provider.fetch_closed_candles(
            symbol,
            interval="1m",
            limit=count,
        )

        if len(candles) < 21:
            raise RuntimeError("INSUFFICIENT_CLOSED_1M_CANDLES")

        return candles

    def cycle(
        self,
        symbol: str,
        quantity: float = 0.001,
        client_order_id: str | None = None,
    ) -> CoreCycleResult:

        started = time.time()
        self.monitoring.heartbeat(started)

        safety = self._enforce_safety_guard()

        candles = self._load_closed_candles(symbol)

        if len(candles) < 21:
            raise RuntimeError("INSUFFICIENT_CLOSED_1M_CANDLES")

        decision = self.strategy.decide(symbol, candles)

        action = getattr(decision, "action", "HOLD")
        price = float(getattr(decision, "price", candles[-1].close))
        provenance = str(getattr(decision, "provenance", ""))
        version = "unknown"
        if "strategy:" in provenance:
            version = provenance.split("strategy:", 1)[1].split("|", 1)[0]

        order_value = abs(quantity * price)

        current_position = float(self.portfolio.positions.get(symbol, 0.0))

        # Prevent accumulating in the same direction.
        if action.upper() == "SELL" and current_position < 0:
            approval = (False, "POSITION_DIRECTION_LIMIT")
        elif action.upper() == "BUY" and current_position > 0:
            approval = (False, "POSITION_DIRECTION_LIMIT")
        else:
            approval = self.risk.approve(
                order_value=order_value,
                current_position_value=abs(
                    float(self.portfolio.positions.get(symbol, 0.0)) * price
                ),
                portfolio_exposure=abs(
                    float(self.portfolio.positions.get(symbol, 0.0)) * price
                ),
                drawdown_pct=0.0,
            )

        if isinstance(approval, tuple):
            approved, approval_reason = approval
        else:
            approved = bool(getattr(approval, "approved", approval))
            approval_reason = getattr(approval, "reason", "RISK_REJECTED")

        if not approved or action == "HOLD":
            execution = {
                "status": "PAPER_NOT_SUBMITTED",
                "reason": (
                    approval_reason
                    if not approved
                    else "STRATEGY_HOLD"
                ),
            }
        else:
            side = action.upper()

            order_value = float(quantity) * float(price)

            if side == "BUY" and order_value > float(self.portfolio.balance):
                execution = {
                    "status": "BLOCKED",
                    "reason": "INSUFFICIENT_BALANCE",
                }
            else:
                execution = self.execution.paper_submit(
                    side=side,
                    quantity=quantity,
                    price=price,
                    client_order_id=client_order_id,
                )

            # Persist a PAPER fill into the durable portfolio ledger.
            if execution.get("status") == "PAPER_FILLED" and not (side == "BUY" and quantity * price > self.portfolio.balance):
                signed_quantity = (
                    quantity if side == "BUY" else -quantity
                )

                current_position = float(
                    self.portfolio.positions.get(symbol, 0.0)
                )

                new_position = current_position + signed_quantity
                new_balance = float(
                    self.portfolio.balance - (signed_quantity * price)
                )

                self.portfolio.append(
                    event=f"PAPER_FILL:{side}",
                    balance=new_balance,
                    positions={
                        **self.portfolio.positions,
                        symbol: new_position,
                    },
                )

                execution["portfolio_recorded"] = True
                execution["portfolio_sequence"] = (
                    self.portfolio.entries[-1].sequence
                )

        self.monitoring.metric(
            "core_cycle_seconds",
            time.time() - started,
        )

        return CoreCycleResult(
            symbol=symbol,
            action=action,
            price=price,
            strategy_version=version,
            risk_approved=approved,
            execution=execution,
            portfolio_balance=self.portfolio.balance,
            portfolio_positions=dict(self.portfolio.positions),
            monitoring={
                "healthy": self.monitoring.healthy,
                "alerts": list(self.monitoring.alerts),
                "metrics": dict(self.monitoring.metrics),
            },
            safety=safety,
            provenance=provenance,
        )
