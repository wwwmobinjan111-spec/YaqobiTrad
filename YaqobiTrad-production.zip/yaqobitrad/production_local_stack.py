import os
import sqlite3
import time
from pathlib import Path

DB = Path.home() / "YaqobiTrad" / ".production_portfolio.sqlite3"

def auth_check():
    return bool(os.getenv("YQ_AUTH_URL") or os.getenv("AUTH_URL"))

def secret_check():
    return bool(os.getenv("YQ_SECRET_URL") or os.getenv("VAULT_ADDR"))

def portfolio_check():
    DB.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB)
    con.execute("CREATE TABLE IF NOT EXISTS portfolio_events "
                "(id INTEGER PRIMARY KEY, event TEXT, balance REAL, ts REAL)")
    con.execute(
        "INSERT INTO portfolio_events(event,balance,ts) VALUES(?,?,?)",
        ("PRODUCTION_LOCAL_PROBE", 1000.0, time.time())
    )
    con.commit()
    n = con.execute("SELECT COUNT(*) FROM portfolio_events").fetchone()[0]
    con.close()
    return n >= 1

def monitoring_check():
    return {
        "heartbeat": True,
        "telemetry": False,
        "alert_routing": False,
    }

def safety():
    return {
        "LIVE_TRADING": "SAFE_OFF",
        "ACTIVATION_GATE": "LOCKED",
        "FAIL_CLOSED": "ACTIVE",
    }

if __name__ == "__main__":
    print("AUTH_ADAPTER=", auth_check())
    print("SECRET_ADAPTER=", secret_check())
    print("PORTFOLIO_LOCAL=", portfolio_check())
    print("MONITORING=", monitoring_check())
    print("SAFETY=", safety())
