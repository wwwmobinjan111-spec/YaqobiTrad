"""Security incident/evidence pipeline primitives.

These primitives create tamper-evident incident records in the existing audit
log. They are local application controls; production transport/retention is
still a deployment concern.
"""
from __future__ import annotations

from typing import Any
from .audit import AuditLog


def record_security_incident(audit: AuditLog, incident_id: str, severity: str, event: str,
                             data: dict[str, Any] | None = None) -> dict[str, Any]:
    if not incident_id or not severity or not event:
        raise ValueError("incident_id, severity and event are required")
    return audit.append("SECURITY_INCIDENT", {
        "incident_id": incident_id,
        "severity": severity,
        "event": event,
        "data": data or {},
    })


def verify_security_evidence(audit: AuditLog) -> bool:
    return audit.verify()


def security_evidence_digest(audit: AuditLog) -> str:
    import hashlib, json
    payload = json.dumps(audit.entries, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(payload).hexdigest()
