from __future__ import annotations

from dataclasses import dataclass
from time import time
from typing import Protocol


@dataclass(frozen=True)
class OrderResult:
    status: str
    client_order_id: str | None = None
    exchange_order_id: str | None = None
    reason: str | None = None


class OrderProvider(Protocol):
    def submit_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
        price: float,
        client_order_id: str,
    ) -> OrderResult: ...


class BinanceOrderProvider:
    """
    Production order-provider boundary.

    Fail-closed by default.
    No live submission is permitted unless explicitly enabled
    by a future verified production configuration.
    """

    def __init__(
        self,
        api_key: str | None = None,
        api_secret: str | None = None,
        base_url: str = "https://api.binance.com",
        live_enabled: bool = False,
    ):
        self.api_key = api_key
        self.api_secret = api_secret
        self.base_url = base_url.rstrip("/")
        self.live_enabled = bool(live_enabled)

    def submit_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
        price: float,
        client_order_id: str,
    ) -> OrderResult:
        if not self.live_enabled:
            return OrderResult(
                status="BLOCKED",
                client_order_id=client_order_id,
                reason="LIVE_TRADING_SAFE_OFF",
            )

        if not self.api_key or not self.api_secret:
            return OrderResult(
                status="BLOCKED",
                client_order_id=client_order_id,
                reason="PROVIDER_CREDENTIALS_UNAVAILABLE",
            )

        if not symbol or side not in {"BUY", "SELL"}:
            return OrderResult(
                status="BLOCKED",
                client_order_id=client_order_id,
                reason="INVALID_ORDER",
            )

        if quantity <= 0 or price <= 0:
            return OrderResult(
                status="BLOCKED",
                client_order_id=client_order_id,
                reason="INVALID_ORDER",
            )

        # Real exchange submission intentionally remains disabled
        # until production authentication, signing, execution,
        # reconciliation and recovery are independently verified.
        return OrderResult(
            status="BLOCKED",
            client_order_id=client_order_id,
            reason="LIVE_PROVIDER_ADAPTER_NOT_VERIFIED",
        )
