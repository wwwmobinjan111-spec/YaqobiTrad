from dataclasses import dataclass

@dataclass(frozen=True)
class Candle:
    open_time: int
    close_time: int
    open: float
    high: float
    low: float
    close: float
    volume: float
    closed: bool

def validate_candle(c):
    if not c.closed:
        return False, "CANDLE_NOT_CLOSED"
    if min(c.open, c.high, c.low, c.close, c.volume) < 0:
        return False, "NEGATIVE_VALUE"
    if c.high < max(c.open, c.close, c.low):
        return False, "HIGH_INVALID"
    if c.low > min(c.open, c.close, c.high):
        return False, "LOW_INVALID"
    if c.close_time <= c.open_time:
        return False, "TIME_INVALID"
    return True, "VALID"
