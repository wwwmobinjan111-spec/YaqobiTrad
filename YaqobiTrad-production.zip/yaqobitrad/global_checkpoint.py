from dataclasses import dataclass

@dataclass(frozen=True)
class GlobalCheckpoint:
    checkpoint: str
    tested_domains: tuple[str, ...]
    open_blocker_count: int
    activation_gate: str
    fail_closed: str
    live_trading: str
    certification: str

CHECKPOINT = GlobalCheckpoint(
    checkpoint="v2.02.30",
    tested_domains=(
        "source", "architecture", "data", "signal", "strategy", "risk",
        "execution", "portfolio", "audit", "security", "dependencies",
        "evidence_retention",
    ),
    # Current unique activation blockers: historical-source equivalence,
    # external-provider E2E, production auth, production secret management,
    # dependency/vulnerability verification, and production evidence retention.
    open_blocker_count=1,
    activation_gate="LOCKED",
    fail_closed="ACTIVE",
    live_trading="SAFE_OFF",
    certification="PENDING_REAL_PRODUCTION_RESULTS",
)

def global_checkpoint() -> GlobalCheckpoint:
    return CHECKPOINT

def checkpoint_is_fail_closed() -> bool:
    return (
        CHECKPOINT.open_blocker_count > 0
        and CHECKPOINT.activation_gate == "LOCKED"
        and CHECKPOINT.fail_closed == "ACTIVE"
        and CHECKPOINT.live_trading == "SAFE_OFF"
    )
