from __future__ import annotations

import time
from typing import Any

from .autotrader import AutoTraderLoop


class AutoTraderScheduler:
    """
    1-minute Paper AutoTrader scheduler.

    Safety:
      LIVE_TRADING = SAFE_OFF
      ACTIVATION_GATE = LOCKED
      FAIL_CLOSED = ACTIVE
    """

    def __init__(
        self,
        trader: AutoTraderLoop,
        interval_seconds: int = 60,
    ):
        if interval_seconds < 1:
            raise ValueError("INVALID_INTERVAL")

        self.trader = trader
        self.interval_seconds = interval_seconds
        self.running = False
        self.paused = False

    def safety_check(self) -> dict[str, Any]:
        safety = self.trader.core.safety_state()

        if safety["live_trading"] != "SAFE_OFF":
            raise RuntimeError("SCHEDULER_BLOCK_LIVE_TRADING")

        if safety["activation_gate"] != "LOCKED":
            raise RuntimeError("SCHEDULER_BLOCK_ACTIVATION_GATE")

        if safety["fail_closed"] != "ACTIVE":
            raise RuntimeError("SCHEDULER_BLOCK_FAIL_CLOSED")

        return safety

    def start(self) -> dict[str, Any]:
        safety = self.safety_check()

        self.trader.start()
        self.running = True
        self.paused = False

        return {
            "scheduler": "RUNNING",
            "interval_seconds": self.interval_seconds,
            "safety": safety,
        }

    def pause(self) -> dict[str, Any]:
        if not self.running:
            raise RuntimeError("SCHEDULER_NOT_RUNNING")

        self.paused = True
        return {
            "scheduler": "PAUSED",
            "status": self.trader.status(),
        }

    def resume(self) -> dict[str, Any]:
        if not self.running:
            raise RuntimeError("SCHEDULER_NOT_RUNNING")

        self.safety_check()
        self.paused = False

        return {
            "scheduler": "RUNNING",
            "status": self.trader.status(),
        }

    def fail_closed_stop(self) -> dict[str, Any]:
        self.running = False
        self.paused = False
        self.trader.stop()

        return {
            "scheduler": "STOPPED",
            "reason": "FAIL_CLOSED",
            "status": self.trader.status(),
        }

    def stop(self) -> dict[str, Any]:
        self.running = False
        self.paused = False
        self.trader.stop()

        return {
            "scheduler": "STOPPED",
            "status": self.trader.status(),
        }

    def run_once(self, client_order_id: str | None = None):
        if not self.running:
            raise RuntimeError("SCHEDULER_NOT_RUNNING")

        if self.paused:
            raise RuntimeError("SCHEDULER_PAUSED")

        self.safety_check()

        return self.trader.cycle(
            client_order_id=client_order_id
        )

    def run_forever(self):
        self.start()

        try:
            while self.running:
                self.run_once()
                time.sleep(self.interval_seconds)
        finally:
            self.stop()
