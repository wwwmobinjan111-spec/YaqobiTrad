from __future__ import annotations

from dataclasses import dataclass


@dataclass
class PositionLifecycle:
    symbol: str
    quantity: float = 0.0

    @property
    def state(self) -> str:
        if self.quantity > 0:
            return "LONG"
        if self.quantity < 0:
            return "SHORT"
        return "FLAT"

    def apply_fill(self, signed_quantity: float) -> str:
        previous = self.state
        self.quantity += signed_quantity

        if abs(self.quantity) < 1e-12:
            self.quantity = 0.0

        current = self.state

        if previous == "FLAT" and current in ("LONG", "SHORT"):
            return "ENTRY"

        if previous in ("LONG", "SHORT") and current == "FLAT":
            return "EXIT"

        if previous == current:
            return "ADD"

        return "REVERSAL"

    def snapshot(self) -> dict:
        return {
            "symbol": self.symbol,
            "quantity": self.quantity,
            "state": self.state,
        }
