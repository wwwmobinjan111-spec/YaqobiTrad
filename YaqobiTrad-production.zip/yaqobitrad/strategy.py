"""Versioned deterministic 1-minute strategy; paper/backtest only."""
from __future__ import annotations
from dataclasses import dataclass
from .signal import SignalEngine, Signal

@dataclass(frozen=True)
class StrategyParameters:
    version: str = "1.0.0"
    fast_ema: int = 9
    slow_ema: int = 21
    rsi_period: int = 14
    atr_period: int = 14
    min_atr: float = 0.0

@dataclass(frozen=True)
class StrategyDecision:
    symbol: str
    close_time: int
    action: str
    price: float
    parameter_version: str
    provenance: str

class StrategyEngine:
    def __init__(self, parameters=None):
        self.parameters = parameters or StrategyParameters()
        p=self.parameters
        self.signal_engine=SignalEngine(p.fast_ema,p.slow_ema,p.rsi_period,p.atr_period)

    def decide(self, symbol, candles):
        s: Signal=self.signal_engine.evaluate(symbol,candles)
        action=s.action if s.atr >= self.parameters.min_atr else "HOLD"
        return StrategyDecision(s.symbol,s.close_time,action,s.price,self.parameters.version,
            f"strategy:{self.parameters.version}|{s.provenance}|atr_min={self.parameters.min_atr}")

    def replay(self, symbol, candles):
        if len(candles) < self.parameters.slow_ema: return []
        out=[]
        for i in range(self.parameters.slow_ema, len(candles)+1):
            out.append(self.decide(symbol,candles[:i]))
        return out
