from __future__ import annotations
import json, os, tempfile
from dataclasses import dataclass, asdict
import hashlib
from yaqobitrad.fund_audit import build_audit

@dataclass(frozen=True)
class FundEntry:
    sequence: int
    member_id: str
    event: str
    amount: float
    balance: float

class MemberFunds:
    def __init__(self, path: str):
        self.path = path
        self.members = {}
        self.entries = []
        self.audit = []
        self.pending_withdrawals = {}
        if os.path.exists(path):
            with open(path) as f:
                data = json.load(f)
            self.members = {k: float(v) for k, v in data.get("members", {}).items()}
            self.entries = data.get("entries", [])
            self.audit = data.get("audit", [])
            self.pending_withdrawals = data.get("pending_withdrawals", {})
            if data.get("members_integrity") != __import__("hashlib").sha256(__import__("json").dumps(self.members,sort_keys=True,separators=(",",":")).encode()).hexdigest(): raise ValueError("member balance integrity failure")

            # Fail closed on any persisted ledger/audit tampering.
            expected_audit = build_audit(self.entries)
            if self.audit != expected_audit:
                raise ValueError("fund audit integrity failure")
            for i, e in enumerate(self.entries, 1):
                if e.get("sequence") != i:
                    raise ValueError("fund sequence integrity failure")

            for rid, record in self.pending_withdrawals.items():
                expected = hashlib.sha256(
                    f"{rid}|{record['member_id']}|{float(record['amount'])}|{record['status']}".encode()
                ).hexdigest()
                if record.get("integrity") != expected:
                    raise ValueError("pending withdrawal integrity failure")

    def _refresh_audit(self):
        self.audit = build_audit(self.entries)

    def _save(self):
        self._refresh_audit()
        folder = os.path.dirname(os.path.abspath(self.path))
        fd, tmp = tempfile.mkstemp(prefix=".funds-", dir=folder)
        try:
            with os.fdopen(fd, "w") as f:
                json.dump(
                    {"members": self.members, "members_integrity": __import__("hashlib").sha256(__import__("json").dumps(self.members,sort_keys=True,separators=(",",":")).encode()).hexdigest(), "entries": self.entries, "audit": self.audit, "pending_withdrawals": self.pending_withdrawals},
                    f, sort_keys=True, separators=(",", ":")
                )
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self.path)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)

    def balance(self, member_id: str) -> float:
        return float(self.members.get(member_id, 0.0))

    def deposit(self, member_id: str, amount: float):
        if not member_id or amount <= 0:
            raise ValueError("invalid deposit")
        new = self.balance(member_id) + float(amount)
        self.members[member_id] = new
        self.entries.append({
            "sequence": len(self.entries) + 1,
            "member_id": member_id,
            "event": "DEPOSIT",
            "amount": float(amount),
            "status": "COMPLETED",
            "balance": new,
        })
        self._save()
        return new

    def request_withdrawal(self, member_id: str, amount: float):
        if not member_id or amount <= 0:
            raise ValueError("invalid withdrawal request")

        amount = float(amount)
        current = self.balance(member_id)

        reserved = sum(
            float(x["amount"])
            for x in self.pending_withdrawals.values()
            if x["member_id"] == member_id
            and x["status"] in ("PENDING", "APPROVED")
        )

        if amount + reserved > current:
            raise ValueError("insufficient available member funds")

        request_id = f"WD-{len(self.pending_withdrawals) + 1:06d}"
        record = {
            "member_id": member_id,
            "amount": amount,
            "status": "PENDING",
        }
        record["integrity"] = hashlib.sha256(
            f"{request_id}|{member_id}|{amount}|PENDING".encode()
        ).hexdigest()

        self.pending_withdrawals[request_id] = record
        self._save()
        return request_id

    def approve_withdrawal(self, request_id: str):
        r = self.pending_withdrawals.get(request_id)
        if not r or r.get("status") != "PENDING":
            raise ValueError("invalid pending withdrawal")
        r["status"] = "APPROVED"
        r["integrity"] = hashlib.sha256(
            f"{request_id}|{r['member_id']}|{float(r['amount'])}|APPROVED".encode()
        ).hexdigest()
        self._save()

    def cancel_withdrawal(self, request_id: str):
        r = self.pending_withdrawals.get(request_id)
        if not r or r.get("status") not in ("PENDING", "APPROVED"):
            raise ValueError("invalid withdrawal for cancellation")
        r["status"] = "CANCELLED"
        r["integrity"] = hashlib.sha256(
            f"{request_id}|{r['member_id']}|{float(r['amount'])}|CANCELLED".encode()
        ).hexdigest()
        self._save()

    def complete_withdrawal(self, request_id: str):
        r = self.pending_withdrawals.get(request_id)
        if not r or r.get("status") != "APPROVED":
            raise ValueError("withdrawal not approved")
        member_id = r["member_id"]
        amount = float(r["amount"])
        if amount > self.balance(member_id):
            raise ValueError("insufficient member funds")
        self.members[member_id] = self.balance(member_id) - amount
        r["status"] = "COMPLETED"
        r["integrity"] = hashlib.sha256(
            f"{request_id}|{r['member_id']}|{float(r['amount'])}|COMPLETED".encode()
        ).hexdigest()
        self._save()

    def withdraw(self, member_id: str, amount: float):
        if not member_id or amount <= 0:
            raise ValueError("invalid withdrawal")
        current = self.balance(member_id)
        if float(amount) > current:
            raise ValueError("insufficient member funds")
        new = current - float(amount)
        self.members[member_id] = new
        self.entries.append({
            "sequence": len(self.entries) + 1,
            "member_id": member_id,
            "event": "WITHDRAW",
            "amount": float(amount),
            "status": "COMPLETED",
            "balance": new,
        })
        self._save()
        return new
