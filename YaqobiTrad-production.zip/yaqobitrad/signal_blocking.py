from dataclasses import dataclass

@dataclass(frozen=True)
class SignalFinding:
    finding_id: str
    control: str
    status: str
    activation_impact: bool
    rationale: str

SIGNAL_FINDINGS = (
    SignalFinding(
        "SIG-001", "input-validity", "CONTROLLED", False,
        "Signal inputs can be required to originate from validated market data."
    ),
    SignalFinding(
        "SIG-002", "closed-candle-boundary", "CONTROLLED", False,
        "Signal evaluation is constrained by the validated closed-candle boundary."
    ),
    SignalFinding(
        "SIG-003", "production-signal-engine", "CONTROLLED", True,
        "Deterministic closed-candle 1m signal engine is implemented and covered by executable tests."
    ),
    SignalFinding(
        "SIG-004", "signal-replay-validation", "CONTROLLED", True,
        "Deterministic signal replay validation is covered by executable tests."
    ),
    SignalFinding(
        "SIG-005", "signal-provenance", "CONTROLLED", True,
        "Each generated signal carries symbol, closed-candle timestamp, source and engine provenance."
    ),
)

def signal_findings():
    return SIGNAL_FINDINGS

def signal_blocks_activation():
    return any(f.status == "OPEN" and f.activation_impact for f in SIGNAL_FINDINGS)
