"""Fail-closed dependency integrity and vulnerability gate for YaqobiTrad."""
from __future__ import annotations
import shutil
import subprocess
from dataclasses import dataclass

@dataclass(frozen=True)
class DependencyGate:
    pip_check_ok: bool
    vulnerability_scanner_available: bool
    scanner_name: str | None
    vulnerability_scan_ok: bool


def dependency_gate() -> DependencyGate:
    result = subprocess.run(
        ["python", "-m", "pip", "check"],
        capture_output=True,
        text=True,
        check=False,
    )
    scanner = None
    scan_ok = False
    if shutil.which("pip-audit"):
        scanner = "pip-audit"
        scan = subprocess.run(
            ["pip-audit"], capture_output=True, text=True, check=False
        )
        scan_ok = scan.returncode == 0
    elif shutil.which("safety"):
        scanner = "safety"
        scan = subprocess.run(
            ["safety", "check"], capture_output=True, text=True, check=False
        )
        scan_ok = scan.returncode == 0
    return DependencyGate(
        pip_check_ok=result.returncode == 0,
        vulnerability_scanner_available=scanner is not None,
        scanner_name=scanner,
        vulnerability_scan_ok=scan_ok,
    )


def dependency_blocks_activation() -> bool:
    gate = dependency_gate()
    return (
        not gate.pip_check_ok
        or not gate.vulnerability_scanner_available
        or not gate.vulnerability_scan_ok
    )
