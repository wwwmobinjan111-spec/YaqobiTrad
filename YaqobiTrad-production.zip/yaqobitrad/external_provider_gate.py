"""Fail-closed gate for successful external market-provider E2E verification."""
from __future__ import annotations

from .provider import BinancePublicProvider


def external_provider_e2e_check(symbol: str = "BTCUSDT", interval: str = "1m", timeout: float = 5.0) -> dict[str, object]:
    try:
        candle = BinancePublicProvider(timeout=timeout).fetch_latest_closed_candle(symbol, interval)
        return {"verified": True, "status": "PASS", "close_time": candle.close_time}
    except Exception as exc:
        return {"verified": False, "status": "BLOCKED", "reason": f"{type(exc).__name__}: {exc}"}


def external_provider_blocks_activation() -> bool:
    return not bool(external_provider_e2e_check().get("verified"))
