from __future__ import annotations

import json
import os
from dataclasses import dataclass, asdict
from typing import Any

from .core import YaqobiTradCore


@dataclass
class AutoTraderState:
    status: str = "STOPPED"
    cycles: int = 0
    last_result: dict[str, Any] | None = None


class AutoTraderLoop:
    """
    Operational 1M Paper AutoTrader controller.

    Market -> Strategy -> Risk -> Position -> Execution
            -> Portfolio -> Monitoring

    Live trading remains SAFE_OFF.
    """

    def __init__(
        self,
        core: YaqobiTradCore,
        symbol: str = "BTCUSDT",
        quantity: float = 0.001,
    ):
        self.core = core
        self.symbol = symbol
        self.quantity = quantity
        self.state_path = f"{core.portfolio.path}.autotrader"
        self.state = self._load_state()

    def _load_state(self) -> AutoTraderState:
        try:
            with open(self.state_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return AutoTraderState(
                status="STOPPED",
                cycles=int(data.get("cycles", 0)),
                last_result=data.get("last_result"),
            )
        except (OSError, ValueError, TypeError):
            return AutoTraderState()

    def _save_state(self) -> None:
        tmp = f"{self.state_path}.tmp"
        data = asdict(self.state)

        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, sort_keys=True, separators=(",", ":"))
            f.flush()
            os.fsync(f.fileno())

        os.replace(tmp, self.state_path)

    def start(self) -> dict[str, Any]:
        safety = self.core.safety_state()

        if (
            safety["live_trading"] != "SAFE_OFF"
            or safety["activation_gate"] != "LOCKED"
            or safety["fail_closed"] != "ACTIVE"
        ):
            raise RuntimeError("AUTOTRADER_SAFETY_STATE_INVALID")

        self.state.status = "RUNNING"
        self._save_state()
        return self.status()

    def stop(self) -> dict[str, Any]:
        self.state.status = "STOPPED"
        self._save_state()
        return self.status()

    def cycle(self, client_order_id: str | None = None):
        if self.state.status != "RUNNING":
            raise RuntimeError("AUTOTRADER_NOT_RUNNING")

        result = self.core.cycle(
            self.symbol,
            quantity=self.quantity,
            client_order_id=client_order_id,
        )

        self.state.cycles += 1
        self.state.last_result = {
            "action": result.action,
            "price": result.price,
            "risk_approved": result.risk_approved,
            "execution_status": result.execution.get("status"),
            "position": result.portfolio_positions.get(
                self.symbol, 0.0
            ),
            "balance": result.portfolio_balance,
        }

        self._save_state()
        return result

    def status(self) -> dict[str, Any]:
        return {
            "status": self.state.status,
            "symbol": self.symbol,
            "quantity": self.quantity,
            "cycles": self.state.cycles,
            "last_result": self.state.last_result,
            "safety": self.core.safety_state(),
            "monitoring_healthy": self.core.monitoring.healthy,
        }
