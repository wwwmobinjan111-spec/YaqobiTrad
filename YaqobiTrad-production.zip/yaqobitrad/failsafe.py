class FailClosed:
    def __init__(self):
        self.safe = True

    def on_failure(self, component):
        self.safe = True
        return {"component": component, "action": "SHUTDOWN", "live_trading": "SAFE_OFF"}

    def can_trade_live(self):
        return False if self.safe else True
