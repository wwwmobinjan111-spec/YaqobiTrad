from dataclasses import dataclass

@dataclass(frozen=True)
class PortfolioAuditFinding:
    finding_id: str
    control: str
    status: str
    activation_impact: bool
    rationale: str

FINDINGS = (
    PortfolioAuditFinding("PA-001", "audit-chain-integrity", "CONTROLLED", False,
        "Durable audit entries use chained SHA-256 hashes and tamper detection."),
    PortfolioAuditFinding("PA-002", "portfolio-boundary", "CONTROLLED", False,
        "Durable portfolio ledger persists balance and positions atomically."),
    PortfolioAuditFinding("PA-003", "position-reconciliation", "CONTROLLED", False,
        "Portfolio ledger exposes deterministic state reconciliation and integrity validation."),
    PortfolioAuditFinding("PA-004", "audit-completeness", "CONTROLLED", False,
        "Audit completeness verifies required event coverage after chain verification."),
    PortfolioAuditFinding("PA-005", "audit-persistence", "CONTROLLED", False,
        "Audit journal uses durable atomic persistence and validates on reload."),
    PortfolioAuditFinding("PA-006", "portfolio-recovery", "CONTROLLED", False,
        "Portfolio state is recovered from the durable ledger and rejected if integrity fails."),
)

def portfolio_audit_findings():
    return FINDINGS

def portfolio_audit_blocks_activation():
    return any(f.status == "OPEN" and f.activation_impact for f in FINDINGS)
