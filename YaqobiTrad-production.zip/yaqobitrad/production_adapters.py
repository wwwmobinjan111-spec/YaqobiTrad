import os

def auth_status():
    url = os.getenv("YQ_AUTH_URL") or os.getenv("AUTH_URL")
    return {"configured": bool(url), "endpoint": url or None}

def secret_status():
    url = os.getenv("YQ_SECRET_URL") or os.getenv("VAULT_ADDR")
    return {"configured": bool(url), "endpoint": url or None}

def production_safety():
    return {
        "live_trading": "SAFE_OFF",
        "activation_gate": "LOCKED",
        "fail_closed": True,
    }

def production_adapter_status():
    return {
        "auth": auth_status(),
        "secret": secret_status(),
        "safety": production_safety(),
    }
