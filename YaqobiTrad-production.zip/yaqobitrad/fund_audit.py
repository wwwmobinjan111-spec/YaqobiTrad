from __future__ import annotations
import hashlib
import json

def audit_digest(sequence, member_id, event, amount, status, previous):
    payload = json.dumps({
        "sequence": sequence,
        "member_id": member_id,
        "event": event,
        "amount": float(amount),
        "status": status,
        "previous": previous,
    }, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode()).hexdigest()

def build_audit(entries):
    previous = ""
    result = []
    for i, e in enumerate(entries, 1):
        digest = audit_digest(
            i, e["member_id"], e["event"],
            e["amount"], e["status"], previous
        )
        result.append({**e, "sequence": i, "previous": previous, "digest": digest})
        previous = digest
    return result

def verify_audit(entries):
    rebuilt = build_audit([
        {k: e[k] for k in
         ("member_id", "event", "amount", "status")}
        for e in entries
    ])
    return all(
        a["digest"] == b["digest"] and
        a["previous"] == b["previous"]
        for a, b in zip(entries, rebuilt)
    )
