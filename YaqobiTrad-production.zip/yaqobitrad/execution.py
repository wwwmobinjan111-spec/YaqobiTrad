"""Fail-closed execution control layer; no live exchange submission."""
from __future__ import annotations
from dataclasses import dataclass
from . import config
from .order_provider import BinanceOrderProvider

@dataclass(frozen=True)
class ExecutionRecord:
    client_order_id: str
    status: str
    side: str
    quantity: float
    price: float
    sequence: int

class ExecutionControl:
    """Deterministic execution control with idempotency and reconciliation.

    This layer never talks to an exchange. Live submission remains blocked until
    an explicitly integrated and independently verified exchange adapter exists.
    """
    def __init__(self):
        self._records: dict[str, ExecutionRecord] = {}
        self._sequence = 0

    def submit_paper(self, client_order_id, side, quantity, price):
        if not client_order_id:
            return {"status":"BLOCKED", "reason":"CLIENT_ORDER_ID_REQUIRED"}
        if client_order_id in self._records:
            r = self._records[client_order_id]
            return {"status":"IDEMPOTENT_REPLAY", "client_order_id":r.client_order_id,
                    "sequence":r.sequence, "original_status":r.status}
        if side not in {"BUY", "SELL"} or quantity <= 0 or price <= 0:
            return {"status":"BLOCKED", "reason":"INVALID_ORDER"}
        self._sequence += 1
        r = ExecutionRecord(client_order_id,"PAPER_FILLED",side,float(quantity),float(price),self._sequence)
        self._records[client_order_id] = r
        return {"status":r.status,"client_order_id":r.client_order_id,"sequence":r.sequence}

    def reconcile(self):
        seqs = [r.sequence for r in self._records.values()]
        if len(seqs) != len(set(seqs)):
            return False
        return sorted(seqs) == list(range(1, len(seqs)+1))

    def live_submit(self, side, quantity, price, client_order_id=None, symbol="BTCUSDT"):
        if client_order_id is None:
            client_order_id = f"live-{self._sequence + 1}"

        provider = BinanceOrderProvider(
            live_enabled=False,
        )

        result = provider.submit_order(
            symbol=symbol,
            side=side,
            quantity=quantity,
            price=price,
            client_order_id=client_order_id,
        )

        return {
            "status": result.status,
            "client_order_id": result.client_order_id,
            "exchange_order_id": result.exchange_order_id,
            "reason": (
                "LIVE_PROVIDER_ADAPTER_NOT_VERIFIED"
                if result.status == "BLOCKED"
                else result.reason
            ),
        }

class ExecutionEngine:
    def __init__(self, risk_engine):
        self.risk = risk_engine
        self.control = ExecutionControl()

    def submit(self, side, quantity, price, current_position_value=0.0, client_order_id=None):
        if config.ACTIVATION_GATE != "OPEN":
            return {"status": "BLOCKED", "reason": "ACTIVATION_GATE_LOCKED"}
        if not config.LIVE_TRADING:
            return {"status": "BLOCKED", "reason": "LIVE_TRADING_SAFE_OFF"}
        return self.control.live_submit(side, quantity, price, client_order_id=client_order_id)

    def paper_submit(self, side, quantity, price, client_order_id=None):
        value = quantity * price
        ok, reason = self.risk.approve(value)
        if not ok:
            return {"status": "BLOCKED", "reason": reason}
        if client_order_id is None:
            client_order_id = f"paper-{self.control._sequence + 1}"
        return self.control.submit_paper(client_order_id, side, quantity, price)
