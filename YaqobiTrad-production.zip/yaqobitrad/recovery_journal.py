from __future__ import annotations

from typing import Any

from .event_journal import EventJournal


class JournalRecovery:
    """Reconstructs the last operational state from the event journal."""

    def __init__(self, journal: EventJournal):
        self.journal = journal

    def recover(self) -> dict[str, Any]:
        events = self.journal.read()

        state = {
            "status": "UNKNOWN",
            "cycles": 0,
            "last_execution": None,
            "last_balance": None,
            "last_position": None,
        }

        for event in events:
            name = event.get("event")

            if name == "START":
                state["status"] = "RUNNING"

            elif name == "CYCLE":
                state["cycles"] += 1
                state["last_execution"] = event.get("execution_status")
                state["last_balance"] = event.get("balance")
                state["last_position"] = event.get("position")

            elif name == "STOP":
                state["status"] = "STOPPED"

        state["events"] = len(events)
        return state
