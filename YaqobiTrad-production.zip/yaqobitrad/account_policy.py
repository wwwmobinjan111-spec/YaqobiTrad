from __future__ import annotations

class AccountPolicy:
    def __init__(self, min_withdrawal=1.0, max_withdrawal=100000.0):
        self.min_withdrawal = float(min_withdrawal)
        self.max_withdrawal = float(max_withdrawal)

    def validate_withdrawal(self, amount):
        amount = float(amount)
        if amount < self.min_withdrawal:
            raise ValueError("withdrawal below minimum")
        if amount > self.max_withdrawal:
            raise ValueError("withdrawal above maximum")
        return True
