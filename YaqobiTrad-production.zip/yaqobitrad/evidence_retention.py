"""Fail-closed contract for security evidence retention.

This module validates deployment retention requirements without claiming that a
remote immutable store is configured or verified.
"""
from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class RetentionPolicy:
    minimum_days: int
    immutable: bool
    remote: bool
    verified: bool


def retention_blocks_activation(policy: RetentionPolicy) -> bool:
    return (
        policy.minimum_days <= 0
        or not policy.immutable
        or not policy.remote
        or not policy.verified
    )


def validate_retention_policy(policy: RetentionPolicy) -> None:
    if retention_blocks_activation(policy):
        raise ValueError("production immutable remote retention is not verified")
