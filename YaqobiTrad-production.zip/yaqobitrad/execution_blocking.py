from dataclasses import dataclass

@dataclass(frozen=True)
class ExecutionFinding:
    finding_id: str
    control: str
    status: str
    activation_impact: bool
    rationale: str

EXECUTION_FINDINGS = (
    ExecutionFinding(
        "EXEC-001", "paper-execution", "CONTROLLED", False,
        "Paper execution is available in the reconstructed baseline."
    ),
    ExecutionFinding(
        "EXEC-002", "activation-gate", "CONTROLLED", False,
        "Live execution is blocked while the activation gate is locked."
    ),
    ExecutionFinding(
        "EXEC-003", "live-provider-adapter", "OPEN", True,
        "External production exchange/provider adapter is not yet independently verified."
    ),
    ExecutionFinding(
        "EXEC-004", "order-state-reconciliation", "CONTROLLED", False,
        "Deterministic execution-control reconciliation is implemented and tested; external exchange reconciliation remains separate."
    ),
    ExecutionFinding(
        "EXEC-005", "execution-idempotency", "CONTROLLED", False,
        "Deterministic client-order idempotency and duplicate protection are implemented and tested."
    ),
    ExecutionFinding(
        "EXEC-006", "execution-failure-recovery", "CONTROLLED", False,
        "Execution control fails closed on invalid/unverified live submission; external exchange recovery remains separate."
    ),
)

def execution_findings():
    return EXECUTION_FINDINGS

def execution_blocks_activation():
    return any(f.status == "OPEN" and f.activation_impact for f in EXECUTION_FINDINGS)
