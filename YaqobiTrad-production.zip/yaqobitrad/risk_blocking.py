from dataclasses import dataclass

@dataclass(frozen=True)
class RiskFinding:
    finding_id: str
    control: str
    status: str
    activation_impact: bool
    rationale: str

RISK_FINDINGS = (
    RiskFinding("RISK-001", "order-limit", "CONTROLLED", False, "Order-size limits are enforced."),
    RiskFinding("RISK-002", "position-limit", "CONTROLLED", False, "Position-size limits are enforced."),
    RiskFinding("RISK-003", "live-gate", "CONTROLLED", False, "Live execution remains locked."),
    RiskFinding("RISK-004", "portfolio-exposure", "CONTROLLED", False, "Portfolio exposure limit is enforced before approval."),
    RiskFinding("RISK-005", "drawdown-control", "CONTROLLED", False, "Drawdown threshold blocks further orders."),
    RiskFinding("RISK-006", "frequency-limit", "CONTROLLED", False, "Order frequency is throttled over a rolling window."),
    RiskFinding("RISK-007", "circuit-breaker", "CONTROLLED", False, "Circuit breaker blocks approvals when tripped."),
)

def risk_findings():
    return RISK_FINDINGS

def risk_blocks_activation():
    return any(f.status == "OPEN" and f.activation_impact for f in RISK_FINDINGS)
