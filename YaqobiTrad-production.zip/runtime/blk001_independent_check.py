import json
from pathlib import Path

root = Path.home() / "YaqobiTrad"

raw = root / "runtime/current_evidence_raw.txt"
bound = root / "runtime/current_evidence_bound.txt"
local = root / "runtime/local_production_evidence.txt"

checks = {}

# Raw evidence must be genuine read-only provider evidence
text = raw.read_text()
data = json.loads(text.split("E2E=")[0])
checks["PROVIDER_VERIFIED"] = data.get("verified") is True and data.get("status") == "VERIFIED"
checks["READ_ONLY"] = data.get("read_only") is True
checks["NO_ORDERS_SUBMITTED"] = data.get("orders_submitted") is False

# Bound evidence must contain integrity metadata and VERIFIED evidence
btext = bound.read_text()
checks["BOUND_SHA256"] = "SOURCE_SHA256=" in btext and "PROVIDER_SHA256=" in btext
checks["BOUND_VERIFIED"] = '"verified": true' in btext and "E2E=VERIFIED" in btext

# Local production evidence
ltext = local.read_text()
checks["LOCAL_4_OF_4"] = "LOCAL_EVIDENCE=4/4" in ltext
checks["SAFETY_FAIL_CLOSED"] = (
    "LIVE_TRADING=SAFE_OFF" in ltext
    and "ACTIVATION_GATE=LOCKED" in ltext
    and "FAIL_CLOSED=ACTIVE" in ltext
)

for k, v in checks.items():
    print(f"{k}={'PASS' if v else 'FAIL'}")

result = all(checks.values())
print(f"INDEPENDENT_CURRENT_EQUIVALENCE_TEST={'PASS' if result else 'FAIL'}")
