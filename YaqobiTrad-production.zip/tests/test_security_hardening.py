import pytest
from yaqobitrad.security import Authenticator, SecretVault

def test_authentication_and_rbac_fail_closed():
    auth = Authenticator()
    auth.add_user("admin", "correct-password", {"admin", "trader"})
    with pytest.raises(PermissionError):
        auth.authenticate("admin", "wrong-password")
    p = auth.authenticate("admin", "correct-password")
    assert auth.authorize(p, "admin") is True
    assert auth.authorize(p, "viewer") is False
    auth.revoke(p)
    assert auth.authorize(p, "admin") is False

def test_secret_rotation_and_revocation():
    vault = SecretVault()
    v1 = vault.put("provider-key", "old")
    assert vault.get("provider-key") == "old"
    v2 = vault.rotate("provider-key", "new")
    assert v2 == v1 + 1
    assert vault.get("provider-key") == "new"
    vault.revoke("provider-key", v2)
    with pytest.raises(KeyError):
        vault.get("provider-key")
