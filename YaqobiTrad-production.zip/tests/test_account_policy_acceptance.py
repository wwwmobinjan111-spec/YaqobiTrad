from pathlib import Path
import json
import tempfile
import pytest
from yaqobitrad.member_funds import MemberFunds
from yaqobitrad.account_policy import AccountPolicy
from yaqobitrad.fund_audit import verify_audit

def test_pending_withdrawal_is_member_bound_and_persistent():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"
        p=MemberFunds(path)
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",200)
        q=MemberFunds(path)

        assert q.pending_withdrawals[wid]["member_id"]=="A"
        assert q.pending_withdrawals[wid]["amount"]==200
        assert q.pending_withdrawals[wid]["status"]=="PENDING"

def test_pending_withdrawal_cannot_exceed_member_balance():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",100)
        with pytest.raises(ValueError):
            p.request_withdrawal("A",101)

def test_account_policy_limits():
    policy=AccountPolicy(min_withdrawal=10,max_withdrawal=1000)
    assert policy.validate_withdrawal(10)
    assert policy.validate_withdrawal(1000)
    with pytest.raises(ValueError):
        policy.validate_withdrawal(9)
    with pytest.raises(ValueError):
        policy.validate_withdrawal(1001)

def test_pending_withdrawal_tamper_is_detected():
    import json
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"
        p=MemberFunds(path)
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",200)

        with open(path) as f:
            data=json.load(f)

        data["pending_withdrawals"][wid]["member_id"]="B"

        with open(path,"w") as f:
            json.dump(data,f)

        with pytest.raises(ValueError, match="pending withdrawal integrity failure"):
            MemberFunds(path)

def test_withdrawal_approval_completion_boundary():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",200)

        with pytest.raises(ValueError):
            p.complete_withdrawal(wid)

        p.approve_withdrawal(wid)
        p.complete_withdrawal(wid)

        assert p.balance("A")==800
        assert p.pending_withdrawals[wid]["status"]=="COMPLETED"

def test_completed_withdrawal_cannot_complete_again():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",200)
        p.approve_withdrawal(wid)
        p.complete_withdrawal(wid)

        with pytest.raises(ValueError):
            p.complete_withdrawal(wid)

        assert p.balance("A")==800

def test_member_boundary_on_withdrawal_request():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",300)

        assert p.pending_withdrawals[wid]["member_id"]=="A"
        assert p.balance("B")==0

def test_completed_withdrawal_persists_after_restart():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"
        p=MemberFunds(path)
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",250)
        p.approve_withdrawal(wid)
        p.complete_withdrawal(wid)

        q=MemberFunds(path)
        assert q.balance("A")==750
        assert q.pending_withdrawals[wid]["status"]=="COMPLETED"

def test_fund_audit_chain_and_tamper_detection():
    from yaqobitrad.fund_audit import build_audit, verify_audit

    entries = [
        {"member_id":"A","event":"DEPOSIT","amount":1000,"status":"COMPLETED"},
        {"member_id":"A","event":"WITHDRAW","amount":200,"status":"COMPLETED"},
    ]

    audit = build_audit(entries)
    assert verify_audit(audit)

    audit[0]["amount"] = 900
    assert not verify_audit(audit)

def test_member_funds_persists_audit_for_real_operations():
    import json
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"
        p=MemberFunds(path)
        p.deposit("A",1000)
        p.withdraw("A",200)

        q=MemberFunds(path)

        assert len(q.audit) == 2
        assert q.audit[0]["member_id"] == "A"
        assert q.audit[0]["event"] == "DEPOSIT"
        assert q.audit[1]["event"] == "WITHDRAW"
        assert q.audit[1]["amount"] == 200
        assert q.audit[0]["digest"] != q.audit[1]["digest"]

def test_pending_withdrawal_reserves_available_member_funds():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)

        first=p.request_withdrawal("A",800)

        with pytest.raises(ValueError, match="insufficient available member funds"):
            p.request_withdrawal("A",300)

        assert p.balance("A")==1000
        assert p.pending_withdrawals[first]["status"]=="PENDING"

def test_approved_withdrawal_remains_reserved_until_completion():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",800)
        p.approve_withdrawal(wid)

        with pytest.raises(ValueError, match="insufficient available member funds"):
            p.request_withdrawal("A",300)

        assert p.balance("A")==1000
        assert p.pending_withdrawals[wid]["status"]=="APPROVED"

def test_completion_releases_reservation_and_debits_once():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",800)
        p.approve_withdrawal(wid)
        p.complete_withdrawal(wid)

        assert p.balance("A")==200

        wid2=p.request_withdrawal("A",200)
        p.approve_withdrawal(wid2)
        p.complete_withdrawal(wid2)

        assert p.balance("A")==0

def test_cancel_pending_withdrawal_releases_reservation():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",800)

        p.cancel_withdrawal(wid)

        assert p.balance("A")==1000
        assert p.pending_withdrawals[wid]["status"]=="CANCELLED"

        wid2=p.request_withdrawal("A",800)
        assert p.pending_withdrawals[wid2]["status"]=="PENDING"

def test_cancel_approved_withdrawal_releases_reservation():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",800)
        p.approve_withdrawal(wid)
        p.cancel_withdrawal(wid)

        assert p.balance("A")==1000

        wid2=p.request_withdrawal("A",1000)
        assert p.pending_withdrawals[wid2]["status"]=="PENDING"

def test_cancelled_withdrawal_persists_after_restart_and_integrity():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"

        p=MemberFunds(path)
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",800)
        p.cancel_withdrawal(wid)

        p2=MemberFunds(path)

        assert p2.pending_withdrawals[wid]["status"]=="CANCELLED"
        assert p2.balance("A")==1000
        assert p2.pending_withdrawals[wid]["integrity"]

        wid2=p2.request_withdrawal("A",1000)
        assert p2.pending_withdrawals[wid2]["status"]=="PENDING"

def test_cancel_preserves_fund_audit_chain():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"
        p=MemberFunds(path)

        p.deposit("A",1000)
        wid=p.request_withdrawal("A",800)
        p.cancel_withdrawal(wid)

        assert verify_audit(p.audit) is True
        assert p.balance("A")==1000


def test_cancel_preserves_audit_after_restart():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"
        p=MemberFunds(path)

        p.deposit("A",1000)
        wid=p.request_withdrawal("A",800)
        p.cancel_withdrawal(wid)

        p2=MemberFunds(path)

        assert verify_audit(p2.audit) is True
        assert p2.balance("A")==1000
        assert p2.pending_withdrawals[wid]["status"]=="CANCELLED"


def test_cancelled_withdrawal_does_not_debit_member():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"
        p=MemberFunds(path)

        p.deposit("A",1000)
        wid=p.request_withdrawal("A",700)
        p.cancel_withdrawal(wid)

        assert p.balance("A")==1000
        with pytest.raises(ValueError, match="insufficient available member funds"):
            wid2=p.request_withdrawal("A",1001)


def test_cancel_then_new_withdrawal_reservation():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"
        p=MemberFunds(path)

        p.deposit("A",1000)
        wid=p.request_withdrawal("A",800)
        p.cancel_withdrawal(wid)

        wid2=p.request_withdrawal("A",900)

        assert p.pending_withdrawals[wid]["status"]=="CANCELLED"
        assert p.pending_withdrawals[wid2]["status"]=="PENDING"
        assert p.balance("A")==1000

def test_cancelled_withdrawal_cannot_be_cancelled_again():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",500)
        p.cancel_withdrawal(wid)

        with pytest.raises(ValueError, match="invalid withdrawal for cancellation"):
            p.cancel_withdrawal(wid)


def test_cancelled_withdrawal_cannot_be_completed():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",500)
        p.cancel_withdrawal(wid)

        with pytest.raises(ValueError, match="withdrawal not approved"):
            p.complete_withdrawal(wid)

        assert p.balance("A")==1000


def test_cancelled_withdrawal_cannot_be_approved():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",500)
        p.cancel_withdrawal(wid)

        with pytest.raises(ValueError):
            p.approve_withdrawal(wid)

        assert p.balance("A")==1000


def test_cancelled_withdrawal_integrity_remains_valid_after_blocked_actions():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",500)
        p.cancel_withdrawal(wid)

        try:
            p.approve_withdrawal(wid)
        except ValueError:
            pass

        try:
            p.complete_withdrawal(wid)
        except ValueError:
            pass

        p2=MemberFunds(f"{d}/funds.json")
        assert p2.pending_withdrawals[wid]["status"]=="CANCELLED"
        assert p2.pending_withdrawals[wid]["integrity"]
        assert p2.balance("A")==1000


def test_cancelled_withdrawal_does_not_consume_available_funds():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",700)
        p.cancel_withdrawal(wid)

        wid2=p.request_withdrawal("A",1000)

        assert p.pending_withdrawals[wid]["status"]=="CANCELLED"
        assert p.pending_withdrawals[wid2]["status"]=="PENDING"
        assert p.balance("A")==1000

def test_completed_withdrawal_cannot_be_cancelled():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",500)
        p.approve_withdrawal(wid)
        p.complete_withdrawal(wid)

        with pytest.raises(ValueError):
            p.cancel_withdrawal(wid)

        assert p.balance("A")==500


def test_completed_withdrawal_cannot_be_approved():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",500)
        p.approve_withdrawal(wid)
        p.complete_withdrawal(wid)

        with pytest.raises(ValueError):
            p.approve_withdrawal(wid)


def test_completed_withdrawal_cannot_be_completed_again():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",500)
        p.approve_withdrawal(wid)
        p.complete_withdrawal(wid)

        with pytest.raises(ValueError, match="withdrawal not approved"):
            p.complete_withdrawal(wid)

        assert p.balance("A")==500


def test_missing_withdrawal_cannot_change_state():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")

        with pytest.raises(ValueError):
            p.approve_withdrawal("WD-999999")

        with pytest.raises(ValueError):
            p.complete_withdrawal("WD-999999")

        with pytest.raises(ValueError):
            p.cancel_withdrawal("WD-999999")


def test_completed_state_persists_with_integrity_after_restart():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"
        p=MemberFunds(path)
        p.deposit("A",1000)
        wid=p.request_withdrawal("A",400)
        p.approve_withdrawal(wid)
        p.complete_withdrawal(wid)

        p2=MemberFunds(path)

        assert p2.pending_withdrawals[wid]["status"]=="COMPLETED"
        assert p2.balance("A")==600
        assert p2.pending_withdrawals[wid]["integrity"]

def test_zero_withdrawal_is_rejected_without_state_change():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)

        with pytest.raises(ValueError, match="invalid withdrawal request"):
            p.request_withdrawal("A",0)

        assert p.balance("A")==1000
        assert p.pending_withdrawals=={}


def test_negative_withdrawal_is_rejected_without_state_change():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)

        with pytest.raises(ValueError, match="invalid withdrawal request"):
            p.request_withdrawal("A",-100)

        assert p.balance("A")==1000
        assert p.pending_withdrawals=={}


def test_over_limit_withdrawal_creates_no_pending_request():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)

        with pytest.raises(ValueError, match="insufficient available member funds"):
            p.request_withdrawal("A",1001)

        assert p.balance("A")==1000
        assert p.pending_withdrawals=={}


def test_rejected_withdrawal_input_does_not_change_audit_or_balance():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)

        audit_before=list(p.audit)

        with pytest.raises(ValueError):
            p.request_withdrawal("A",-1)

        assert p.balance("A")==1000
        assert p.pending_withdrawals=={}
        assert p.audit==audit_before

def test_member_withdrawal_cannot_cross_member_balance():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        p.deposit("B",500)

        with pytest.raises(ValueError, match="insufficient available member funds"):
            p.request_withdrawal("A",1200)

        assert p.balance("A")==1000
        assert p.balance("B")==500
        assert p.pending_withdrawals=={}


def test_member_a_request_cannot_be_approved_as_member_b():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        p.deposit("B",500)

        wid=p.request_withdrawal("A",400)

        with pytest.raises(ValueError):
            p.approve_withdrawal("B:"+wid)

        assert p.pending_withdrawals[wid]["member_id"]=="A"
        assert p.pending_withdrawals[wid]["status"]=="PENDING"


def test_member_a_request_cannot_be_cancelled_as_member_b():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        p.deposit("B",500)

        wid=p.request_withdrawal("A",400)

        with pytest.raises(ValueError):
            p.cancel_withdrawal("B:"+wid)

        assert p.pending_withdrawals[wid]["member_id"]=="A"
        assert p.pending_withdrawals[wid]["status"]=="PENDING"


def test_member_operation_does_not_change_other_member():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        p.deposit("B",500)

        wid=p.request_withdrawal("A",400)
        p.approve_withdrawal(wid)
        p.complete_withdrawal(wid)

        assert p.balance("A")==600
        assert p.balance("B")==500

def test_member_withdrawal_cannot_cross_member_balance():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        p.deposit("B",500)

        with pytest.raises(ValueError, match="insufficient available member funds"):
            p.request_withdrawal("A",1200)

        assert p.balance("A")==1000
        assert p.balance("B")==500
        assert p.pending_withdrawals=={}


def test_member_a_request_cannot_be_approved_as_member_b():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        p.deposit("B",500)

        wid=p.request_withdrawal("A",400)

        with pytest.raises(ValueError):
            p.approve_withdrawal("B:"+wid)

        assert p.pending_withdrawals[wid]["member_id"]=="A"
        assert p.pending_withdrawals[wid]["status"]=="PENDING"


def test_member_a_request_cannot_be_cancelled_as_member_b():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        p.deposit("B",500)

        wid=p.request_withdrawal("A",400)

        with pytest.raises(ValueError):
            p.cancel_withdrawal("B:"+wid)

        assert p.pending_withdrawals[wid]["member_id"]=="A"
        assert p.pending_withdrawals[wid]["status"]=="PENDING"


def test_member_operation_does_not_change_other_member():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")
        p.deposit("A",1000)
        p.deposit("B",500)

        wid=p.request_withdrawal("A",400)
        p.approve_withdrawal(wid)
        p.complete_withdrawal(wid)

        assert p.balance("A")==600
        assert p.balance("B")==500

def test_zero_deposit_is_rejected_without_state_change():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")

        with pytest.raises(ValueError):
            p.deposit("A",0)

        assert p.balance("A")==0
        assert p.entries==[]


def test_negative_deposit_is_rejected_without_state_change():
    with tempfile.TemporaryDirectory() as d:
        p=MemberFunds(f"{d}/funds.json")

        with pytest.raises(ValueError):
            p.deposit("A",-100)

        assert p.balance("A")==0
        assert p.entries==[]


def test_deposit_persists_after_restart():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"

        p=MemberFunds(path)
        p.deposit("A",1500)

        p2=MemberFunds(path)

        assert p2.balance("A")==1500
        assert len(p2.entries)==1
        assert p2.audit


def test_member_deposit_isolation_after_restart():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"

        p=MemberFunds(path)
        p.deposit("A",1500)
        p.deposit("B",700)

        p2=MemberFunds(path)

        assert p2.balance("A")==1500
        assert p2.balance("B")==700
        assert p2.balance("A") != p2.balance("B")

def test_tampered_deposit_amount_is_detected_after_restart():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"
        p=MemberFunds(path)
        p.deposit("A",1000)

        data=json.loads(Path(path).read_text())
        data["entries"][0]["amount"]=900
        Path(path).write_text(json.dumps(data))

        with pytest.raises(ValueError):
            MemberFunds(path)


def test_tampered_deposit_member_id_is_detected_after_restart():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"
        p=MemberFunds(path)
        p.deposit("A",1000)

        data=json.loads(Path(path).read_text())
        data["entries"][0]["member_id"]="B"
        Path(path).write_text(json.dumps(data))

        with pytest.raises(ValueError):
            MemberFunds(path)


def test_tampered_deposit_event_is_detected_after_restart():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"
        p=MemberFunds(path)
        p.deposit("A",1000)

        data=json.loads(Path(path).read_text())
        data["entries"][0]["event"]="WITHDRAW"
        Path(path).write_text(json.dumps(data))

        with pytest.raises(ValueError):
            MemberFunds(path)


def test_tampered_audit_is_detected_after_restart():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"
        p=MemberFunds(path)
        p.deposit("A",1000)

        data=json.loads(Path(path).read_text())
        data["audit"][0]["digest"]="TAMPERED"
        Path(path).write_text(json.dumps(data))

        with pytest.raises(ValueError):
            MemberFunds(path)

def test_tampered_deposit_balance_is_detected_after_restart():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"
        p=MemberFunds(path)
        p.deposit("A",1000)
        data=json.loads(Path(path).read_text())
        data["entries"][0]["balance"]=1
        Path(path).write_text(json.dumps(data))
        with pytest.raises(ValueError):
            MemberFunds(path)


def test_tampered_deposit_sequence_is_detected_after_restart():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"
        p=MemberFunds(path)
        p.deposit("A",1000)
        data=json.loads(Path(path).read_text())
        data["entries"][0]["sequence"]=99
        Path(path).write_text(json.dumps(data))
        with pytest.raises(ValueError):
            MemberFunds(path)


def test_tampered_member_balance_is_detected_after_restart():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/funds.json"
        p=MemberFunds(path)
        p.deposit("A",1000)
        data=json.loads(Path(path).read_text())
        data["members"]["A"]=1
        Path(path).write_text(json.dumps(data))
        with pytest.raises(ValueError):
            MemberFunds(path)
