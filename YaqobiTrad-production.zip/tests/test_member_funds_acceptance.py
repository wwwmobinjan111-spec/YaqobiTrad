import tempfile
import pytest
from yaqobitrad.member_funds import MemberFunds

def test_member_isolation_and_deposit_withdraw():
    with tempfile.TemporaryDirectory() as d:
        p = MemberFunds(f"{d}/funds.json")
        p.deposit("A", 1000)
        p.deposit("B", 500)
        p.withdraw("A", 200)

        assert p.balance("A") == 800
        assert p.balance("B") == 500
        assert p.balance("A") != p.balance("B")

def test_persistence():
    with tempfile.TemporaryDirectory() as d:
        path = f"{d}/funds.json"
        p = MemberFunds(path)
        p.deposit("A", 1000)

        q = MemberFunds(path)
        assert q.balance("A") == 1000

def test_cross_member_withdrawal_cannot_mix_funds():
    with tempfile.TemporaryDirectory() as d:
        p = MemberFunds(f"{d}/funds.json")
        p.deposit("A", 1000)

        with pytest.raises(ValueError):
            p.withdraw("B", 1)

        assert p.balance("A") == 1000
        assert p.balance("B") == 0

def test_overwithdrawal_fails_closed():
    with tempfile.TemporaryDirectory() as d:
        p = MemberFunds(f"{d}/funds.json")
        p.deposit("A", 100)
        with pytest.raises(ValueError):
            p.withdraw("A", 101)
        assert p.balance("A") == 100
