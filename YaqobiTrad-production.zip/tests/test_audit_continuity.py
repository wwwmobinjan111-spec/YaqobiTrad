import pytest
from yaqobitrad.audit import AuditLog
from yaqobitrad.evidence import evidence_digest, evidence_integrity, observability_release_state, record_observation
from yaqobitrad.monitoring import MonitoringState


def test_audit_chain_preserves_previous_hash_links():
    audit = AuditLog()
    first = audit.append('BOOT')
    second = audit.append('RECOVERY')
    assert second['prev_hash'] == first['hash']
    assert audit.verify() is True


def test_audit_middle_entry_tamper_is_detected():
    audit = AuditLog()
    audit.append('A', {'n': 1})
    audit.append('B', {'n': 2})
    audit.append('C', {'n': 3})
    audit.entries[1]['data']['n'] = 99
    assert audit.verify() is False


def test_evidence_digest_changes_when_evidence_changes():
    audit = AuditLog()
    record_observation(audit, 'metric', {'value': 1})
    before = evidence_digest(audit)
    audit.entries[0]['data']['value'] = 2
    after = evidence_digest(audit)
    assert before != after
    assert evidence_integrity(audit) is False


def test_release_blocks_when_audit_chain_is_broken():
    monitoring = MonitoringState()
    monitoring.heartbeat(now=100.0)
    audit = AuditLog()
    record_observation(audit, 'heartbeat', {'ts': 100.0})
    audit.entries[0]['hash'] = 'broken'
    state = observability_release_state(monitoring, audit)
    assert state['state'] == 'BLOCKED'
    assert state['live_trading'] == 'SAFE_OFF'
    assert state['activation_gate'] == 'LOCKED'


def test_empty_event_cannot_enter_evidence_chain():
    audit = AuditLog()
    with pytest.raises(ValueError):
        record_observation(audit, '')
    assert audit.entries == []
    assert evidence_integrity(audit) is True


def test_multiple_recovery_events_remain_auditable():
    audit = AuditLog()
    for event in ('CHECKPOINT_CREATED', 'RECOVERY_STARTED', 'RECOVERY_COMPLETED'):
        record_observation(audit, event)
    assert len(audit.entries) == 3
    assert evidence_integrity(audit) is True
