from yaqobitrad.audit import AuditLog
from yaqobitrad.security_evidence import (
    record_security_incident, verify_security_evidence, security_evidence_digest,
)
import pytest


def test_security_incident_is_audited_and_verifiable():
    audit = AuditLog()
    entry = record_security_incident(audit, "INC-001", "HIGH", "AUTH_FAILURE", {"user": "admin"})
    assert entry["event"] == "SECURITY_INCIDENT"
    assert verify_security_evidence(audit) is True
    assert security_evidence_digest(audit)


def test_security_evidence_fails_closed_after_tamper():
    audit = AuditLog()
    record_security_incident(audit, "INC-002", "CRITICAL", "KEY_REVOKED")
    audit.entries[0]["hash"] = "tampered"
    assert verify_security_evidence(audit) is False


def test_security_incident_requires_identity_and_event():
    audit = AuditLog()
    with pytest.raises(ValueError):
        record_security_incident(audit, "", "HIGH", "AUTH_FAILURE")


def test_security_evidence_durable_export_and_manifest(tmp_path):
    from yaqobitrad.security_transport import export_security_evidence, verify_security_export
    audit = AuditLog()
    record_security_incident(audit, "INC-003", "HIGH", "AUTH_FAILURE")
    path = export_security_evidence(audit, str(tmp_path), "bundle-003")
    assert path.exists()
    assert verify_security_export(str(path)) is True


def test_security_evidence_export_fails_closed_after_file_tamper(tmp_path):
    from yaqobitrad.security_transport import export_security_evidence, verify_security_export
    audit = AuditLog()
    record_security_incident(audit, "INC-004", "CRITICAL", "KEY_REVOKED")
    path = export_security_evidence(audit, str(tmp_path), "bundle-004")
    path.write_text(path.read_text() + "tampered")
    assert verify_security_export(str(path)) is False


def test_security_evidence_export_requires_intact_audit(tmp_path):
    from yaqobitrad.security_transport import export_security_evidence
    audit = AuditLog()
    record_security_incident(audit, "INC-005", "HIGH", "AUTH_FAILURE")
    audit.entries[0]["hash"] = "tampered"
    with pytest.raises(ValueError):
        export_security_evidence(audit, str(tmp_path), "bundle-005")


def test_retention_policy_fail_closed_when_remote_immutable_retention_unverified():
    from yaqobitrad.evidence_retention import RetentionPolicy, retention_blocks_activation, validate_retention_policy
    policy = RetentionPolicy(minimum_days=30, immutable=True, remote=True, verified=False)
    assert retention_blocks_activation(policy) is True
    with pytest.raises(ValueError):
        validate_retention_policy(policy)


def test_retention_policy_accepts_verified_contract():
    from yaqobitrad.evidence_retention import RetentionPolicy, retention_blocks_activation, validate_retention_policy
    policy = RetentionPolicy(minimum_days=30, immutable=True, remote=True, verified=True)
    assert retention_blocks_activation(policy) is False
    validate_retention_policy(policy)
