from yaqobitrad.dependency_gate import dependency_blocks_activation, dependency_gate
from yaqobitrad.release_gate import release_gate_state


def test_dependency_gate_reports_scanner_state():
    gate = dependency_gate()
    assert isinstance(gate.pip_check_ok, bool)
    assert isinstance(gate.vulnerability_scanner_available, bool)
    assert isinstance(gate.vulnerability_scan_ok, bool)


def test_dependency_gate_fails_closed_when_any_boundary_is_bad():
    gate = dependency_gate()
    assert dependency_blocks_activation() is (
        (not gate.pip_check_ok)
        or (not gate.vulnerability_scanner_available)
        or (not gate.vulnerability_scan_ok)
    )


def test_release_gate_is_blocked_by_dependency_boundary():
    gate = dependency_gate()
    if dependency_blocks_activation():
        assert release_gate_state()["state"] == "BLOCKED"


def test_vulnerability_scanner_failure_blocks_activation(monkeypatch):
    import yaqobitrad.dependency_gate as dg

    class Result:
        def __init__(self, returncode):
            self.returncode = returncode
            self.stdout = ""
            self.stderr = ""

    calls = []
    def fake_run(args, **kwargs):
        calls.append(args)
        return Result(0 if args[:3] == ["python", "-m", "pip"] else 1)

    monkeypatch.setattr(dg.shutil, "which", lambda name: "/usr/bin/pip-audit" if name == "pip-audit" else None)
    monkeypatch.setattr(dg.subprocess, "run", fake_run)
    gate = dg.dependency_gate()
    assert gate.scanner_name == "pip-audit"
    assert gate.vulnerability_scanner_available is True
    assert gate.vulnerability_scan_ok is False
    assert dg.dependency_blocks_activation() is True
