from yaqobitrad.security_blocking import security_inventory, security_blocks_activation

def test_security_inventory_has_controlled_boundaries():
    inv = security_inventory()
    assert "activation_gate_lock" in inv.controlled
    assert "fail_closed_state" in inv.controlled
    assert "live_trading_safe_off" in inv.controlled
    assert "audit_hash_integrity" in inv.controlled

def test_security_inventory_has_open_activation_blockers():
    inv = security_inventory()
    assert len(inv.open_activation_blockers) == 4

def test_security_blocks_activation():
    assert security_blocks_activation() is True
