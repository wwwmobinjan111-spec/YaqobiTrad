from yaqobitrad.execution import ExecutionEngine
from yaqobitrad.risk import RiskEngine

def test_live_execution_is_blocked_by_default():
    r = ExecutionEngine(RiskEngine()).submit("BUY", 1, 100)
    assert r["status"] == "BLOCKED"
    assert r["reason"] == "ACTIVATION_GATE_LOCKED"

def test_paper_execution_works():
    r = ExecutionEngine(RiskEngine()).paper_submit("BUY", 1, 100)
    assert r["status"] == "PAPER_FILLED"
