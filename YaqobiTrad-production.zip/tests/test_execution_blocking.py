from yaqobitrad.execution_blocking import execution_findings, execution_blocks_activation

def test_execution_inventory_has_controlled_and_open_findings():
    findings = execution_findings()
    assert any(f.status == "CONTROLLED" for f in findings)
    assert any(f.status == "OPEN" for f in findings)

def test_execution_findings_are_well_formed():
    for f in execution_findings():
        assert f.finding_id.startswith("EXEC-")
        assert f.control
        assert f.rationale

def test_execution_gate_remains_blocked():
    assert execution_blocks_activation() is True
