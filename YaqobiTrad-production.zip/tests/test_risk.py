from yaqobitrad.risk import RiskEngine

def test_order_within_limit():
    assert RiskEngine().approve(500)[0] is True

def test_order_limit_blocks():
    ok, reason = RiskEngine().approve(1500)
    assert not ok and reason == "ORDER_LIMIT"

def test_position_limit_blocks():
    ok, reason = RiskEngine().approve(1000, 4501)
    assert not ok and reason == "POSITION_LIMIT"

def test_portfolio_exposure_limit_blocks():
    engine = RiskEngine()
    assert engine.approve(100, portfolio_exposure=4950)[0] is False
    assert engine.approve(100, portfolio_exposure=4950)[1] == "EXPOSURE_LIMIT"

def test_drawdown_limit_blocks():
    engine = RiskEngine()
    assert engine.approve(100, drawdown_pct=20.1) == (False, "DRAWDOWN_LIMIT")

def test_frequency_limit_blocks():
    engine = RiskEngine()
    for i in range(5):
        assert engine.approve(10, now=100 + i)[0] is True
        engine.record_order(now=100 + i)
    assert engine.approve(10, now=104)[1] == "FREQUENCY_LIMIT"

def test_circuit_breaker_blocks():
    engine = RiskEngine()
    engine.set_circuit_breaker(True)
    assert engine.approve(10) == (False, "CIRCUIT_BREAKER")
