from yaqobitrad.signal_blocking import signal_findings, signal_blocks_activation

def test_signal_inventory_is_controlled():
    findings = signal_findings()
    assert findings
    assert all(f.status == "CONTROLLED" for f in findings)

def test_signal_findings_are_well_formed():
    for f in signal_findings():
        assert f.finding_id.startswith("SIG-")
        assert f.control
        assert f.rationale

def test_signal_gate_is_not_blocked_by_signal_domain():
    assert signal_blocks_activation() is False
