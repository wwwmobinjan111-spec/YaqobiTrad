import json
import tempfile
from dataclasses import replace
import pytest
from yaqobitrad.portfolio import DurablePortfolio

def test_durable_ledger_roundtrip_and_reconcile():
    with tempfile.TemporaryDirectory() as d:
        p=f"{d}/portfolio.json"
        x=DurablePortfolio(p,1000)
        x.append("open",900,{"BTCUSDT":{"qty":1}})
        y=DurablePortfolio(p)
        assert y.balance==900 and y.positions["BTCUSDT"]["qty"]==1 and y.reconcile()

def test_tamper_is_rejected():
    with tempfile.TemporaryDirectory() as d:
        p=f"{d}/portfolio.json"
        x=DurablePortfolio(p,1000); x.append("open",900,{"BTCUSDT":{"qty":1}})
        data=json.load(open(p)); data["entries"][0]["balance"]=1; json.dump(data,open(p,"w"))
        with pytest.raises(ValueError): DurablePortfolio(p)
