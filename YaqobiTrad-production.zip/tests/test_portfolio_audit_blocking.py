from yaqobitrad.portfolio_audit_blocking import (
    portfolio_audit_findings, portfolio_audit_blocks_activation
)

def test_inventory_has_controlled_and_open_findings():
    findings = portfolio_audit_findings()
    assert any(f.status == "CONTROLLED" for f in findings)
    assert all(f.status == "CONTROLLED" for f in findings)

def test_findings_are_well_formed():
    for f in portfolio_audit_findings():
        assert f.finding_id.startswith("PA-")
        assert f.control
        assert f.rationale

def test_portfolio_audit_gate_remains_blocked():
    assert portfolio_audit_blocks_activation() is False
