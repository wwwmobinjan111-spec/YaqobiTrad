from yaqobitrad.strategy_blocking import strategy_findings, strategy_blocks_activation

def test_strategy_inventory_is_controlled():
    findings = strategy_findings()
    assert findings
    assert all(f.status == "CONTROLLED" for f in findings)

def test_strategy_findings_are_well_formed():
    for f in strategy_findings():
        assert f.finding_id.startswith("STR-")
        assert f.control
        assert f.rationale

def test_strategy_gate_is_not_blocked_by_strategy_domain():
    assert strategy_blocks_activation() is False
