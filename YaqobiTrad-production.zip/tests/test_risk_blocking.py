from yaqobitrad.risk_blocking import risk_findings, risk_blocks_activation

def test_risk_inventory_is_controlled():
    findings = risk_findings()
    assert any(f.status == "CONTROLLED" for f in findings)
    assert all(f.status == "CONTROLLED" for f in findings)

def test_risk_findings_are_well_formed():
    for f in risk_findings():
        assert f.finding_id.startswith("RISK-")
        assert f.control
        assert f.rationale

def test_risk_gate_has_no_risk_blocker():
    assert risk_blocks_activation() is False
