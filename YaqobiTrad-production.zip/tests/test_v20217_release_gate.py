from yaqobitrad.audit import AuditLog
from yaqobitrad.release_gate import release_gate_from_audit, release_gate_state


def test_open_blockers_keep_activation_locked():
    s = release_gate_state()
    assert s["state"] == "BLOCKED"
    assert s["activation_gate"] == "LOCKED"


def test_blocked_release_keeps_live_trading_safe_off():
    s = release_gate_state()
    assert s["live_trading"] == "SAFE_OFF"


def test_blocked_release_keeps_fail_closed_active():
    s = release_gate_state()
    assert s["fail_closed"] == "ACTIVE"


def test_broken_audit_blocks_release_even_without_gate_logic_changes():
    audit = AuditLog()
    audit.append("BOOT")
    audit.entries[0]["hash"] = "tampered"
    s = release_gate_from_audit(audit)
    assert s["state"] == "BLOCKED"
    assert s["live_trading"] == "SAFE_OFF"


def test_valid_audit_does_not_unlock_gate_automatically():
    audit = AuditLog()
    audit.append("BOOT")
    s = release_gate_from_audit(audit)
    assert s["activation_gate"] == "LOCKED"
    assert s["live_trading"] == "SAFE_OFF"


def test_gate_boundary_is_deterministic():
    a = release_gate_state()
    b = release_gate_state()
    assert a == b
