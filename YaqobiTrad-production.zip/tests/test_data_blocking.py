from yaqobitrad.data_blocking import data_findings, data_blocks_activation

def test_data_inventory_contains_controlled_and_open_findings():
    findings = data_findings()
    assert any(f.status == "CONTROLLED" for f in findings)
    assert any(f.status == "OPEN" for f in findings)

def test_data_findings_have_identity_and_rationale():
    for f in data_findings():
        assert f.finding_id.startswith("DATA-")
        assert f.control
        assert f.rationale

def test_data_gate_remains_fail_closed():
    assert data_blocks_activation() is True
