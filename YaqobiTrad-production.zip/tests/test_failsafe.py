from yaqobitrad.failsafe import FailClosed

def test_fail_closed():
    f = FailClosed()
    result = f.on_failure("execution")
    assert result["action"] == "SHUTDOWN"
    assert result["live_trading"] == "SAFE_OFF"
    assert f.can_trade_live() is False
