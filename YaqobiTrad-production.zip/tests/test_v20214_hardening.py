import pytest

from yaqobitrad.audit import AuditLog
from yaqobitrad.evidence import evidence_digest, observability_release_state, record_observation
from yaqobitrad.monitoring import MonitoringState


def test_missing_heartbeat_is_stale_and_unhealthy():
    state = MonitoringState()
    assert state.stale(now=10.0, max_age=5.0) is True
    assert state.healthy is False


def test_negative_max_age_is_rejected():
    state = MonitoringState()
    with pytest.raises(ValueError):
        state.stale(now=10.0, max_age=-1.0)


def test_empty_alert_message_is_rejected():
    state = MonitoringState()
    with pytest.raises(ValueError):
        state.alert("")


def test_digest_changes_when_evidence_changes():
    audit = AuditLog()
    record_observation(audit, "event", {"n": 1})
    before = evidence_digest(audit)
    record_observation(audit, "event", {"n": 2})
    assert evidence_digest(audit) != before


def test_empty_audit_is_valid_but_activation_remains_locked():
    monitoring = MonitoringState()
    audit = AuditLog()
    state = observability_release_state(monitoring, audit)
    assert state["state"] == "OBSERVABLE"
    assert state["activation_gate"] == "LOCKED"
    assert state["live_trading"] == "SAFE_OFF"


def test_monitoring_failure_action_is_fail_closed():
    state = MonitoringState()
    state.alert("backend unavailable")
    action = state.fail_closed_action()
    assert action["action"] == "SHUTDOWN"
    assert action["live_trading"] == "SAFE_OFF"
    assert action["activation_gate"] == "LOCKED"


def test_release_gate_includes_security_blockers():
    from yaqobitrad.release_gate import release_gate_state
    state = release_gate_state(audit_ok=True)
    assert state["state"] == "BLOCKED"
    assert state["live_trading"] == "SAFE_OFF"
    assert state["activation_gate"] == "LOCKED"
    assert state["fail_closed"] == "ACTIVE"
