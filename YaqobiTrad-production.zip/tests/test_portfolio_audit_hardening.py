import json
import tempfile
import pytest
from yaqobitrad.audit import AuditLog
from yaqobitrad.portfolio import DurablePortfolio
from yaqobitrad.portfolio_audit_blocking import portfolio_audit_findings, portfolio_audit_blocks_activation

def test_durable_audit_roundtrip_and_completeness():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/audit.json"
        a=AuditLog(path)
        a.append("START", {"mode":"PAPER"})
        a.append("ORDER_BLOCKED", {"reason":"SAFE_OFF"})
        b=AuditLog(path)
        assert b.verify()
        assert b.completeness(["START","ORDER_BLOCKED"])

def test_audit_missing_required_event_is_incomplete():
    a=AuditLog()
    a.append("START")
    assert not a.completeness(["START","SHUTDOWN"])

def test_audit_tamper_is_rejected_on_reload():
    with tempfile.TemporaryDirectory() as d:
        path=f"{d}/audit.json"
        a=AuditLog(path); a.append("START")
        data=json.load(open(path)); data["entries"][0]["event"]="TAMPERED"
        json.dump(data,open(path,"w"))
        with pytest.raises(ValueError): AuditLog(path)

def test_portfolio_external_state_reconciliation_boundary():
    with tempfile.TemporaryDirectory() as d:
        p=DurablePortfolio(f"{d}/portfolio.json",1000)
        p.append("open",900,{"BTCUSDT":{"qty":1,"avg_price":100}})
        assert p.reconcile()
        assert p.positions == {"BTCUSDT":{"qty":1,"avg_price":100}}

def test_all_portfolio_audit_findings_controlled():
    findings=portfolio_audit_findings()
    assert len(findings)==6
    assert all(f.status=="CONTROLLED" for f in findings)
    assert portfolio_audit_blocks_activation() is False
