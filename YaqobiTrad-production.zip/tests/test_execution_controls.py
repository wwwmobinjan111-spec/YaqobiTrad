from yaqobitrad.execution import ExecutionEngine
from yaqobitrad.risk import RiskEngine

def test_paper_idempotency():
    e=ExecutionEngine(RiskEngine())
    a=e.paper_submit("BUY",1,100,client_order_id="abc")
    b=e.paper_submit("BUY",1,100,client_order_id="abc")
    assert a["status"] == "PAPER_FILLED"
    assert b["status"] == "IDEMPOTENT_REPLAY"
    assert b["sequence"] == a["sequence"]

def test_execution_reconciliation():
    e=ExecutionEngine(RiskEngine())
    e.paper_submit("BUY",1,100,client_order_id="a")
    e.paper_submit("SELL",1,101,client_order_id="b")
    assert e.control.reconcile() is True

def test_invalid_order_fail_closed():
    e=ExecutionEngine(RiskEngine())
    r=e.paper_submit("BUY",0,100,client_order_id="bad")
    assert r["status"] == "BLOCKED"
    assert r["reason"] == "INVALID_ORDER_VALUE"

def test_live_provider_is_not_falsely_enabled():
    e=ExecutionEngine(RiskEngine())
    r=e.control.live_submit("BUY",1,100,client_order_id="live")
    assert r["status"] == "BLOCKED"
    assert r["reason"] == "LIVE_PROVIDER_ADAPTER_NOT_VERIFIED"
