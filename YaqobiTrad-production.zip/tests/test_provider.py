import json
from unittest.mock import patch

from yaqobitrad.provider import BinancePublicProvider, ProviderFreshnessBridge

def test_binance_provider_parses_closed_kline():
    payload = [[1700000000000,"100","101","99","100.5","12",1700000059999]]
    class Resp:
        def __enter__(self): return self
        def __exit__(self,*a): pass
        def read(self): return json.dumps(payload).encode()
    with patch("yaqobitrad.provider.urlopen", return_value=Resp()):
        c = BinancePublicProvider("https://example.test").fetch_latest_closed_candle("btcusdt","1m")
    assert c.close == 100.5
    assert c.closed is True

def test_freshness_rejects_duplicate_and_stale():
    b = ProviderFreshnessBridge(max_age_seconds=60)
    payload = type("C", (), {"close_time": 100000})()
    assert b.observe(payload) is True
    assert b.observe(payload) is False
    assert b.is_fresh(now_ms=100001) is True
    assert b.is_fresh(now_ms=160001) is False
    assert b.fail_closed_state()["activation_gate"] == "LOCKED"
