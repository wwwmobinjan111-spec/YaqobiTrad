from yaqobitrad.monitoring import monitoring_inventory

def test_production_observability_blockers_remain_explicit():
    inv = monitoring_inventory()
    assert len(inv["activation_blockers"]) >= 4
