import json
from unittest.mock import patch
import pytest
from yaqobitrad.provider import BinancePublicProvider

def test_provider_rejects_only_open_kline():
    payload=[[1700000000000,"100","101","99","100.5","12",9999999999999]]
    class Resp:
        def __enter__(self): return self
        def __exit__(self,*a): pass
        def read(self): return json.dumps(payload).encode()
    with patch("yaqobitrad.provider._time.time", return_value=1700000001):
        with patch("yaqobitrad.provider.urlopen", return_value=Resp()):
            with pytest.raises(ValueError, match="no closed"):
                BinancePublicProvider("https://example.test").fetch_latest_closed_candle("btcusdt","1m")
