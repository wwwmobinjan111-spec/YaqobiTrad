import os
from yaqobitrad import config
from yaqobitrad.execution import ExecutionEngine
from yaqobitrad.risk import RiskEngine
from yaqobitrad.audit import AuditLog
from yaqobitrad.failsafe import FailClosed
from yaqobitrad.release_gate import release_gate_state


def test_end_to_end_live_path_stays_blocked():
    engine = ExecutionEngine(RiskEngine())
    result = engine.submit("BUY", 1, 100)
    assert result["status"] == "BLOCKED"
    assert result["reason"] in {"ACTIVATION_GATE_LOCKED", "LIVE_TRADING_SAFE_OFF"}


def test_paper_path_requires_valid_risk():
    engine = ExecutionEngine(RiskEngine())
    result = engine.paper_submit("BUY", 2, 100)
    assert result["status"] == "PAPER_FILLED"


def test_risk_rejects_excessive_order_in_pipeline():
    engine = ExecutionEngine(RiskEngine())
    result = engine.paper_submit("BUY", 20, 100)
    assert result["status"] == "BLOCKED"
    assert result["reason"] == "ORDER_LIMIT"


def test_audit_records_pipeline_events_and_verifies():
    audit = AuditLog()
    audit.append("MARKET_ACCEPTED", {"symbol": "BTCUSDT"})
    audit.append("SIGNAL_ACCEPTED", {"side": "BUY"})
    audit.append("RISK_APPROVED", {"mode": "PAPER"})
    audit.append("EXECUTION_COMPLETED", {"mode": "PAPER"})
    assert audit.verify() is True
    assert [e["event"] for e in audit.entries] == [
        "MARKET_ACCEPTED", "SIGNAL_ACCEPTED", "RISK_APPROVED", "EXECUTION_COMPLETED"
    ]


def test_release_gate_remains_locked():
    state = release_gate_state(audit_ok=True)
    assert state["activation_gate"] == "LOCKED"
    assert state["live_trading"] == "SAFE_OFF"
    assert state["fail_closed"] == "ACTIVE"


def test_failure_injection_is_fail_closed():
    fs = FailClosed()
    result = fs.on_failure("E2E_EXECUTION")
    assert result["action"] == "SHUTDOWN"
    assert result["live_trading"] == "SAFE_OFF"
    assert fs.can_trade_live() is False
