from yaqobitrad.monitoring import MonitoringState, monitoring_inventory

def test_monitoring_inventory_covers_required_controls():
    inv = monitoring_inventory()
    required = {"structured_logging", "health_readiness", "metrics", "alerting", "heartbeat_freshness", "fail_closed_monitoring", "audit_traceability"}
    assert required.issubset(set(inv["controlled"]))

def test_heartbeat_marks_system_healthy():
    state = MonitoringState()
    state.heartbeat(now=100.0)
    assert state.healthy is True
    assert state.last_heartbeat == 100.0

def test_metrics_are_recorded():
    state = MonitoringState()
    state.metric("latency_ms", 12.5)
    assert state.metrics["latency_ms"] == 12.5

def test_alert_marks_monitoring_unhealthy():
    state = MonitoringState()
    state.alert("telemetry failure")
    assert state.healthy is False
    assert state.alerts == ["telemetry failure"]

def test_stale_heartbeat_is_detected():
    state = MonitoringState()
    state.heartbeat(now=100.0)
    assert state.stale(now=106.0, max_age=5.0) is True
    assert state.healthy is False

def test_fresh_heartbeat_is_not_stale():
    state = MonitoringState()
    state.heartbeat(now=100.0)
    assert state.stale(now=104.0, max_age=5.0) is False
    assert state.healthy is True

def test_monitoring_failure_has_fail_closed_action():
    state = MonitoringState()
    assert state.fail_closed_action() == {"action": "SHUTDOWN", "live_trading": "SAFE_OFF", "activation_gate": "LOCKED"}

def test_invalid_metric_name_is_rejected():
    state = MonitoringState()
    try:
        state.metric("", 1)
    except ValueError:
        pass
    else:
        raise AssertionError("empty metric name must be rejected")
