from yaqobitrad.global_checkpoint import global_checkpoint, checkpoint_is_fail_closed


def test_major_checkpoint_is_v20230_and_covers_all_tested_domains():
    cp = global_checkpoint()
    assert cp.checkpoint == "v2.02.30"
    expected = {
        "source", "architecture", "data", "signal", "strategy", "risk",
        "execution", "portfolio", "audit", "security", "dependencies",
        "evidence_retention",
    }
    assert set(cp.tested_domains) == expected


def test_major_checkpoint_has_current_open_blockers_and_pending_certification():
    cp = global_checkpoint()
    assert cp.open_blocker_count == 1
    assert cp.certification == "PENDING_REAL_PRODUCTION_RESULTS"


def test_major_checkpoint_is_fail_closed():
    assert checkpoint_is_fail_closed() is True
