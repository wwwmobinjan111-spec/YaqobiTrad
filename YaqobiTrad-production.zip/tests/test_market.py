from yaqobitrad.market import Candle, validate_candle

def test_closed_valid_candle():
    c = Candle(1, 2, 100, 110, 95, 105, 12, True)
    assert validate_candle(c) == (True, "VALID")

def test_open_candle_blocked():
    c = Candle(1, 2, 100, 110, 95, 105, 12, False)
    assert validate_candle(c) == (False, "CANDLE_NOT_CLOSED")
