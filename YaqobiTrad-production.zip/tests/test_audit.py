from yaqobitrad.audit import AuditLog

def test_audit_chain_integrity():
    a = AuditLog()
    a.append("LOGIN", {"user": "test"})
    a.append("ORDER_BLOCKED", {"reason": "SAFE_OFF"})
    assert a.verify() is True

def test_audit_tamper_detection():
    a = AuditLog()
    a.append("LOGIN")
    a.entries[0]["event"] = "TAMPERED"
    assert a.verify() is False
