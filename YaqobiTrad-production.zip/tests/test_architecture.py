from yaqobitrad.architecture import (
    architecture_findings,
    activation_impacting_findings,
    architecture_blocks_activation,
)

def test_architecture_inventory_has_controlled_and_open_findings():
    findings = architecture_findings()
    assert findings
    assert any(f.status == "CONTROLLED" for f in findings)
    assert any(f.status == "OPEN" for f in findings)

def test_only_explicit_open_activation_impacting_findings_block_activation():
    blockers = activation_impacting_findings()
    assert blockers
    assert all(f.status == "OPEN" and f.activation_impact for f in blockers)

def test_architecture_gate_is_fail_closed():
    assert architecture_blocks_activation() is True
