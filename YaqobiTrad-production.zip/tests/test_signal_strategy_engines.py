from yaqobitrad.market import Candle
from yaqobitrad.signal import SignalEngine
from yaqobitrad.strategy import StrategyEngine, StrategyParameters
from yaqobitrad.signal_blocking import signal_findings, signal_blocks_activation
from yaqobitrad.strategy_blocking import strategy_findings, strategy_blocks_activation

def candles(n=30):
    out=[]; price=100.0
    for i in range(n):
        price += 1.0
        out.append(Candle(i*60000,(i+1)*60000,price-0.5,price+0.5,price-1,price,100.0,True))
    return out

def test_signal_engine_is_deterministic_and_provenance_bearing():
    s=SignalEngine().evaluate("BTCUSDT", candles())
    assert s.action == "BUY"
    assert s.close_time == 30*60000
    assert "source=validated_closed_candles" in s.provenance

def test_signal_engine_rejects_open_candle():
    cs=candles(); cs[-1]=Candle(cs[-1].open_time,cs[-1].close_time,*cs[-1].__dict__.values()) if False else Candle(cs[-1].open_time,cs[-1].close_time,cs[-1].open,cs[-1].high,cs[-1].low,cs[-1].close,cs[-1].volume,False)
    try: SignalEngine().evaluate("BTCUSDT", cs); assert False
    except ValueError as e: assert str(e)=="CANDLE_NOT_CLOSED"

def test_strategy_version_and_replay_are_deterministic():
    p=StrategyParameters(version="1.0.1")
    a=StrategyEngine(p).replay("BTCUSDT", candles())
    b=StrategyEngine(p).replay("BTCUSDT", candles())
    assert len(a)==len(b)==10
    assert [(x.action,x.price,x.parameter_version) for x in a] == [(x.action,x.price,x.parameter_version) for x in b]
    assert all("strategy:1.0.1" in x.provenance for x in a)

def test_signal_blockers_controlled():
    assert all(f.status=="CONTROLLED" for f in signal_findings())
    assert signal_blocks_activation() is False

def test_strategy_blockers_controlled():
    assert all(f.status=="CONTROLLED" for f in strategy_findings())
    assert strategy_blocks_activation() is False
