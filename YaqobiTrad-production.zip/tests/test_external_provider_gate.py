from unittest.mock import patch

from yaqobitrad.external_provider_gate import external_provider_e2e_check, external_provider_blocks_activation


def test_external_provider_success_is_verified():
    candle = type("C", (), {"close_time": 1700000059999})()
    with patch("yaqobitrad.external_provider_gate.BinancePublicProvider.fetch_latest_closed_candle", return_value=candle):
        result = external_provider_e2e_check()
    assert result["verified"] is True
    assert result["status"] == "PASS"


def test_external_provider_failure_is_blocked():
    with patch("yaqobitrad.external_provider_gate.BinancePublicProvider.fetch_latest_closed_candle", side_effect=OSError("DNS failure")):
        result = external_provider_e2e_check()
    assert result["verified"] is False
    assert result["status"] == "BLOCKED"


def test_external_provider_failure_blocks_activation():
    with patch("yaqobitrad.external_provider_gate.external_provider_e2e_check", return_value={"verified": False, "status": "BLOCKED"}):
        assert external_provider_blocks_activation() is True


def test_external_provider_success_does_not_block():
    with patch("yaqobitrad.external_provider_gate.external_provider_e2e_check", return_value={"verified": True, "status": "PASS"}):
        assert external_provider_blocks_activation() is False
