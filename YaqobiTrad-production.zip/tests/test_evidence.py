import pytest

from yaqobitrad.audit import AuditLog
from yaqobitrad.evidence import evidence_digest, evidence_integrity, observability_release_state, record_observation
from yaqobitrad.monitoring import MonitoringState


def test_record_observation_is_audited():
    audit = AuditLog()
    record = record_observation(audit, "heartbeat", {"ok": True})
    assert record["event"] == "heartbeat"
    assert evidence_integrity(audit)


def test_audit_tamper_blocks_evidence():
    audit = AuditLog()
    record_observation(audit, "metric", {"value": 1})
    audit.entries[0]["data"]["value"] = 2
    assert not evidence_integrity(audit)


def test_evidence_digest_is_stable():
    audit = AuditLog()
    record_observation(audit, "event", {"n": 1})
    assert evidence_digest(audit) == evidence_digest(audit)
    assert len(evidence_digest(audit)) == 64


def test_unhealthy_monitoring_blocks_release():
    monitoring = MonitoringState()
    audit = AuditLog()
    monitoring.alert("test")
    assert observability_release_state(monitoring, audit)["state"] == "BLOCKED"


def test_tampered_audit_blocks_release():
    monitoring = MonitoringState()
    audit = AuditLog()
    record_observation(audit, "event")
    audit.entries[0]["event"] = "tampered"
    state = observability_release_state(monitoring, audit)
    assert state["state"] == "BLOCKED"
    assert state["activation_gate"] == "LOCKED"


def test_healthy_observability_still_keeps_live_trading_off():
    monitoring = MonitoringState()
    monitoring.heartbeat(now=100.0)
    audit = AuditLog()
    record_observation(audit, "heartbeat", {"ts": 100.0})
    state = observability_release_state(monitoring, audit)
    assert state["state"] == "OBSERVABLE"
    assert state["live_trading"] == "SAFE_OFF"
    assert state["activation_gate"] == "LOCKED"
