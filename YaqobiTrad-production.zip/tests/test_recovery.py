import pytest
from dataclasses import replace
from yaqobitrad.recovery import RecoveryCheckpoint, create_checkpoint, restore_checkpoint


def test_checkpoint_round_trip_preserves_state():
    cp = create_checkpoint(7, {"balance": 100, "mode": "PAPER"})
    restored = restore_checkpoint(cp, expected_sequence=7)
    assert restored["balance"] == 100
    assert restored["mode"] == "PAPER"


def test_negative_sequence_is_rejected():
    with pytest.raises(ValueError):
        create_checkpoint(-1, {})


def test_sequence_mismatch_is_rejected():
    cp = create_checkpoint(7, {})
    with pytest.raises(ValueError):
        restore_checkpoint(cp, expected_sequence=8)


def test_tampered_checkpoint_is_rejected():
    cp = create_checkpoint(7, {"balance": 100})
    tampered = replace(cp, state={"balance": 999})
    with pytest.raises(ValueError):
        restore_checkpoint(tampered)


def test_recovery_forces_safe_off_and_locked_gate():
    cp = create_checkpoint(7, {"mode": "PAPER"})
    restored = restore_checkpoint(cp)
    assert restored["live_trading"] == "SAFE_OFF"
    assert restored["activation_gate"] == "LOCKED"


def test_invalid_checkpoint_type_is_rejected():
    with pytest.raises(TypeError):
        restore_checkpoint(object())
