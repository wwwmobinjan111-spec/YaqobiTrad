import json
import os
from http.server import BaseHTTPRequestHandler, HTTPServer

from yaqobitrad.core import YaqobiTradCore
from yaqobitrad.autotrader import AutoTraderLoop
from yaqobitrad.scheduler import AutoTraderScheduler
from yaqobitrad.member_funds import MemberFunds


core = YaqobiTradCore("yaqobitrad_dashboard_portfolio.json")
trader = AutoTraderLoop(core, symbol="BTCUSDT", quantity=0.001)
scheduler = AutoTraderScheduler(trader, interval_seconds=60)
member_funds = MemberFunds("yaqobitrad_member_funds.json")
PRIMARY_MEMBER_ID = "primary"


class Handler(BaseHTTPRequestHandler):

    def send_json(self, data, status=200):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/api/account":
            self.send_json({
                "member_id": PRIMARY_MEMBER_ID,
                "balance": member_funds.balance(PRIMARY_MEMBER_ID),
            })
            return

        if self.path == "/api/history":
            self.send_json({"entries": [e.__dict__ if hasattr(e, "__dict__") else e for e in core.portfolio.entries[-50:]]})
            return
        if self.path == "/api/status":
            try:
                self.send_json({
                    "symbol": trader.symbol,
                    "price": None,
                    "action": "IDLE",
                    "strategy_version": "1.0.0",
                    "risk_approved": False,
                    "execution": {"status": "PAPER_READY"},
                    "balance": member_funds.balance(PRIMARY_MEMBER_ID),
                    "account": {
                        "member_id": PRIMARY_MEMBER_ID,
                        "balance": member_funds.balance(PRIMARY_MEMBER_ID),
                    },
                    "positions": dict(core.portfolio.positions),
                    "autotrader": trader.status(),
                    "scheduler": {
                        "running": scheduler.running,
                        "paused": scheduler.paused,
                        "interval_seconds": scheduler.interval_seconds,
                    },
                    "monitoring": {
                        "healthy": core.monitoring.healthy,
                        "alerts": list(core.monitoring.alerts),
                        "metrics": dict(core.monitoring.metrics),
                    },
                    "safety": core.safety_state(),
                    "provenance": "dashboard:control_center",
                })
            except Exception as e:
                self.send_json({"error": str(e)}, 500)
            return

        if self.path == "/" or self.path == "/dashboard.html":
            try:
                with open("dashboard.html", "rb") as f:
                    body = f.read()

                self.send_response(200)
                self.send_header(
                    "Content-Type",
                    "text/html; charset=utf-8"
                )
                self.send_header(
                    "Content-Length",
                    str(len(body))
                )
                self.end_headers()
                self.wfile.write(body)

            except FileNotFoundError:
                self.send_error(404)
            return

        self.send_error(404)

    def do_POST(self):
        if self.path in ("/api/account/deposit", "/api/account/withdraw"):
            try:
                length = int(self.headers.get("Content-Length", "0"))
                payload = json.loads(self.rfile.read(length) or b"{}")
                amount = float(payload.get("amount", 0))

                if self.path.endswith("/deposit"):
                    result = member_funds.deposit(PRIMARY_MEMBER_ID, amount)
                else:
                    result = member_funds.withdraw(PRIMARY_MEMBER_ID, amount)

                self.send_json({
                    "status": "OK",
                    "member_id": PRIMARY_MEMBER_ID,
                    "balance": member_funds.balance(PRIMARY_MEMBER_ID),
                    "result": result,
                })
            except ValueError as e:
                self.send_json({
                    "status": "BLOCKED",
                    "error": str(e),
                }, 400)
            except Exception as e:
                self.send_json({
                    "status": "ERROR",
                    "error": str(e),
                }, 500)
            return

        actions = {
            "/api/control/start": scheduler.start,
            "/api/control/stop": scheduler.stop,
        }

        action = actions.get(self.path)

        if action is None:
            self.send_json({
                "error": "CONTROL_ENDPOINT_NOT_FOUND"
            }, 404)
            return

        try:
            result = action()

            self.send_json({
                "status": "OK",
                "action": self.path,
                "result": result,
            })

        except RuntimeError as e:
            self.send_json({
                "status": "BLOCKED",
                "action": self.path,
                "error": str(e),
                "safety": core.safety_state(),
            }, 409)

        except Exception as e:
            self.send_json({
                "status": "ERROR",
                "action": self.path,
                "error": str(e),
            }, 500)

    def log_message(self, format, *args):
        print("%s - %s" % (
            self.address_string(),
            format % args
        ))


print("YaqobiTrad Dashboard Server")
print("CONTROL_CENTER=ACTIVE")
print("LIVE_TRADING=SAFE_OFF")
print("ACTIVATION_GATE=LOCKED")
print("FAIL_CLOSED=ACTIVE")
print("CORE_CYCLE=ACTIVE")
print("http://127.0.0.1:8080")

HTTPServer(("0.0.0.0", int(os.environ.get("PORT", "8080"))), Handler).serve_forever()
