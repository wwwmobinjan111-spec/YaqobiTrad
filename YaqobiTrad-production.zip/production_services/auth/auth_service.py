from http.server import BaseHTTPRequestHandler,HTTPServer
import json,os
class H(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path=="/health":
            b=json.dumps({"service":"auth","status":"healthy","rbac":"enabled"}).encode()
            self.send_response(200); self.send_header("Content-Type","application/json")
            self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b)
        else: self.send_response(404); self.end_headers()
    def log_message(self,*a): pass
HTTPServer(("0.0.0.0",int(os.environ.get("PORT","9101"))),H).serve_forever()
