from http.server import BaseHTTPRequestHandler,HTTPServer
import json,sqlite3
DB="production_services/portfolio/portfolio.sqlite3"
con=sqlite3.connect(DB)
con.execute("create table if not exists portfolio_events(id integer primary key,event text,balance real)")
con.commit(); con.close()
class H(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path=="/health":
            con=sqlite3.connect(DB)
            n=con.execute("select count(*) from portfolio_events").fetchone()[0]
            con.close()
            b=json.dumps({"service":"portfolio","status":"healthy","persistent":True,"rows":n}).encode()
            self.send_response(200); self.send_header("Content-Type","application/json")
            self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b)
        else: self.send_response(404); self.end_headers()
    def log_message(self,*a): pass
HTTPServer(("127.0.0.1",9103),H).serve_forever()
