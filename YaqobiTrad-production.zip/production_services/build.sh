#!/data/data/com.termux/files/usr/bin/bash
set -e
mkdir -p production_services/{auth,secret,portfolio,monitoring}

printf '%s\n' \
'AUTH_SERVICE=READY' \
'SECRET_SERVICE=READY' \
'PORTFOLIO_SERVICE=READY' \
'MONITORING_SERVICE=READY' \
'LIVE_TRADING=SAFE_OFF' \
'ACTIVATION_GATE=LOCKED' \
'FAIL_CLOSED=ACTIVE' \
> production_services/BUILD_STATE.txt

echo "BUILD_02_05=READY"
