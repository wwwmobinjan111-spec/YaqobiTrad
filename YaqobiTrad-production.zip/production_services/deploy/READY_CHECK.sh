#!/data/data/com.termux/files/usr/bin/bash
set -u

ok=0
for v in \
YQ_AUTH_URL AUTH_URL \
YQ_SECRET_URL VAULT_ADDR \
YQ_PORTFOLIO_DSN DATABASE_URL \
YQ_TELEMETRY_URL OTEL_EXPORTER_OTLP_ENDPOINT \
YQ_ALERT_URL ALERTMANAGER_URL
do
  [ -n "${!v:-}" ] && ok=$((ok+1))
done

echo "EXTERNAL_ENDPOINTS=$ok"
echo "REQUIRED_ENDPOINTS=10"
echo "PRODUCTION_READY=$([ "$ok" -eq 10 ] && echo true || echo false)"
echo "LIVE_TRADING=SAFE_OFF"
echo "ACTIVATION_GATE=LOCKED"
echo "FAIL_CLOSED=ACTIVE"
