"""Account policy and order-admission controls for YaqobiTrad.

The policy layer is deliberately fail-closed.  LIVE orders can only pass when
all account/risk checks pass *and* the formal activation gate is OPEN with
LIVE_TRADING enabled.  Roles never bypass the activation gate.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from time import time


ROLES = {"USER", "TRADER", "ADMIN", "SUPER_ADMIN"}
ACCOUNT_STATES = {"ACTIVE", "SUSPENDED", "LOCKED", "CLOSED"}
TRADING_MODES = {"PAPER", "LIVE"}


@dataclass(frozen=True)
class AccountLimits:
    allowed_symbols: frozenset[str] = frozenset()
    timeframe: str = "1M"
    max_order_value: float = 1000.0
    max_position_value: float = 5000.0
    max_open_positions: int = 5
    max_risk_per_trade_pct: float = 2.0
    max_daily_loss: float = 500.0
    max_drawdown_pct: float = 20.0
    max_orders_per_window: int = 5
    frequency_window_seconds: float = 60.0
    require_stop_loss: bool = True
    require_take_profit: bool = True
    max_leverage: float = 1.0
    deposit_level: int = 0
    withdrawal_level: int = 0
    max_deposit_per_transaction: float = 0.0
    max_deposit_daily: float = 0.0
    max_withdrawal_per_transaction: float = 0.0
    max_withdrawal_daily: float = 0.0
    max_pending_withdrawal: float = 0.0


@dataclass
class AccountPolicy:
    account_id: str
    role: str = "USER"
    state: str = "ACTIVE"
    trading_mode: str = "PAPER"
    limits: AccountLimits = field(default_factory=AccountLimits)
    daily_loss: float = 0.0
    drawdown_pct: float = 0.0
    open_positions: int = 0
    position_value: float = 0.0
    daily_deposit: float = 0.0
    daily_withdrawal: float = 0.0
    pending_withdrawal: float = 0.0
    _order_times: list[float] = field(default_factory=list, repr=False)

    def __post_init__(self) -> None:
        if not self.account_id:
            raise ValueError("account_id is required")
        if self.role not in ROLES:
            raise ValueError("invalid role")
        if self.state not in ACCOUNT_STATES:
            raise ValueError("invalid account state")
        if self.trading_mode not in TRADING_MODES:
            raise ValueError("invalid trading mode")

    def _prune(self, now: float) -> None:
        cutoff = now - self.limits.frequency_window_seconds
        self._order_times = [x for x in self._order_times if x >= cutoff]

    def admit_order(
        self,
        *,
        side: str,
        symbol: str,
        timeframe: str,
        quantity: float,
        price: float,
        risk_pct: float = 0.0,
        stop_loss: float | None = None,
        take_profit: float | None = None,
        current_position_value: float = 0.0,
        portfolio_exposure: float = 0.0,
        now: float | None = None,
        activation_gate: str = "LOCKED",
        live_trading: bool = False,
        reduce_only: bool = False,
    ) -> dict[str, object]:
        """Return an admission decision.  No execution occurs here."""
        if self.state != "ACTIVE":
            return self._block("ACCOUNT_NOT_ACTIVE")
        if side not in {"BUY", "SELL"} or quantity <= 0 or price <= 0:
            return self._block("INVALID_ORDER")
        if timeframe != self.limits.timeframe:
            return self._block("TIMEFRAME_NOT_ALLOWED")
        if self.limits.allowed_symbols and symbol not in self.limits.allowed_symbols:
            return self._block("SYMBOL_NOT_ALLOWED")
        value = quantity * price
        if value > self.limits.max_order_value:
            return self._block("ORDER_LIMIT")
        if not reduce_only and current_position_value + value > self.limits.max_position_value:
            return self._block("POSITION_LIMIT")
        if not reduce_only and portfolio_exposure + value > self.limits.max_position_value:
            return self._block("EXPOSURE_LIMIT")
        if not reduce_only and self.open_positions >= self.limits.max_open_positions:
            return self._block("OPEN_POSITION_LIMIT")
        if risk_pct < 0 or risk_pct > self.limits.max_risk_per_trade_pct:
            return self._block("RISK_PER_TRADE_LIMIT")
        if self.daily_loss > self.limits.max_daily_loss:
            return self._block("DAILY_LOSS_LIMIT")
        if self.drawdown_pct > self.limits.max_drawdown_pct:
            return self._block("DRAWDOWN_LIMIT")
        if not reduce_only and self.limits.require_stop_loss and stop_loss is None:
            return self._block("STOP_LOSS_REQUIRED")
        if not reduce_only and self.limits.require_take_profit and take_profit is None:
            return self._block("TAKE_PROFIT_REQUIRED")
        ts = time() if now is None else float(now)
        self._prune(ts)
        if len(self._order_times) >= self.limits.max_orders_per_window:
            return self._block("FREQUENCY_LIMIT")

        # This is intentionally independent of role.  No role can bypass it.
        if self.trading_mode == "LIVE":
            if activation_gate != "OPEN":
                return self._block("ACTIVATION_GATE_LOCKED")
            if not live_trading:
                return self._block("LIVE_TRADING_SAFE_OFF")

        self._order_times.append(ts)
        return {"status": "APPROVED", "account_id": self.account_id, "mode": self.trading_mode}

    def deposit(self, amount: float) -> dict[str, object]:
        if self.state != "ACTIVE":
            return self._block("ACCOUNT_NOT_ACTIVE")
        if amount <= 0:
            return self._block("INVALID_AMOUNT")
        if amount > self.limits.max_deposit_per_transaction:
            return self._block("DEPOSIT_TRANSACTION_LIMIT")
        if self.daily_deposit + amount > self.limits.max_deposit_daily:
            return self._block("DEPOSIT_DAILY_LIMIT")
        self.daily_deposit += amount
        return {"status": "APPROVED", "amount": amount, "operation": "DEPOSIT"}

    def withdraw(self, amount: float, available_balance: float) -> dict[str, object]:
        if self.state != "ACTIVE":
            return self._block("ACCOUNT_NOT_ACTIVE")
        if amount <= 0:
            return self._block("INVALID_AMOUNT")
        if amount > available_balance:
            return self._block("INSUFFICIENT_AVAILABLE_BALANCE")
        if amount > self.limits.max_withdrawal_per_transaction:
            return self._block("WITHDRAWAL_TRANSACTION_LIMIT")
        if self.daily_withdrawal + amount > self.limits.max_withdrawal_daily:
            return self._block("WITHDRAWAL_DAILY_LIMIT")
        if self.pending_withdrawal + amount > self.limits.max_pending_withdrawal:
            return self._block("PENDING_WITHDRAWAL_LIMIT")
        self.daily_withdrawal += amount
        self.pending_withdrawal += amount
        return {"status": "APPROVED", "amount": amount, "operation": "WITHDRAWAL"}

    @staticmethod
    def _block(reason: str) -> dict[str, object]:
        return {"status": "BLOCKED", "reason": reason}
