"""YaqobiTrad v2.02.99 — recovery attestation boundary."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json

from .audit import AuditLog
from .production_blockers import open_production_blockers

SCHEMA_VERSION = "v2.02.99"
ANCHOR_EVENT = "MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED"

@dataclass(frozen=True)
class MonitoringEvidenceAuditContinuityAnchorAttestationResult:
    valid: bool
    attestation_digest: str
    anchor_hash: str
    bound_audit_hash: str
    evidence_digest: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"

class MonitoringEvidenceAuditContinuityAnchorAttestation:
    """Read-only deterministic attestation over a verified recovery snapshot."""
    def attest(self, audit_path: str, *, expected_bound_audit_hash: str,
               expected_evidence_digest: str, expected_anchor_hash: str) -> MonitoringEvidenceAuditContinuityAnchorAttestationResult:
        audit = AuditLog(audit_path)
        if not audit.verify():
            raise ValueError("MONITORING_EVIDENCE_AUDIT_CONTINUITY_ATTESTATION_CHAIN_INVALID")
        if not open_production_blockers():
            raise ValueError("MONITORING_BLOCKER_STATE_UNEXPECTED")
        anchors = [e for e in audit.entries if e.get("event") == ANCHOR_EVENT]
        if len(anchors) != 1 or not audit.entries or audit.entries[-1] is not anchors[0]:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_CONTINUITY_ATTESTATION_ANCHOR_INVALID")
        anchor = anchors[0]
        data = anchor.get("data", {})
        if data.get("schema_version") != "v2.02.96":
            raise ValueError("MONITORING_EVIDENCE_AUDIT_CONTINUITY_ATTESTATION_SCHEMA_MISMATCH")
        if data.get("bound_audit_hash") != expected_bound_audit_hash:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_CONTINUITY_ATTESTATION_BOUND_HASH_MISMATCH")
        if data.get("evidence_digest") != expected_evidence_digest:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_CONTINUITY_ATTESTATION_DIGEST_MISMATCH")
        if anchor.get("hash") != expected_anchor_hash:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_CONTINUITY_ATTESTATION_ANCHOR_HASH_MISMATCH")
        if len(audit.entries) < 2 or data.get("continuity_hash") != audit.entries[-2].get("hash"):
            raise ValueError("MONITORING_EVIDENCE_AUDIT_CONTINUITY_ATTESTATION_CONTINUITY_MISMATCH")
        canonical = {"schema_version": SCHEMA_VERSION, "bound_audit_hash": expected_bound_audit_hash,
                     "evidence_digest": expected_evidence_digest, "anchor_hash": expected_anchor_hash,
                     "continuity_hash": data["continuity_hash"]}
        raw = json.dumps(canonical, sort_keys=True, separators=(",", ":")).encode()
        digest = hashlib.sha256(raw).hexdigest()
        return MonitoringEvidenceAuditContinuityAnchorAttestationResult(True, digest, expected_anchor_hash,
            expected_bound_audit_hash, expected_evidence_digest)
