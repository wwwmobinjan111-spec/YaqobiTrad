"""Central fail-closed enforcement boundary for YaqobiTrad v2.02.53."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Any


@dataclass(frozen=True)
class GateDecision:
    status: str
    action: str
    live_trading: str
    activation_gate: str
    fail_closed: str
    reason: str | None = None


class FailClosedEnforcementGate:
    """Normalize unsafe runtime states to a safe, non-live boundary.

    The gate never grants live-trading authorization. Paper actions can be
    allowed only when the supplied state is explicitly healthy; malformed or
    unsafe state is converted to a blocked, fail-closed decision.
    """

    SAFE_OFF = "SAFE_OFF"
    LOCKED = "LOCKED"
    ACTIVE = "ACTIVE"

    def evaluate(self, state: Mapping[str, Any] | None, *, action: str) -> GateDecision:
        if not isinstance(state, Mapping):
            return self._blocked("INVALID_STATE")
        if action not in {"PAPER", "LIVE"}:
            return self._blocked("INVALID_ACTION")

        live = state.get("live_trading")
        activation = state.get("activation_gate")
        fail_closed = state.get("fail_closed")

        if live != self.SAFE_OFF or activation != self.LOCKED or fail_closed != self.ACTIVE:
            return self._blocked("UNSAFE_STATE")

        if action == "LIVE":
            return self._blocked("LIVE_TRADING_DISABLED")

        return GateDecision(
            status="ALLOWED",
            action="PAPER",
            live_trading=self.SAFE_OFF,
            activation_gate=self.LOCKED,
            fail_closed=self.ACTIVE,
        )

    def enforce_failure(self, state: Mapping[str, Any] | None, *, reason: str) -> GateDecision:
        if not isinstance(reason, str) or not reason.strip():
            reason = "UNSPECIFIED_FAILURE"
        # Regardless of the incoming state, failure transitions to the safe boundary.
        return GateDecision(
            status="FAILED_SAFE",
            action="SHUTDOWN",
            live_trading=self.SAFE_OFF,
            activation_gate=self.LOCKED,
            fail_closed=self.ACTIVE,
            reason=reason,
        )

    def _blocked(self, reason: str) -> GateDecision:
        return GateDecision(
            status="BLOCKED",
            action="NONE",
            live_trading=self.SAFE_OFF,
            activation_gate=self.LOCKED,
            fail_closed=self.ACTIVE,
            reason=reason,
        )
