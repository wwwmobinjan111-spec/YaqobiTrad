"""v2.02.88 — Audit durability continuity verification gate.

Verifies that a durably persisted audit/evidence envelope can be recovered
repeatedly without state drift, that recovery is deterministic, and that the
recovered evidence remains bound to the original blocker/safety state.
This gate is evidence-only and never changes production blockers or unlocks
trading.
"""
from __future__ import annotations

from dataclasses import dataclass
from .audit_durability_evidence_gate import recover_audit_evidence, verify_recovered_evidence
from .evidence_integrity_attestation import EvidenceIntegrityAttestationGate
from .evidence_integrity_attestation_persistence import serialize_attestation
from .production_blockers import open_production_blockers


@dataclass(frozen=True)
class DurabilityContinuityDecision:
    valid: bool
    reason: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"


class DurabilityContinuityGate:
    """Require deterministic, drift-free repeated evidence recovery."""

    def __init__(self, original_gate: EvidenceIntegrityAttestationGate):
        self.original_gate = original_gate

    def verify(self, path: str, expected_audit, expected_attestation) -> DurabilityContinuityDecision:
        before_blockers = tuple(b.blocker_id for b in open_production_blockers())
        first, first_att = recover_audit_evidence(path)
        second, second_att = recover_audit_evidence(path)
        if not first.verify() or not second.verify():
            return DurabilityContinuityDecision(False, "RECOVERED_AUDIT_INVALID")
        if first.entries != expected_audit.entries or first.prev_hash != expected_audit.prev_hash:
            return DurabilityContinuityDecision(False, "RECOVERED_AUDIT_DRIFT")
        if second.entries != first.entries or second.prev_hash != first.prev_hash:
            return DurabilityContinuityDecision(False, "RECOVERY_NONDETERMINISTIC")
        if serialize_attestation(first_att) != serialize_attestation(expected_attestation):
            return DurabilityContinuityDecision(False, "RECOVERED_ATTESTATION_DRIFT")
        if serialize_attestation(second_att) != serialize_attestation(first_att):
            return DurabilityContinuityDecision(False, "RECOVERY_ATTESTATION_NONDETERMINISTIC")
        result, _, _ = verify_recovered_evidence(self.original_gate, path)
        if not result.valid:
            return DurabilityContinuityDecision(False, result.reason)
        after_blockers = tuple(b.blocker_id for b in open_production_blockers())
        if before_blockers != after_blockers:
            return DurabilityContinuityDecision(False, "PRODUCTION_BLOCKER_SET_CHANGED")
        return DurabilityContinuityDecision(True, "AUDIT_DURABILITY_CONTINUITY_VERIFIED")
