"""YaqobiTrad v2.02.238 — production blocker closure readiness boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT='v2.02.238'; PREDECESSOR='v2.02.237'

@dataclass(frozen=True)
class Result:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str='SAFE_OFF'
    activation_gate: str='LOCKED'
    fail_closed: str='ACTIVE'
    open_blocker_count: int=6
    certification: str='PENDING_REAL_PRODUCTION_RESULTS'
    closure_ready: bool=False
    real_production_evidence_required: bool=True

class ProductionBlockerClosureReadinessBoundaryV238:
    REQUIRED=tuple(b.blocker_id for b in open_production_blockers())

    @classmethod
    def verify(cls, checkpoint, *, production_evidence=()):
        req=('valid','checkpoint','predecessor','live_trading','activation_gate','fail_closed')
        if checkpoint is None or not all(hasattr(checkpoint,n) for n in req):
            raise ValueError('V202238_CHECKPOINT_INTERFACE_INVALID')
        if not checkpoint.valid or checkpoint.checkpoint!='v2.02.237' or checkpoint.predecessor!='v2.02.236':
            raise ValueError('V202238_LINEAGE_INVALID')
        if (checkpoint.live_trading,checkpoint.activation_gate,checkpoint.fail_closed)!=('SAFE_OFF','LOCKED','ACTIVE'):
            raise ValueError('V202238_SAFETY_STATE_INVALID')
        if tuple(b.blocker_id for b in open_production_blockers())!=cls.REQUIRED or len(cls.REQUIRED)!=6:
            raise ValueError('V202238_BLOCKER_SET_INVALID')
        evidence=tuple(production_evidence)
        if evidence and any(x not in cls.REQUIRED for x in evidence):
            raise ValueError('V202238_EVIDENCE_ID_INVALID')
        if len(set(evidence))!=len(evidence):
            raise ValueError('V202238_EVIDENCE_DUPLICATE')
        # Evidence collection alone never closes a blocker; closure requires real production proof.
        return Result(True,closure_ready=False,real_production_evidence_required=True)
