"""v2.02.68: fail-closed evidence release distribution boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .evidence_release_publication_gate import EvidenceReleasePublicationGate

@dataclass(frozen=True)
class EvidenceReleaseDistributionDecision:
    distributed: bool
    reason: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"

class EvidenceReleaseDistributionGate:
    """Distribute a published evidence release only after publication succeeds."""

    EVENT = "EVIDENCE_RELEASE_DISTRIBUTED"

    def __init__(self, audit, publication_gate: EvidenceReleasePublicationGate):
        self.audit = audit
        self.publication_gate = publication_gate
        self._distributed: dict[str, str] = {}

    def distribute(self, checkpoint) -> EvidenceReleaseDistributionDecision:
        if not self.audit.verify():
            self._distributed.pop(checkpoint.checkpoint, None)
            return EvidenceReleaseDistributionDecision(False, "AUDIT_CHAIN_INVALID")

        existing = self._distributed.get(checkpoint.checkpoint)
        if existing is not None:
            if not self.publication_gate.published:
                self._distributed.pop(checkpoint.checkpoint, None)
                return EvidenceReleaseDistributionDecision(False, "PUBLICATION_NOT_VERIFIED")
            return EvidenceReleaseDistributionDecision(True, "EVIDENCE_RELEASE_DISTRIBUTED")

        publication = self.publication_gate.publish(checkpoint)
        if not publication.published:
            self._distributed.pop(checkpoint.checkpoint, None)
            return EvidenceReleaseDistributionDecision(False, "PUBLICATION_NOT_VERIFIED")

        if not self.audit.verify():
            self._distributed.pop(checkpoint.checkpoint, None)
            return EvidenceReleaseDistributionDecision(False, "AUDIT_CHAIN_INVALID")

        head = self.audit.entries[-1]["hash"] if self.audit.entries else None
        self.audit.append(self.EVENT, {
            "checkpoint": checkpoint.checkpoint,
            "publication_audit_head": head,
        })
        self._distributed[checkpoint.checkpoint] = head or ""
        return EvidenceReleaseDistributionDecision(True, "EVIDENCE_RELEASE_DISTRIBUTED")

    @property
    def distributed(self) -> bool:
        return bool(self._distributed) and self.audit.verify()
