"""v2.02.64: fail-closed evidence release reconciliation boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .evidence_release_gate import EvidenceReleaseGate

@dataclass(frozen=True)
class EvidenceReconciliationDecision:
    reconciled: bool
    reason: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"

class EvidenceReleaseReconciliationGate:
    """Reconcile checkpoint, retention, authorization and audit-head state before release."""

    EVENT = "EVIDENCE_RELEASE_RECONCILED"

    def __init__(self, audit, retention_gate, release_gate: EvidenceReleaseGate):
        self.audit = audit
        self.retention_gate = retention_gate
        self.release_gate = release_gate
        self._reconciled: dict[str, str] = {}

    def reconcile(self, checkpoint) -> EvidenceReconciliationDecision:
        if not self.audit.verify():
            self._reconciled.pop(checkpoint.checkpoint, None)
            return EvidenceReconciliationDecision(False, "AUDIT_CHAIN_INVALID")
        if not self.retention_gate.release_allowed():
            self._reconciled.pop(checkpoint.checkpoint, None)
            return EvidenceReconciliationDecision(False, "RETENTION_NOT_VERIFIED")

        # Idempotent fast path: no new audit entry for an unchanged, already
        # reconciled checkpoint whose authorization remains valid.
        if checkpoint.checkpoint in self._reconciled and self.release_gate.authorized:
            return EvidenceReconciliationDecision(True, "EVIDENCE_RELEASE_RECONCILED")

        if not self.release_gate.authorize(checkpoint).allowed:
            self._reconciled.pop(checkpoint.checkpoint, None)
            return EvidenceReconciliationDecision(False, "RELEASE_AUTHORIZATION_STALE")

        head = self.audit.entries[-1]["hash"] if self.audit.entries else None
        self.audit.append(self.EVENT, {
            "checkpoint": checkpoint.checkpoint,
            "audit_head": head,
        })
        self._reconciled[checkpoint.checkpoint] = head or ""
        return EvidenceReconciliationDecision(True, "EVIDENCE_RELEASE_RECONCILED")

    @property
    def reconciled(self) -> bool:
        return bool(self._reconciled) and self.audit.verify()
