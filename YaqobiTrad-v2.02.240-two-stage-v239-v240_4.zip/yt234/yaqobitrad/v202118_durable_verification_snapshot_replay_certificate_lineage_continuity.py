"""YaqobiTrad v2.02.118 — durable verification snapshot replay certificate lineage continuity."""
from __future__ import annotations
import copy, hashlib, json
from dataclasses import dataclass
from .audit import AuditLog
from .production_blockers import open_production_blockers

CHECKPOINT="v2.02.118"
PREDECESSOR="v2.02.117"
ATTESTATION_EVENT="MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED"
ATTESTATION_SCHEMA="v2.02.99"

@dataclass(frozen=True)
class ReplayCertificateLineageContinuityResult:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"
    activation_gate: str="LOCKED"
    fail_closed: str="ACTIVE"
    open_blocker_count: int=6
    certification: str="PENDING_REAL_PRODUCTION_RESULTS"
    snapshot_digest: str=""
    lineage_digest: str=""

class DurableVerificationSnapshotReplayCertificateLineageContinuityV118:
    @staticmethod
    def _snapshot(a): return {"entries":copy.deepcopy(a.entries),"prev_hash":a.prev_hash}
    @staticmethod
    def _canonical(s): return json.dumps(s,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()
    @classmethod
    def _digest(cls,s): return hashlib.sha256(cls._canonical(s)).hexdigest()
    @classmethod
    def lineage_digest(cls, *, predecessor_certificate_digest: str, snapshot_digest: str) -> str:
        return cls._digest({"checkpoint":CHECKPOINT,"predecessor":PREDECESSOR,"predecessor_certificate_digest":predecessor_certificate_digest,"snapshot_digest":snapshot_digest})

    def verify(self,audit_path,*,expected_anchor_hash,expected_bound_audit_hash,expected_evidence_digest,expected_snapshot_digest,expected_predecessor_certificate_digest,expected_lineage_digest):
        a=AuditLog(audit_path)
        if not a.verify(): raise ValueError("V202118_AUDIT_CHAIN_INVALID")
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers): raise ValueError("V202118_BLOCKER_STATE_INVALID")
        anchors=[e for e in a.entries if e.get("event")==ATTESTATION_EVENT]
        if len(anchors)!=1 or not a.entries or a.entries[-1] is not anchors[0]: raise ValueError("V202118_TERMINAL_ATTESTATION_INVALID")
        anchor=anchors[0]; d=anchor.get("data",{})
        if d.get("schema_version")!=ATTESTATION_SCHEMA: raise ValueError("V202118_SCHEMA_INVALID")
        if anchor.get("hash")!=expected_anchor_hash: raise ValueError("V202118_ANCHOR_HASH_MISMATCH")
        if d.get("bound_audit_hash")!=expected_bound_audit_hash: raise ValueError("V202118_BOUND_AUDIT_HASH_MISMATCH")
        if d.get("evidence_digest")!=expected_evidence_digest: raise ValueError("V202118_EVIDENCE_DIGEST_MISMATCH")
        if len(a.entries)<2 or d.get("continuity_hash")!=a.entries[-2].get("hash"): raise ValueError("V202118_CONTINUITY_LINK_INVALID")
        snap=self._snapshot(a); digest=self._digest(snap)
        if digest!=expected_snapshot_digest: raise ValueError("V202118_SNAPSHOT_DIGEST_MISMATCH")
        replay=json.loads(self._canonical(snap).decode())
        digests=[self._digest(replay)]
        for _ in range(3):
            replay=json.loads(self._canonical(replay).decode()); digests.append(self._digest(replay))
        if any(x!=digest for x in digests): raise ValueError("V202118_REPLAY_NONDETERMINISTIC")
        provenance={"checkpoint":CHECKPOINT,"predecessor":PREDECESSOR,"snapshot_digest":digest,"replay_digest":digests[-1]}
        if provenance["snapshot_digest"]!=provenance["replay_digest"]: raise ValueError("V202118_REPLAY_PROVENANCE_MISMATCH")
        if self._digest(provenance)!=self._digest(json.loads(self._canonical(provenance).decode())): raise ValueError("V202118_PROVENANCE_NONCANONICAL")
        fresh=AuditLog(audit_path)
        if self._digest(self._snapshot(fresh))!=digest: raise ValueError("V202118_RELOAD_DIGEST_MISMATCH")
        replay["entries"][-1]["data"]["evidence_digest"]="MUTATION_SENTINEL"
        if a.entries[-1]["data"].get("evidence_digest")!=expected_evidence_digest: raise ValueError("V202118_REPLAY_ISOLATION_FAILURE")
        if self._digest(self._snapshot(a))!=digest: raise ValueError("V202118_SOURCE_SNAPSHOT_MUTATED")
        if not expected_predecessor_certificate_digest: raise ValueError("V202118_PREDECESSOR_CERTIFICATE_MISSING")
        lineage=self.lineage_digest(predecessor_certificate_digest=expected_predecessor_certificate_digest,snapshot_digest=digest)
        if lineage!=expected_lineage_digest: raise ValueError("V202118_LINEAGE_DIGEST_MISMATCH")
        lineage_roundtrip=json.loads(self._canonical({"checkpoint":CHECKPOINT,"predecessor":PREDECESSOR,"predecessor_certificate_digest":expected_predecessor_certificate_digest,"snapshot_digest":digest}).decode())
        if self.lineage_digest(predecessor_certificate_digest=lineage_roundtrip["predecessor_certificate_digest"],snapshot_digest=lineage_roundtrip["snapshot_digest"])!=lineage: raise ValueError("V202118_LINEAGE_ROUNDTRIP_MISMATCH")
        certificate={"checkpoint":CHECKPOINT,"predecessor":PREDECESSOR,"snapshot_digest":digest,"replay_digest":digests[-1],"lineage_digest":lineage,"status":"VALID"}
        cd=self._digest(certificate)
        if self._digest(json.loads(self._canonical(certificate).decode()))!=cd: raise ValueError("V202118_CERTIFICATE_CANONICAL_MISMATCH")
        return ReplayCertificateLineageContinuityResult(True,snapshot_digest=digest,lineage_digest=lineage)
