"""Release/activation boundary checks for YaqobiTrad v2.02.17."""
from __future__ import annotations

from .blocking import blocking_issues
from .evidence import evidence_integrity
from .failsafe import FailClosed
from .security_blocking import security_blocks_activation
from .dependency_gate import dependency_blocks_activation
from .external_provider_gate import external_provider_blocks_activation


def release_gate_state(audit_ok: bool = True) -> dict[str, str]:
    blockers = [i for i in blocking_issues() if i.blocks_activation and i.status == "OPEN"]
    fail_closed = FailClosed()
    if (blockers or security_blocks_activation() or dependency_blocks_activation()
            or external_provider_blocks_activation() or not audit_ok):
        return {
            "state": "BLOCKED",
            "live_trading": "SAFE_OFF",
            "activation_gate": "LOCKED",
            "fail_closed": "ACTIVE" if fail_closed.safe else "INACTIVE",
        }
    return {
        "state": "READY_FOR_REVIEW",
        "live_trading": "SAFE_OFF",
        "activation_gate": "LOCKED",
        "fail_closed": "ACTIVE",
    }


def release_gate_from_audit(audit) -> dict[str, str]:
    return release_gate_state(evidence_integrity(audit))
