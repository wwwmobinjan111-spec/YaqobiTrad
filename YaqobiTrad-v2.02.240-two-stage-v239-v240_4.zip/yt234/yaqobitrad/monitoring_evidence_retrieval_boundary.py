"""YaqobiTrad v2.02.93 — monitoring evidence retrieval/recovery boundary.

Source-level boundary only. Retrieval is read-only: a retained monitoring
record is accepted only after envelope digest, schema, retention policy, and
monitoring freshness/health are re-verified. Any failure is fail-closed.
This module never changes production blockers or activation state.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Mapping

from .evidence_retention import RetentionPolicy, retention_blocks_activation
from .monitoring_evidence_boundary import MonitoringEvidenceBoundary
from .production_blockers import open_production_blockers

SCHEMA_VERSION = "v2.02.93"
_REQUIRED = {"schema_version", "evidence", "retention", "envelope_digest"}


def _canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def _digest(value: object) -> str:
    return hashlib.sha256(_canonical(value)).hexdigest()


@dataclass(frozen=True)
class MonitoringEvidenceRetrievalResult:
    valid: bool
    reason: str
    evidence: dict[str, Any]
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"


class MonitoringEvidenceRetrievalBoundary:
    """Re-verify retained monitoring evidence without mutating the artifact."""

    def __init__(self, monitoring_boundary: MonitoringEvidenceBoundary):
        self.monitoring_boundary = monitoring_boundary

    @staticmethod
    def envelope(evidence: Mapping[str, Any], policy: RetentionPolicy) -> dict[str, Any]:
        if not isinstance(evidence, Mapping):
            raise ValueError("MONITORING_EVIDENCE_INVALID")
        body = {
            "schema_version": SCHEMA_VERSION,
            "evidence": dict(evidence),
            "retention": {
                "minimum_days": policy.minimum_days,
                "immutable": policy.immutable,
                "remote": policy.remote,
                "verified": policy.verified,
            },
        }
        return {**body, "envelope_digest": _digest(body)}

    def retrieve(
        self,
        path: str,
        *,
        now: float,
        max_age: float,
    ) -> MonitoringEvidenceRetrievalResult:
        before = _read_bytes(path)
        try:
            payload = json.loads(before.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("MONITORING_EVIDENCE_RETRIEVAL_INVALID") from exc

        if not isinstance(payload, dict) or set(payload) != _REQUIRED:
            raise ValueError("MONITORING_EVIDENCE_RETRIEVAL_SCHEMA_INVALID")
        if payload["schema_version"] != SCHEMA_VERSION:
            raise ValueError("MONITORING_EVIDENCE_RETRIEVAL_VERSION_INVALID")

        body = {
            "schema_version": payload["schema_version"],
            "evidence": payload["evidence"],
            "retention": payload["retention"],
        }
        if _digest(body) != payload["envelope_digest"]:
            raise ValueError("MONITORING_EVIDENCE_RETRIEVAL_DIGEST_MISMATCH")

        retention = payload["retention"]
        if not isinstance(retention, dict) or set(retention) != {
            "minimum_days", "immutable", "remote", "verified"
        }:
            raise ValueError("MONITORING_RETENTION_POLICY_INVALID")
        try:
            policy = RetentionPolicy(**retention)
        except (TypeError, ValueError) as exc:
            raise ValueError("MONITORING_RETENTION_POLICY_INVALID") from exc
        if retention_blocks_activation(policy):
            raise ValueError("MONITORING_RETENTION_NOT_VERIFIED")

        self.monitoring_boundary.verify(payload["evidence"], now=now, max_age=max_age)
        if not open_production_blockers():
            raise ValueError("MONITORING_BLOCKER_STATE_UNEXPECTED")

        after = _read_bytes(path)
        if before != after:
            raise ValueError("MONITORING_EVIDENCE_MUTATED_DURING_RETRIEVAL")

        return MonitoringEvidenceRetrievalResult(
            valid=True,
            reason="MONITORING_EVIDENCE_RETRIEVAL_RECOVERY_VERIFIED",
            evidence=dict(payload["evidence"]),
        )


def _read_bytes(path: str) -> bytes:
    try:
        with open(path, "rb") as f:
            return f.read()
    except OSError as exc:
        raise ValueError("MONITORING_EVIDENCE_RETRIEVAL_UNAVAILABLE") from exc
