"""Deterministic execution failure/recovery hardening for YaqobiTrad.

Recovery is fail-closed: an ambiguous provider result is reconciled before any
retry. Retries are bounded and reuse the exact client_order_id, so recovery
cannot create a duplicate order.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any


class RecoveryError(RuntimeError):
    pass


class AmbiguousExecutionError(RecoveryError):
    """Provider outcome is unknown; reconciliation is mandatory before retry."""


class PermanentExecutionError(RecoveryError):
    """Provider rejected execution in a non-retryable way."""


@dataclass(frozen=True)
class RecoveryResult:
    status: str
    client_order_id: str
    provider_order_id: str | None
    attempts: int
    reconciled: bool
    reason: str | None = None
    audit: tuple[str, ...] = field(default_factory=tuple)


class ExecutionRecoveryManager:
    def __init__(self, provider: Any, *, max_retries: int = 1):
        if max_retries < 0:
            raise ValueError("max_retries must be non-negative")
        self.provider = provider
        self.max_retries = max_retries

    def execute(self, client_order_id: str, side: str, quantity: float, price: float) -> RecoveryResult:
        if not client_order_id:
            raise ValueError("CLIENT_ORDER_ID_REQUIRED")
        audit: list[str] = ["RECOVERY_START"]
        attempts = 0
        reconciled = False

        while True:
            try:
                order = self.provider.submit(client_order_id, side, quantity, price)
                audit.append("SUBMIT_SUCCESS")
                return RecoveryResult("EXECUTED", client_order_id, order.provider_order_id,
                                      attempts, reconciled, audit=tuple(audit))
            except AmbiguousExecutionError:
                audit.append("AMBIGUOUS_RESULT")
                existing = self.provider.reconcile_order(client_order_id)
                reconciled = existing is not None
                audit.append("RECONCILE_FOUND" if reconciled else "RECONCILE_NOT_FOUND")
                if existing is not None:
                    return RecoveryResult("RECOVERED", client_order_id,
                                          existing.provider_order_id, attempts,
                                          True, audit=tuple(audit))
                if attempts >= self.max_retries:
                    audit.append("RETRY_EXHAUSTED")
                    return RecoveryResult("BLOCKED", client_order_id, None, attempts,
                                          False, "AMBIGUOUS_UNRESOLVED", tuple(audit))
                attempts += 1
                audit.append("RETRY")
            except PermanentExecutionError as exc:
                audit.append("PERMANENT_FAILURE")
                return RecoveryResult("BLOCKED", client_order_id, None, attempts,
                                      reconciled, str(exc), tuple(audit))
            except Exception as exc:
                # Unknown provider failures are treated as ambiguous and never
                # retried blindly. Reconcile first, then bounded retry.
                audit.append("UNKNOWN_PROVIDER_ERROR")
                existing = self.provider.reconcile_order(client_order_id)
                reconciled = existing is not None
                audit.append("RECONCILE_FOUND" if reconciled else "RECONCILE_NOT_FOUND")
                if existing is not None:
                    return RecoveryResult("RECOVERED", client_order_id,
                                          existing.provider_order_id, attempts,
                                          True, audit=tuple(audit))
                if attempts >= self.max_retries:
                    audit.append("RETRY_EXHAUSTED")
                    return RecoveryResult("BLOCKED", client_order_id, None, attempts,
                                          False, f"AMBIGUOUS:{type(exc).__name__}", tuple(audit))
                attempts += 1
                audit.append("RETRY")
