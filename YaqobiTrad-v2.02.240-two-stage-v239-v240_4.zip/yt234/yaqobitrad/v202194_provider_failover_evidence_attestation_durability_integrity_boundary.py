"""YaqobiTrad v2.02.194 — provider failover evidence attestation durability integrity boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers
CHECKPOINT="v2.02.194"; PREDECESSOR="v2.02.193"
@dataclass(frozen=True)
class ProviderFailoverEvidenceAttestationDurabilityIntegrityBoundaryResult:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"
    activation_gate: str="LOCKED"
    fail_closed: str="ACTIVE"
    open_blocker_count: int=6
    certification: str="PENDING_REAL_PRODUCTION_RESULTS"
    recovery_ref: str=""; provenance_ref: str=""; attestation_ref: str=""; integrity_ref: str=""
class ProviderFailoverEvidenceAttestationDurabilityIntegrityBoundaryV194:
    @staticmethod
    def _ref(value: str, field: str)->str:
        if not isinstance(value,str) or not value.strip() or not value.startswith("evidence://"):
            raise ValueError(f"V202194_{field.upper()}_INVALID")
        if "=" in value or any(t in value.upper() for t in ("TOKEN","SECRET","PASSWORD","PRIVATE_KEY")):
            raise ValueError(f"V202194_{field.upper()}_SECRET_OR_ASSIGNMENT_INVALID")
        return value
    @classmethod
    def verify(cls,state,*,recovery_ref,provenance_ref,attestation_ref,integrity_ref):
        if state is None or not all(hasattr(state,n) for n in ("activation_gate","live_trading","fail_closed")):
            raise ValueError("V202194_STATE_INTERFACE_INVALID")
        if (state.activation_gate,state.live_trading,state.fail_closed)!=("LOCKED","SAFE_OFF","ACTIVE"):
            raise ValueError("V202194_SAFETY_STATE_INVALID")
        refs={k:cls._ref(v,k) for k,v in {"recovery_ref":recovery_ref,"provenance_ref":provenance_ref,"attestation_ref":attestation_ref,"integrity_ref":integrity_ref}.items()}
        if len(set(refs.values()))!=4: raise ValueError("V202194_REFERENCE_REUSE_INVALID")
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers): raise ValueError("V202194_BLOCKER_STATE_INVALID")
        return ProviderFailoverEvidenceAttestationDurabilityIntegrityBoundaryResult(True,**refs)
