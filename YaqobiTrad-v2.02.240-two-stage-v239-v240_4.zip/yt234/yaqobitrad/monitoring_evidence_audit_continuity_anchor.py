"""YaqobiTrad v2.02.96 — monitoring evidence audit continuity anchor.

Extends v2.02.95 by anchoring the verified continuity record to the durable
hash chain. The anchor can only be created when the prior continuity record
references the exact bound audit hash and evidence digest. Duplicate anchors
and tampered chains fail closed.
"""
from __future__ import annotations

from dataclasses import dataclass

from .audit import AuditLog
from .production_blockers import open_production_blockers

SCHEMA_VERSION = "v2.02.96"
EVENT = "MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED"
CONTINUITY_EVENT = "MONITORING_EVIDENCE_RETRIEVAL_AUDIT_CONTINUITY_VERIFIED"
BIND_EVENT = "MONITORING_EVIDENCE_RETRIEVAL_VERIFIED"


@dataclass(frozen=True)
class MonitoringEvidenceAuditContinuityAnchorResult:
    valid: bool
    reason: str
    bound_audit_hash: str
    evidence_digest: str
    anchor_hash: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"


class MonitoringEvidenceAuditContinuityAnchor:
    """Create and verify a single durable anchor for v2.02.95 continuity."""

    def anchor(
        self,
        audit_path: str,
        *,
        expected_bound_audit_hash: str,
        expected_evidence_digest: str,
    ) -> MonitoringEvidenceAuditContinuityAnchorResult:
        audit = AuditLog(audit_path)
        if not audit.verify():
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_CHAIN_INVALID")
        if len(audit.entries) < 2:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_HISTORY_INCOMPLETE")

        if any(
            entry.get("event") == EVENT
            and entry.get("data", {}).get("bound_audit_hash") == expected_bound_audit_hash
            for entry in audit.entries
        ):
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_DUPLICATE")

        bind = audit.entries[-2]
        continuity = audit.entries[-1]
        if bind.get("event") != BIND_EVENT:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_BIND_EVENT_MISSING")
        if continuity.get("event") != CONTINUITY_EVENT:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_CONTINUITY_EVENT_MISSING")

        actual_bound = bind.get("hash")
        actual_digest = bind.get("data", {}).get("evidence_digest")
        if actual_bound != expected_bound_audit_hash:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_BOUND_HASH_MISMATCH")
        if actual_digest != expected_evidence_digest:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_DIGEST_MISMATCH")
        if continuity.get("data", {}).get("bound_audit_hash") != actual_bound:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_CONTINUITY_HASH_MISMATCH")
        if continuity.get("data", {}).get("evidence_digest") != actual_digest:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_CONTINUITY_DIGEST_MISMATCH")
        if continuity.get("prev_hash") != actual_bound:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_PREV_HASH_MISMATCH")

        if not open_production_blockers():
            raise ValueError("MONITORING_BLOCKER_STATE_UNEXPECTED")

        anchor = audit.append(
            EVENT,
            {
                "schema_version": SCHEMA_VERSION,
                "bound_audit_hash": actual_bound,
                "evidence_digest": actual_digest,
                "continuity_hash": continuity.get("hash"),
            },
        )
        if not audit.verify():
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_CHAIN_INVALID_AFTER_APPEND")

        restored = AuditLog(audit_path)
        if not restored.verify() or restored.entries[-1].get("hash") != anchor.get("hash"):
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_RELOAD_INVALID")

        return MonitoringEvidenceAuditContinuityAnchorResult(
            valid=True,
            reason="MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED",
            bound_audit_hash=actual_bound,
            evidence_digest=actual_digest,
            anchor_hash=anchor["hash"],
        )
