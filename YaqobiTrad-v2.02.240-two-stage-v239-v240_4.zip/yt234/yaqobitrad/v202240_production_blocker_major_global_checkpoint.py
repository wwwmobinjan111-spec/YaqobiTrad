"""YaqobiTrad v2.02.240 — MAJOR GLOBAL CHECKPOINT for production blockers."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT='v2.02.240'; PREDECESSOR='v2.02.239'; MAJOR_GLOBAL_CHECKPOINT=True

@dataclass(frozen=True)
class Result:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str='SAFE_OFF'
    activation_gate: str='LOCKED'
    fail_closed: str='ACTIVE'
    open_blocker_count: int=6
    certification: str='PENDING_REAL_PRODUCTION_RESULTS'
    major_global_checkpoint: bool=True
    closure_authorized: bool=False

class ProductionBlockerMajorGlobalCheckpointV240:
    REQUIRED=tuple(b.blocker_id for b in open_production_blockers())

    @classmethod
    def verify(cls, checkpoint, *, evidence_ids=()):
        if checkpoint is None or not getattr(checkpoint,'valid',False):
            raise ValueError('V202240_CHECKPOINT_INVALID')
        if checkpoint.checkpoint!='v2.02.239' or checkpoint.predecessor!='v2.02.238':
            raise ValueError('V202240_LINEAGE_INVALID')
        if (checkpoint.live_trading,checkpoint.activation_gate,checkpoint.fail_closed)!=('SAFE_OFF','LOCKED','ACTIVE'):
            raise ValueError('V202240_SAFETY_STATE_INVALID')
        if len(cls.REQUIRED)!=6 or any(b.state!='OPEN' for b in open_production_blockers()):
            raise ValueError('V202240_BLOCKER_STATE_INVALID')
        evidence=tuple(evidence_ids)
        if any(x not in cls.REQUIRED for x in evidence):
            raise ValueError('V202240_EVIDENCE_ID_INVALID')
        if len(set(evidence)) != len(evidence):
            raise ValueError('V202240_EVIDENCE_DUPLICATE')
        return Result(True,closure_authorized=False)
