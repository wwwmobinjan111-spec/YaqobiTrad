"""YaqobiTrad v2.02.125 — production monitoring boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT="v2.02.125"
PREDECESSOR="v2.02.124"

@dataclass(frozen=True)
class MonitoringBoundaryResult:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"
    activation_gate: str="LOCKED"
    fail_closed: str="ACTIVE"
    monitoring_blocker: str="OPEN"
    open_blocker_count: int=6
    certification: str="PENDING_REAL_PRODUCTION_RESULTS"

class ProductionMonitoringBoundaryV125:
    @staticmethod
    def verify(monitor):
        if monitor is None or not all(hasattr(monitor,n) for n in ("record","health","snapshot")):
            raise ValueError("V202125_MONITORING_INTERFACE_INVALID")
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers):
            raise ValueError("V202125_BLOCKER_STATE_INVALID")
        return MonitoringBoundaryResult(True)
