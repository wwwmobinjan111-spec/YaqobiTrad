"""YaqobiTrad v2.02.128 — release readiness boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT="v2.02.128"
PREDECESSOR="v2.02.127"

@dataclass(frozen=True)
class ReleaseReadinessResult:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"
    activation_gate: str="LOCKED"
    fail_closed: str="ACTIVE"
    open_blocker_count: int=6
    certification: str="PENDING_REAL_PRODUCTION_RESULTS"

class ReleaseReadinessBoundaryV128:
    @staticmethod
    def verify(release_gate):
        if release_gate is None or not all(hasattr(release_gate,n) for n in ("validate","is_ready")):
            raise ValueError("V202128_RELEASE_GATE_INTERFACE_INVALID")
        if release_gate.is_ready():
            raise ValueError("V202128_READY_REQUIRES_PRODUCTION_EVIDENCE")
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers):
            raise ValueError("V202128_BLOCKER_STATE_INVALID")
        return ReleaseReadinessResult(True)
