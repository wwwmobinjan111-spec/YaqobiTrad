"""v2.02.67: fail-closed evidence release publication boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .evidence_release_commitment_gate import EvidenceReleaseCommitmentGate

@dataclass(frozen=True)
class EvidenceReleasePublicationDecision:
    published: bool
    reason: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"

class EvidenceReleasePublicationGate:
    """Publish an evidence release only after successful commitment."""

    EVENT = "EVIDENCE_RELEASE_PUBLISHED"

    def __init__(self, audit, commitment_gate: EvidenceReleaseCommitmentGate):
        self.audit = audit
        self.commitment_gate = commitment_gate
        self._published: dict[str, str] = {}

    def publish(self, checkpoint) -> EvidenceReleasePublicationDecision:
        if not self.audit.verify():
            self._published.pop(checkpoint.checkpoint, None)
            return EvidenceReleasePublicationDecision(False, "AUDIT_CHAIN_INVALID")

        existing = self._published.get(checkpoint.checkpoint)
        if existing is not None:
            if not self.commitment_gate.committed:
                self._published.pop(checkpoint.checkpoint, None)
                return EvidenceReleasePublicationDecision(False, "COMMITMENT_NOT_VERIFIED")
            return EvidenceReleasePublicationDecision(True, "EVIDENCE_RELEASE_PUBLISHED")

        commitment = self.commitment_gate.commit(checkpoint)
        if not commitment.committed:
            self._published.pop(checkpoint.checkpoint, None)
            return EvidenceReleasePublicationDecision(False, "COMMITMENT_NOT_VERIFIED")

        if not self.audit.verify():
            self._published.pop(checkpoint.checkpoint, None)
            return EvidenceReleasePublicationDecision(False, "AUDIT_CHAIN_INVALID")

        head = self.audit.entries[-1]["hash"] if self.audit.entries else None
        self.audit.append(self.EVENT, {
            "checkpoint": checkpoint.checkpoint,
            "commitment_audit_head": head,
        })
        self._published[checkpoint.checkpoint] = head or ""
        return EvidenceReleasePublicationDecision(True, "EVIDENCE_RELEASE_PUBLISHED")

    @property
    def published(self) -> bool:
        return bool(self._published) and self.audit.verify()
