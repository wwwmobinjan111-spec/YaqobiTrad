from dataclasses import dataclass

@dataclass(frozen=True)
class ProductionBlocker:
    blocker_id: str
    state: str = "OPEN"


PRODUCTION_BLOCKERS = (
    ProductionBlocker("production_provider_execution"),
    ProductionBlocker("production_auth_authorization"),
    ProductionBlocker("production_secret_management"),
    ProductionBlocker("production_portfolio_persistence"),
    ProductionBlocker("production_monitoring"),
    ProductionBlocker("live_provider_e2e"),
)


def open_production_blockers() -> tuple[ProductionBlocker, ...]:
    return tuple(b for b in PRODUCTION_BLOCKERS if b.state == "OPEN")
