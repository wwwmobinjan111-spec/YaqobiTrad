"""YaqobiTrad v2.02.100 — MAJOR GLOBAL CHECKPOINT integrity gate."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path

from .audit import AuditLog
from .production_blockers import open_production_blockers

CHECKPOINT = "v2.02.100"
PREDECESSOR = "v2.02.99"
ATTESTATION_SCHEMA = "v2.02.99"
ATTESTATION_EVENT = "MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED"

@dataclass(frozen=True)
class MajorGlobalCheckpointResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    open_blocker_count: int = 6
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"
    chain_digest: str = ""

class MajorGlobalCheckpoint:
    """Read-only consolidation gate for the v2.02.99 verified state."""
    def verify(self, audit_path: str, *, expected_anchor_hash: str,
               expected_bound_audit_hash: str, expected_evidence_digest: str) -> MajorGlobalCheckpointResult:
        audit = AuditLog(audit_path)
        if not audit.verify():
            raise ValueError("V202100_AUDIT_CHAIN_INVALID")
        blockers = open_production_blockers()
        if len(blockers) != 6 or any(b.state != "OPEN" for b in blockers):
            raise ValueError("V202100_BLOCKER_STATE_INVALID")
        anchors = [e for e in audit.entries if e.get("event") == ATTESTATION_EVENT]
        if len(anchors) != 1 or not audit.entries or audit.entries[-1] is not anchors[0]:
            raise ValueError("V202100_TERMINAL_ATTESTATION_INVALID")
        anchor = anchors[0]
        data = anchor.get("data", {})
        if data.get("schema_version") != ATTESTATION_SCHEMA:
            raise ValueError("V202100_PREDECESSOR_SCHEMA_INVALID")
        if anchor.get("hash") != expected_anchor_hash:
            raise ValueError("V202100_ANCHOR_HASH_MISMATCH")
        if data.get("bound_audit_hash") != expected_bound_audit_hash:
            raise ValueError("V202100_BOUND_AUDIT_HASH_MISMATCH")
        if data.get("evidence_digest") != expected_evidence_digest:
            raise ValueError("V202100_EVIDENCE_DIGEST_MISMATCH")
        if len(audit.entries) < 2 or data.get("continuity_hash") != audit.entries[-2].get("hash"):
            raise ValueError("V202100_CONTINUITY_LINK_INVALID")
        canonical = {
            "checkpoint": CHECKPOINT,
            "predecessor": PREDECESSOR,
            "anchor_hash": expected_anchor_hash,
            "bound_audit_hash": expected_bound_audit_hash,
            "evidence_digest": expected_evidence_digest,
            "continuity_hash": data["continuity_hash"],
            "blockers": [b.blocker_id for b in blockers],
            "safety": {"live_trading":"SAFE_OFF","activation_gate":"LOCKED","fail_closed":"ACTIVE"},
            "certification": "PENDING_REAL_PRODUCTION_RESULTS",
        }
        digest = hashlib.sha256(json.dumps(canonical, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        return MajorGlobalCheckpointResult(True, chain_digest=digest)
