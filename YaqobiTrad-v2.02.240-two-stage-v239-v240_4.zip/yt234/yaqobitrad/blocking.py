from dataclasses import dataclass
from typing import Literal

Status = Literal["OPEN", "RESOLVED"]

@dataclass(frozen=True)
class BlockingIssue:
    issue_id: str
    area: str
    description: str
    status: Status
    blocks_activation: bool = True

# These are evidence-based gaps in the reconstructed baseline, not claims
# about an unavailable historical production source.
BLOCKING_ISSUES = (
    BlockingIssue(
        "BLK-001", "source", "Historical production source is unavailable; "
        "this baseline cannot prove equivalence to the historical platform.",
        "OPEN",
    ),
    BlockingIssue(
        "BLK-002", "provider", "Real provider adapter exists, but successful external E2E has not been verified "
        "in the execution environment.",
        "OPEN",
    ),
    BlockingIssue(
        "BLK-003", "signal", "Production signal-generation module and replay validation are implemented and tested.",
        "RESOLVED",
    ),
    BlockingIssue(
        "BLK-004", "strategy", "Production strategy module and replay validation are implemented and tested.",
        "RESOLVED",
    ),
    BlockingIssue(
        "BLK-005", "portfolio", "Persistent portfolio/accounting, recovery, and reconciliation are implemented and tested.",
        "RESOLVED",
    ),
    BlockingIssue(
        "BLK-006", "integration", "No end-to-end live-provider integration test "
        "has been executed.",
        "OPEN",
    ),
)

def blocking_issues() -> tuple[BlockingIssue, ...]:
    return BLOCKING_ISSUES

def activation_blocked() -> bool:
    return any(i.blocks_activation and i.status == "OPEN" for i in BLOCKING_ISSUES)
