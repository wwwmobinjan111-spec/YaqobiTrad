"""YaqobiTrad v2.02.97 — monitoring evidence audit continuity anchor verification.

Provides a read-only verification boundary for the durable v2.02.96 anchor.
No audit mutation is performed; malformed, missing, duplicated, or mismatched
anchor state fails closed.
"""
from __future__ import annotations

from dataclasses import dataclass

from .audit import AuditLog
from .production_blockers import open_production_blockers

SCHEMA_VERSION = "v2.02.97"
ANCHOR_EVENT = "MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED"


@dataclass(frozen=True)
class MonitoringEvidenceAuditContinuityAnchorVerificationResult:
    valid: bool
    reason: str
    bound_audit_hash: str
    evidence_digest: str
    anchor_hash: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"


class MonitoringEvidenceAuditContinuityAnchorVerification:
    """Read-only verification of the persisted v2.02.96 continuity anchor."""

    def verify(
        self,
        audit_path: str,
        *,
        expected_bound_audit_hash: str,
        expected_evidence_digest: str,
        expected_anchor_hash: str | None = None,
    ) -> MonitoringEvidenceAuditContinuityAnchorVerificationResult:
        audit = AuditLog(audit_path)
        if not audit.verify():
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_VERIFICATION_CHAIN_INVALID")
        if not open_production_blockers():
            raise ValueError("MONITORING_BLOCKER_STATE_UNEXPECTED")

        anchors = [e for e in audit.entries if e.get("event") == ANCHOR_EVENT]
        if len(anchors) != 1:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_VERIFICATION_CARDINALITY_INVALID")
        anchor = anchors[0]
        if audit.entries[-1] is not anchor:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_VERIFICATION_NOT_TERMINAL")

        data = anchor.get("data", {})
        if data.get("schema_version") != "v2.02.96":
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_VERIFICATION_SCHEMA_MISMATCH")
        if data.get("bound_audit_hash") != expected_bound_audit_hash:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_VERIFICATION_BOUND_HASH_MISMATCH")
        if data.get("evidence_digest") != expected_evidence_digest:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_VERIFICATION_DIGEST_MISMATCH")
        if expected_anchor_hash is not None and anchor.get("hash") != expected_anchor_hash:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_VERIFICATION_ANCHOR_HASH_MISMATCH")
        if data.get("continuity_hash") != audit.entries[-2].get("hash"):
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_VERIFICATION_CONTINUITY_LINK_MISMATCH")
        if anchor.get("prev_hash") != audit.entries[-2].get("hash"):
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_VERIFICATION_PREV_HASH_MISMATCH")

        before = list(audit.entries)
        restored = AuditLog(audit_path)
        if restored.entries != before or not restored.verify():
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_VERIFICATION_RELOAD_INVALID")
        if restored.entries != before:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_VERIFICATION_MUTATED")

        return MonitoringEvidenceAuditContinuityAnchorVerificationResult(
            valid=True,
            reason="MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHOR_VERIFIED",
            bound_audit_hash=expected_bound_audit_hash,
            evidence_digest=expected_evidence_digest,
            anchor_hash=anchor["hash"],
        )
