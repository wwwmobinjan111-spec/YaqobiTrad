"""YaqobiTrad v2.02.139 — key rotation and revocation boundary.

Source-level boundary only. It validates non-secret rotation/revocation
references and preserves the production fail-closed state. It does not
perform real key rotation, revoke production credentials, or close the
production secret-management blocker.
"""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT = "v2.02.139"
PREDECESSOR = "v2.02.138"

@dataclass(frozen=True)
class KeyRotationRevocationBoundaryResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    open_blocker_count: int = 6
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"

class KeyRotationRevocationBoundaryV139:
    @staticmethod
    def verify(state, *, rotation_ref: str | None = None,
               revocation_ref: str | None = None) -> KeyRotationRevocationBoundaryResult:
        if state is None or not all(hasattr(state, n) for n in ("activation_gate", "live_trading", "fail_closed")):
            raise ValueError("V202139_STATE_INTERFACE_INVALID")
        if state.activation_gate != "LOCKED" or state.live_trading != "SAFE_OFF" or state.fail_closed != "ACTIVE":
            raise ValueError("V202139_SAFETY_STATE_INVALID")
        for name, value in (("rotation_ref", rotation_ref), ("revocation_ref", revocation_ref)):
            if value is not None:
                if not isinstance(value, str) or not value.strip() or "=" in value or len(value.strip()) < 3:
                    raise ValueError(f"V202139_{name.upper()}_INVALID")
        blockers = open_production_blockers()
        if len(blockers) != 6 or any(b.state != "OPEN" for b in blockers):
            raise ValueError("V202139_BLOCKER_STATE_INVALID")
        return KeyRotationRevocationBoundaryResult(True)
