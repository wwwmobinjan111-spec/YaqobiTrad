"""Runtime activation-boundary adapter for YaqobiTrad v2.02.54.

The adapter binds the runtime configuration to the centralized fail-closed
engine. It does not grant live authorization; LIVE is always denied by the
underlying enforcement gate. PAPER is admitted only from the explicit safe
configuration boundary.
"""
from __future__ import annotations

from dataclasses import dataclass

from . import config
from .fail_closed_gate import FailClosedEnforcementGate, GateDecision


@dataclass(frozen=True)
class ActivationBoundary:
    """Evaluate an execution intent against the current runtime safety state."""

    gate: FailClosedEnforcementGate = FailClosedEnforcementGate()

    def evaluate(self, action: str) -> GateDecision:
        state = {
            "live_trading": "LIVE" if config.LIVE_TRADING else "SAFE_OFF",
            "activation_gate": config.ACTIVATION_GATE,
            "fail_closed": "ACTIVE" if config.FAIL_CLOSED else "INACTIVE",
        }
        return self.gate.evaluate(state, action=action)

    def failure(self, reason: str) -> GateDecision:
        return self.gate.enforce_failure(None, reason=reason)
