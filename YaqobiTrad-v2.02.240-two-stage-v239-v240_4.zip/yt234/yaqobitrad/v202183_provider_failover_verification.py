"""YaqobiTrad v2.02.183 — provider failover verification boundary."""
from __future__ import annotations
from dataclasses import dataclass

CHECKPOINT = "v2.02.183"
PREDECESSOR = "v2.02.182"


@dataclass(frozen=True)
class ProviderFailoverVerificationResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    selected_provider: str = ""
    attempted_providers: tuple[str, ...] = ()
    failover_used: bool = False
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"


class ProviderFailoverVerificationV183:
    """Verify deterministic provider fallback without ever enabling live trading."""

    @staticmethod
    def _validate_state(state) -> None:
        if state is None or not all(hasattr(state, n) for n in ("activation_gate", "live_trading", "fail_closed")):
            raise ValueError("V202183_STATE_INTERFACE_INVALID")
        if (state.activation_gate, state.live_trading, state.fail_closed) != ("LOCKED", "SAFE_OFF", "ACTIVE"):
            raise ValueError("V202183_SAFETY_STATE_INVALID")

    @classmethod
    def verify(cls, state, providers, *, symbol="BTCUSDT", interval="1m"):
        cls._validate_state(state)
        if not isinstance(providers, (list, tuple)) or not providers:
            raise ValueError("V202183_PROVIDER_SET_INVALID")

        attempted = []
        selected = ""
        failover_used = False
        last_error = None
        for index, entry in enumerate(providers):
            if not isinstance(entry, tuple) or len(entry) != 2:
                raise ValueError("V202183_PROVIDER_ENTRY_INVALID")
            name, provider = entry
            if not isinstance(name, str) or not name.strip():
                raise ValueError("V202183_PROVIDER_NAME_INVALID")
            if not hasattr(provider, "fetch_latest_closed_candle"):
                raise ValueError("V202183_PROVIDER_INTERFACE_INVALID")
            attempted.append(name)
            try:
                candle = provider.fetch_latest_closed_candle(symbol, interval)
                if not getattr(candle, "closed", False):
                    raise ValueError("V202183_UNCLOSED_CANDLE")
                if index > 0:
                    failover_used = True
                selected = name
                return ProviderFailoverVerificationResult(
                    True, selected_provider=selected,
                    attempted_providers=tuple(attempted), failover_used=failover_used,
                )
            except Exception as exc:
                last_error = exc

        # Provider exhaustion is a hard block, never an activation path.
        reason = type(last_error).__name__ if last_error else "NO_PROVIDER"
        raise RuntimeError(f"V202183_ALL_PROVIDERS_FAILED:{reason}")
