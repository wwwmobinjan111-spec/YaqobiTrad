"""YaqobiTrad v2.02.200 — provider failover evidence attestation durability reconciliation major global checkpoint."""
from __future__ import annotations
import hashlib, json
from dataclasses import dataclass
from .production_blockers import open_production_blockers
CHECKPOINT="v2.02.200"; PREDECESSOR="v2.02.199"
@dataclass(frozen=True)
class ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointResult:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"
    activation_gate: str="LOCKED"
    fail_closed: str="ACTIVE"
    open_blocker_count: int=6
    certification: str="PENDING_REAL_PRODUCTION_RESULTS"
    reconciliation_digest: str=""
    provenance_digest: str=""
    checkpoint_digest: str=""
class ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointV200:
    @staticmethod
    def _digest(value, field):
        if not isinstance(value,str) or len(value)!=64 or any(c not in "0123456789abcdefABCDEF" for c in value):
            raise ValueError(f"V202200_{field.upper()}_DIGEST_INVALID")
        return value.lower()
    @classmethod
    def verify(cls, provenance, *, expected_provenance_digest=None):
        required=("valid","checkpoint","predecessor","reconciliation_ref","provenance_ref","recovery_ref","attestation_ref","live_trading","activation_gate","fail_closed")
        if provenance is None or not all(hasattr(provenance,n) for n in required): raise ValueError("V202200_PROVENANCE_INTERFACE_INVALID")
        if not provenance.valid: raise ValueError("V202200_PROVENANCE_INVALID")
        if (provenance.checkpoint,provenance.predecessor)!=(PREDECESSOR,"v2.02.198"): raise ValueError("V202200_PROVENANCE_LINEAGE_INVALID")
        refs=[provenance.reconciliation_ref,provenance.provenance_ref,provenance.recovery_ref,provenance.attestation_ref]
        if any(not isinstance(x,str) or not x.startswith("evidence://") or "=" in x for x in refs): raise ValueError("V202200_EVIDENCE_REF_INVALID")
        if len(set(refs))!=4: raise ValueError("V202200_REFERENCE_REUSE_INVALID")
        if (provenance.live_trading,provenance.activation_gate,provenance.fail_closed)!=("SAFE_OFF","LOCKED","ACTIVE"): raise ValueError("V202200_SAFETY_STATE_INVALID")
        reconciliation_digest=hashlib.sha256(provenance.reconciliation_ref.encode()).hexdigest()
        provenance_digest=hashlib.sha256(json.dumps({"checkpoint":provenance.checkpoint,"predecessor":provenance.predecessor,"refs":refs},separators=(",",":"),sort_keys=True).encode()).hexdigest()
        if expected_provenance_digest is not None and provenance_digest!=expected_provenance_digest: raise ValueError("V202200_PROVENANCE_DIGEST_MISMATCH")
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers): raise ValueError("V202200_BLOCKER_STATE_INVALID")
        payload={"checkpoint":CHECKPOINT,"predecessor":PREDECESSOR,"reconciliation_digest":reconciliation_digest,"provenance_digest":provenance_digest,"live_trading":"SAFE_OFF","activation_gate":"LOCKED","fail_closed":"ACTIVE"}
        checkpoint_digest=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":"),ensure_ascii=True).encode()).hexdigest()
        return ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointResult(True,reconciliation_digest=reconciliation_digest,provenance_digest=provenance_digest,checkpoint_digest=checkpoint_digest)
