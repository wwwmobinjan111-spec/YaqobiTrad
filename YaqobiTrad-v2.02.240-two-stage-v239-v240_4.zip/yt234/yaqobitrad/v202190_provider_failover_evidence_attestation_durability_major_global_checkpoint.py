"""YaqobiTrad v2.02.190 — provider failover evidence attestation durability major global checkpoint boundary."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

from .production_blockers import open_production_blockers

CHECKPOINT = "v2.02.190"
PREDECESSOR = "v2.02.189"


@dataclass(frozen=True)
class ProviderFailoverEvidenceAttestationDurabilityMajorGlobalCheckpointResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    open_blocker_count: int = 6
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"
    continuity_digest: str = ""
    durability_digest: str = ""
    checkpoint_digest: str = ""


class ProviderFailoverEvidenceAttestationDurabilityMajorGlobalCheckpointV190:
    """Verify the v2.02.189 provider-failover evidence chain at a major checkpoint."""

    @staticmethod
    def _payload(continuity):
        required = (
            "valid", "checkpoint", "predecessor", "continuity_digest",
            "durability_digest", "live_trading", "activation_gate", "fail_closed",
        )
        if continuity is None or not all(hasattr(continuity, name) for name in required):
            raise ValueError("V202190_CONTINUITY_INTERFACE_INVALID")
        if not continuity.valid:
            raise ValueError("V202190_CONTINUITY_INVALID")
        if (continuity.checkpoint, continuity.predecessor) != (PREDECESSOR, "v2.02.188"):
            raise ValueError("V202190_CONTINUITY_LINEAGE_INVALID")
        for name in ("continuity_digest", "durability_digest"):
            value = getattr(continuity, name)
            if not isinstance(value, str) or len(value) != 64:
                raise ValueError("V202190_DIGEST_INVALID")
        if (continuity.live_trading, continuity.activation_gate, continuity.fail_closed) != (
            "SAFE_OFF", "LOCKED", "ACTIVE"
        ):
            raise ValueError("V202190_SAFETY_STATE_INVALID")
        return {
            "checkpoint": continuity.checkpoint,
            "predecessor": continuity.predecessor,
            "continuity_digest": continuity.continuity_digest,
            "durability_digest": continuity.durability_digest,
            "live_trading": "SAFE_OFF",
            "activation_gate": "LOCKED",
            "fail_closed": "ACTIVE",
        }

    @classmethod
    def verify(cls, continuity, *, expected_durability_digest=None):
        payload = cls._payload(continuity)
        if (
            expected_durability_digest is not None
            and payload["durability_digest"] != expected_durability_digest
        ):
            raise ValueError("V202190_DURABILITY_DIGEST_MISMATCH")
        blockers = open_production_blockers()
        if len(blockers) != 6 or any(b.state != "OPEN" for b in blockers):
            raise ValueError("V202190_BLOCKER_STATE_INVALID")
        canonical = json.dumps(
            payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True
        ).encode()
        checkpoint_digest = hashlib.sha256(canonical).hexdigest()
        return ProviderFailoverEvidenceAttestationDurabilityMajorGlobalCheckpointResult(
            valid=True,
            continuity_digest=payload["continuity_digest"],
            durability_digest=payload["durability_digest"],
            checkpoint_digest=checkpoint_digest,
        )
