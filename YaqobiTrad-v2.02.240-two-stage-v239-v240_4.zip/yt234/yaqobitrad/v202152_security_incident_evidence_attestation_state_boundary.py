"""YaqobiTrad v2.02.152 — security incident evidence attestation state boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT = "v2.02.152"
PREDECESSOR = "v2.02.151"

@dataclass(frozen=True)
class SecurityIncidentEvidenceAttestationStateBoundaryResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    open_blocker_count: int = 6
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"
    continuity_ref: str = ""
    state_ref: str = ""

class SecurityIncidentEvidenceAttestationStateBoundaryV152:
    @staticmethod
    def _ref(value: str, field: str) -> str:
        if not isinstance(value, str) or not value.strip() or not value.startswith("evidence://"):
            raise ValueError(f"V202152_{field.upper()}_INVALID")
        if "=" in value or any(token in value.upper() for token in ("TOKEN", "SECRET", "PASSWORD", "PRIVATE_KEY")):
            raise ValueError(f"V202152_{field.upper()}_SECRET_OR_ASSIGNMENT_INVALID")
        return value

    @classmethod
    def verify(cls, state, *, continuity_ref: str, state_ref: str):
        if state is None or not all(hasattr(state, n) for n in ("activation_gate", "live_trading", "fail_closed")):
            raise ValueError("V202152_STATE_INTERFACE_INVALID")
        if (state.activation_gate, state.live_trading, state.fail_closed) != ("LOCKED", "SAFE_OFF", "ACTIVE"):
            raise ValueError("V202152_SAFETY_STATE_INVALID")
        continuity_ref = cls._ref(continuity_ref, "continuity_ref")
        state_ref = cls._ref(state_ref, "state_ref")
        blockers = open_production_blockers()
        if len(blockers) != 6 or any(b.state != "OPEN" for b in blockers):
            raise ValueError("V202152_BLOCKER_STATE_INVALID")
        return SecurityIncidentEvidenceAttestationStateBoundaryResult(True, continuity_ref=continuity_ref, state_ref=state_ref)
