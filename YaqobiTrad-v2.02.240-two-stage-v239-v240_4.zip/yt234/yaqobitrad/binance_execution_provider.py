"""Production Binance Spot execution adapter; live use remains explicitly gated."""
from __future__ import annotations
import hashlib, hmac, time, urllib.parse, urllib.request, json
from dataclasses import dataclass

@dataclass(frozen=True)
class ExchangeOrder:
    client_order_id: str
    provider_order_id: str
    status: str

class BinanceExecutionProvider:
    BASE = "https://api.binance.com"
    def __init__(self, api_key: str, api_secret: str, *, live_enabled: bool = False, transport=None, base_url: str | None = None):
        self.api_key, self.api_secret = api_key, api_secret
        self.live_enabled = live_enabled
        self.base_url = (base_url or self.BASE).rstrip("/")
        self.transport = transport or self._http
        self._seen: dict[str, ExchangeOrder] = {}

    def submit(self, client_order_id, side, quantity, price, symbol="BTCUSDT"):
        if not self.live_enabled:
            return {"status":"BLOCKED", "reason":"LIVE_TRADING_SAFE_OFF"}
        if client_order_id in self._seen:
            return self._seen[client_order_id]
        if side not in {"BUY", "SELL"} or float(quantity) <= 0 or float(price) <= 0:
            raise ValueError("INVALID_ORDER")
        params = {"symbol":symbol, "side":side, "type":"LIMIT", "timeInForce":"GTC",
                  "quantity":str(quantity), "price":str(price), "newClientOrderId":client_order_id,
                  "timestamp":str(int(time.time()*1000))}
        qs = urllib.parse.urlencode(params)
        sig = hmac.new(self.api_secret.encode(), qs.encode(), hashlib.sha256).hexdigest()
        data = self.transport("POST", "/api/v3/order?" + qs + "&signature=" + sig,
                              {"X-MBX-APIKEY": self.api_key})
        order = ExchangeOrder(client_order_id, str(data["orderId"]), str(data.get("status", "NEW")))
        self._seen[client_order_id] = order
        return order

    def reconcile(self, client_order_id, symbol="BTCUSDT"):
        if client_order_id in self._seen:
            return self._seen[client_order_id]
        if not self.live_enabled:
            return {"status":"BLOCKED", "reason":"LIVE_TRADING_SAFE_OFF"}
        params = {"symbol":symbol, "origClientOrderId":client_order_id, "timestamp":str(int(time.time()*1000))}
        qs = urllib.parse.urlencode(params)
        sig = hmac.new(self.api_secret.encode(), qs.encode(), hashlib.sha256).hexdigest()
        data = self.transport("GET", "/api/v3/order?" + qs + "&signature=" + sig,
                              {"X-MBX-APIKEY": self.api_key})
        order = ExchangeOrder(client_order_id, str(data["orderId"]), str(data.get("status", "UNKNOWN")))
        self._seen[client_order_id] = order
        return order

    @staticmethod
    def _http(method, path, headers):
        req = urllib.request.Request(BinanceExecutionProvider.BASE + path, headers=headers, method=method)
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read().decode())
