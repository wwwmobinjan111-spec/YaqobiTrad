"""Fail-closed restart/recovery gate for YaqobiTrad v2.02.52.

A restart never re-opens live execution. Recovery must validate checkpoint
integrity and sequence before the runtime can resume paper-mode operation.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .recovery import RecoveryCheckpoint, restore_checkpoint


@dataclass(frozen=True)
class RestartGateResult:
    status: str
    live_trading: str
    activation_gate: str
    fail_closed: str
    recovery_status: str
    reason: str | None = None
    audit: tuple[str, ...] = field(default_factory=tuple)


class RecoveryRestartGate:
    """Stateful, deterministic restart boundary that fails closed."""

    def __init__(self) -> None:
        self._recovered = False
        self._reconciled = False
        self._audit: list[str] = []

    def restart(self) -> RestartGateResult:
        self._recovered = False
        self._reconciled = False
        self._audit = ["RESTART_REQUEST", "LIVE_TRADING_SAFE_OFF", "ACTIVATION_GATE_LOCKED"]
        return self._result("RESTART_REQUIRED")

    def recover(
        self,
        checkpoint: RecoveryCheckpoint,
        *,
        expected_sequence: int | None = None,
    ) -> RestartGateResult:
        try:
            restore_checkpoint(checkpoint, expected_sequence=expected_sequence)
        except (TypeError, ValueError) as exc:
            self._recovered = False
            self._reconciled = False
            self._audit.extend(["RECOVERY_REJECTED", "FAIL_CLOSED"])
            return self._result("FAILED_SAFE", reason=str(exc))

        self._recovered = True
        self._reconciled = False
        self._audit.extend(["CHECKPOINT_VALID", "RECOVERY_RESTORED"])
        return self._result("RECOVERED")

    def reconcile(self, ok: bool) -> RestartGateResult:
        if not self._recovered:
            self._audit.extend(["RECONCILIATION_REJECTED", "FAIL_CLOSED"])
            return self._result("FAILED_SAFE", reason="RECOVERY_NOT_COMPLETE")
        if not ok:
            self._reconciled = False
            self._audit.extend(["RECONCILIATION_FAILED", "FAIL_CLOSED"])
            return self._result("FAILED_SAFE", reason="RECONCILIATION_FAILED")
        self._reconciled = True
        self._audit.append("RECONCILIATION_PASSED")
        return self._result("READY_PAPER")

    def resume(self) -> RestartGateResult:
        if not self._recovered:
            self._audit.extend(["RESUME_REJECTED", "FAIL_CLOSED"])
            return self._result("BLOCKED", reason="RECOVERY_NOT_COMPLETE")
        if not self._reconciled:
            self._audit.extend(["RESUME_REJECTED", "FAIL_CLOSED"])
            return self._result("BLOCKED", reason="RECONCILIATION_REQUIRED")
        self._audit.append("PAPER_RESUME_AUTHORIZED")
        # Resume is deliberately paper-only. The activation gate remains locked.
        return self._result("RESUMED_PAPER")

    def _result(self, status: str, *, reason: str | None = None) -> RestartGateResult:
        return RestartGateResult(
            status=status,
            live_trading="SAFE_OFF",
            activation_gate="LOCKED",
            fail_closed="ACTIVE",
            recovery_status="RECOVERED" if self._recovered else "FAILED_SAFE" if status in {"FAILED_SAFE", "BLOCKED"} else "RESTART_REQUIRED",
            reason=reason,
            audit=tuple(self._audit),
        )
