"""YaqobiTrad v2.02.188 — provider failover evidence attestation durability boundary."""
from __future__ import annotations
import hashlib, json
from dataclasses import dataclass

CHECKPOINT = "v2.02.188"
PREDECESSOR = "v2.02.187"

@dataclass(frozen=True)
class ProviderFailoverEvidenceAttestationDurabilityResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    continuity_digest: str = ""
    durability_digest: str = ""
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"

class ProviderFailoverEvidenceAttestationDurabilityV188:
    """Seal v2.02.187 attestation continuity for deterministic durable replay."""
    @staticmethod
    def _payload(continuity):
        required=("valid","checkpoint","predecessor","attestation_digest","continuity_digest",
                  "live_trading","activation_gate","fail_closed")
        if continuity is None or not all(hasattr(continuity,n) for n in required):
            raise ValueError("V202188_CONTINUITY_INTERFACE_INVALID")
        if not continuity.valid:
            raise ValueError("V202188_CONTINUITY_INVALID")
        if (continuity.checkpoint,continuity.predecessor)!=(PREDECESSOR,"v2.02.186"):
            raise ValueError("V202188_CONTINUITY_LINEAGE_INVALID")
        for name in ("continuity_digest","attestation_digest"):
            value=getattr(continuity,name)
            if not isinstance(value,str) or len(value)!=64:
                raise ValueError("V202188_DIGEST_INVALID")
        if (continuity.live_trading,continuity.activation_gate,continuity.fail_closed)!=("SAFE_OFF","LOCKED","ACTIVE"):
            raise ValueError("V202188_SAFETY_STATE_INVALID")
        return {"checkpoint":continuity.checkpoint,"predecessor":continuity.predecessor,
                "attestation_digest":continuity.attestation_digest,"continuity_digest":continuity.continuity_digest,
                "live_trading":"SAFE_OFF","activation_gate":"LOCKED","fail_closed":"ACTIVE"}
    @classmethod
    def seal(cls, continuity, *, expected_continuity_digest=None):
        payload=cls._payload(continuity)
        if expected_continuity_digest is not None and payload["continuity_digest"]!=expected_continuity_digest:
            raise ValueError("V202188_CONTINUITY_DIGEST_MISMATCH")
        canonical=json.dumps(payload,sort_keys=True,separators=(",",":"),ensure_ascii=True).encode()
        digest=hashlib.sha256(canonical).hexdigest()
        return ProviderFailoverEvidenceAttestationDurabilityResult(valid=True,
            continuity_digest=payload["continuity_digest"],durability_digest=digest)
