"""YaqobiTrad v2.02.202 — post-checkpoint recovery boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT="v2.02.202"; PREDECESSOR="v2.02.201"
@dataclass(frozen=True)
class ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointRecoveryBoundaryResult:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"
    activation_gate: str="LOCKED"
    fail_closed: str="ACTIVE"
    open_blocker_count: int=6
    certification: str="PENDING_REAL_PRODUCTION_RESULTS"
    recovery_ref: str=""
    checkpoint_digest: str=""

class ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointRecoveryBoundaryV202:
    @staticmethod
    def _ref(value, field):
        if not isinstance(value,str) or not value.strip() or not value.startswith("evidence://") or "=" in value or any(t in value.upper() for t in ("TOKEN","SECRET","PASSWORD","PRIVATE_KEY")):
            raise ValueError(f"V202202_{field.upper()}_INVALID")
        return value
    @classmethod
    def verify(cls, state, *, recovery_ref, checkpoint_digest):
        if state is None or not all(hasattr(state,n) for n in ("checkpoint","predecessor","live_trading","activation_gate","fail_closed","checkpoint_digest")):
            raise ValueError("V202202_STATE_INTERFACE_INVALID")
        if (state.checkpoint,state.predecessor)!=(CHECKPOINT,PREDECESSOR):
            raise ValueError("V202202_LINEAGE_INVALID")
        if (state.live_trading,state.activation_gate,state.fail_closed)!=("SAFE_OFF","LOCKED","ACTIVE"):
            raise ValueError("V202202_SAFETY_STATE_INVALID")
        if not isinstance(checkpoint_digest,str) or len(checkpoint_digest)!=64 or any(c not in "0123456789abcdefABCDEF" for c in checkpoint_digest):
            raise ValueError("V202202_CHECKPOINT_DIGEST_INVALID")
        if checkpoint_digest.lower()!=state.checkpoint_digest.lower():
            raise ValueError("V202202_CHECKPOINT_DIGEST_MISMATCH")
        recovery_ref=cls._ref(recovery_ref,"recovery_ref")
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers):
            raise ValueError("V202202_BLOCKER_STATE_INVALID")
        return ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointRecoveryBoundaryResult(True,recovery_ref=recovery_ref,checkpoint_digest=checkpoint_digest.lower())
