"""YaqobiTrad v2.02.121 — production provider execution boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT="v2.02.121"
PREDECESSOR="v2.02.120"

@dataclass(frozen=True)
class ProviderExecutionBoundaryResult:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"
    activation_gate: str="LOCKED"
    fail_closed: str="ACTIVE"
    production_provider_blocker: str="OPEN"
    open_blocker_count: int=6
    certification: str="PENDING_REAL_PRODUCTION_RESULTS"

class ProductionProviderExecutionBoundaryV121:
    @staticmethod
    def verify(provider) -> ProviderExecutionBoundaryResult:
        if provider is None or not hasattr(provider,"submit") or not hasattr(provider,"reconcile"):
            raise ValueError("V202121_PROVIDER_INTERFACE_INVALID")
        if provider.live_enabled:
            # A real production adapter may exist, but this checkpoint does not authorize live trading.
            raise ValueError("V202121_LIVE_ENABLE_REQUIRES_PRODUCTION_AUTHORIZATION")
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers):
            raise ValueError("V202121_BLOCKER_STATE_INVALID")
        return ProviderExecutionBoundaryResult(True)
