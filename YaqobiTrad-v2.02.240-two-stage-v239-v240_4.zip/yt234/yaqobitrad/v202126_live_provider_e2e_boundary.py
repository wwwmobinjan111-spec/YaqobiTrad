"""YaqobiTrad v2.02.126 — live provider E2E boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT="v2.02.126"
PREDECESSOR="v2.02.125"

@dataclass(frozen=True)
class LiveProviderE2EBoundaryResult:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"
    activation_gate: str="LOCKED"
    fail_closed: str="ACTIVE"
    live_provider_e2e_blocker: str="OPEN"
    open_blocker_count: int=6
    certification: str="PENDING_REAL_PRODUCTION_RESULTS"

class LiveProviderE2EBoundaryV126:
    @staticmethod
    def verify(provider):
        if provider is None or not all(hasattr(provider,n) for n in ("submit","reconcile")):
            raise ValueError("V202126_PROVIDER_INTERFACE_INVALID")
        if getattr(provider,"live_enabled",False):
            raise ValueError("V202126_LIVE_E2E_REQUIRES_EXPLICIT_PRODUCTION_AUTHORIZATION")
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers):
            raise ValueError("V202126_BLOCKER_STATE_INVALID")
        return LiveProviderE2EBoundaryResult(True)
