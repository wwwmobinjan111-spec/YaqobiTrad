"""YaqobiTrad v2.02.143 — security incident evidence retention/recovery boundary.

Source-level boundary only. It validates non-secret retention/recovery evidence
references and preserves the production fail-closed state. It does not claim
that a real production retention or recovery system has been deployed or that
any production security blocker has been closed.
"""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT = "v2.02.143"
PREDECESSOR = "v2.02.142"

@dataclass(frozen=True)
class SecurityIncidentEvidenceRetentionRecoveryBoundaryResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    open_blocker_count: int = 6
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"

class SecurityIncidentEvidenceRetentionRecoveryBoundaryV143:
    @staticmethod
    def verify(state, *, retention_ref: str | None = None,
               recovery_ref: str | None = None) -> SecurityIncidentEvidenceRetentionRecoveryBoundaryResult:
        if state is None or not all(hasattr(state, n) for n in ("activation_gate", "live_trading", "fail_closed")):
            raise ValueError("V202143_STATE_INTERFACE_INVALID")
        if state.activation_gate != "LOCKED" or state.live_trading != "SAFE_OFF" or state.fail_closed != "ACTIVE":
            raise ValueError("V202143_SAFETY_STATE_INVALID")
        for name, value in (("retention_ref", retention_ref), ("recovery_ref", recovery_ref)):
            if value is not None:
                if not isinstance(value, str) or not value.strip() or "=" in value or len(value.strip()) < 3:
                    raise ValueError(f"V202143_{name.upper()}_INVALID")
        blockers = open_production_blockers()
        if len(blockers) != 6 or any(b.state != "OPEN" for b in blockers):
            raise ValueError("V202143_BLOCKER_STATE_INVALID")
        return SecurityIncidentEvidenceRetentionRecoveryBoundaryResult(True)
