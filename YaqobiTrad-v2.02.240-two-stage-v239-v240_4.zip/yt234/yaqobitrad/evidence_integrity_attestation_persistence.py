"""v2.02.86 — portable evidence integrity attestation persistence gate.

Serializes an already-verified v2.02.85 attestation into a canonical JSON
envelope and validates it on import. Persistence never closes blockers or
changes activation/live-trading state.
"""
from __future__ import annotations

import json
from dataclasses import asdict

from .evidence_integrity_attestation import (
    EvidenceIntegrityAttestation,
    EvidenceIntegrityAttestationGate,
)

SCHEMA_VERSION = "v2.02.86"
REQUIRED_KEYS = (
    "schema_version",
    "checkpoint",
    "evidence_digest",
    "blocker_ids",
    "activation_gate",
    "fail_closed",
    "live_trading",
    "attestation_digest",
)


def serialize_attestation(attestation: EvidenceIntegrityAttestation) -> str:
    """Return deterministic JSON suitable for durable transport/storage."""
    payload = {"schema_version": SCHEMA_VERSION, **asdict(attestation)}
    payload["blocker_ids"] = list(attestation.blocker_ids)
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def deserialize_attestation(payload: str) -> EvidenceIntegrityAttestation:
    """Parse a persisted attestation with strict schema and field validation."""
    if not isinstance(payload, str):
        raise ValueError("ATTESTATION_PAYLOAD_INVALID")
    try:
        data = json.loads(payload)
    except (TypeError, json.JSONDecodeError) as exc:
        raise ValueError("ATTESTATION_PAYLOAD_INVALID") from exc
    if not isinstance(data, dict) or tuple(k for k in data if k not in REQUIRED_KEYS) or set(data) != set(REQUIRED_KEYS):
        raise ValueError("ATTESTATION_SCHEMA_INVALID")
    if data["schema_version"] != SCHEMA_VERSION:
        raise ValueError("ATTESTATION_SCHEMA_VERSION_INVALID")
    blockers = data["blocker_ids"]
    if not isinstance(blockers, list) or any(not isinstance(x, str) for x in blockers):
        raise ValueError("ATTESTATION_BLOCKERS_INVALID")
    values = {
        "checkpoint": data["checkpoint"],
        "evidence_digest": data["evidence_digest"],
        "blocker_ids": tuple(blockers),
        "activation_gate": data["activation_gate"],
        "fail_closed": data["fail_closed"],
        "live_trading": data["live_trading"],
        "attestation_digest": data["attestation_digest"],
    }
    if any(not isinstance(v, str) for k, v in values.items() if k != "blocker_ids"):
        raise ValueError("ATTESTATION_FIELDS_INVALID")
    return EvidenceIntegrityAttestation(**values)


def verify_persisted_attestation(
    gate: EvidenceIntegrityAttestationGate, payload: str
):
    """Load and verify without changing any project safety state."""
    attestation = deserialize_attestation(payload)
    return gate.verify(attestation)
