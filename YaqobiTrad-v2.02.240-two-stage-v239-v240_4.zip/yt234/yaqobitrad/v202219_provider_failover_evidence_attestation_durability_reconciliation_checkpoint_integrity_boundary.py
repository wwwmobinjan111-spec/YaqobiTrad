"""YaqobiTrad v2.02.219 — checkpoint integrity boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT="v2.02.219"; PREDECESSOR="v2.02.218"

@dataclass(frozen=True)
class Result:
    valid: bool
    checkpoint: str=CHECKPOINT; predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"; activation_gate: str="LOCKED"; fail_closed: str="ACTIVE"
    open_blocker_count: int=6; certification: str="PENDING_REAL_PRODUCTION_RESULTS"
    checkpoint_digest: str=""; integrity_ref: str=""; recovery_ref: str=""

class ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointIntegrityBoundaryV219:
    @staticmethod
    def _ref(value, field):
        if not isinstance(value,str) or not value.strip() or not value.startswith("evidence://") or "=" in value or any(t in value.upper() for t in ("TOKEN","SECRET","PASSWORD","PRIVATE_KEY")):
            raise ValueError(f"V202219_{field.upper()}_INVALID")
        return value

    @classmethod
    def verify(cls,state,*,checkpoint_digest,integrity_ref,recovery_ref):
        req=("checkpoint","predecessor","live_trading","activation_gate","fail_closed","checkpoint_digest")
        if state is None or not all(hasattr(state,n) for n in req): raise ValueError("V202219_STATE_INTERFACE_INVALID")
        if (state.checkpoint,state.predecessor)!=(CHECKPOINT,PREDECESSOR): raise ValueError("V202219_LINEAGE_INVALID")
        if (state.live_trading,state.activation_gate,state.fail_closed)!=("SAFE_OFF","LOCKED","ACTIVE"): raise ValueError("V202219_SAFETY_STATE_INVALID")
        if not isinstance(checkpoint_digest,str) or len(checkpoint_digest)!=64 or any(c not in "0123456789abcdefABCDEF" for c in checkpoint_digest): raise ValueError("V202219_CHECKPOINT_DIGEST_INVALID")
        if checkpoint_digest.lower()!=state.checkpoint_digest.lower(): raise ValueError("V202219_CHECKPOINT_DIGEST_MISMATCH")
        integrity_ref=cls._ref(integrity_ref,"integrity_ref"); recovery_ref=cls._ref(recovery_ref,"recovery_ref")
        if integrity_ref==recovery_ref: raise ValueError("V202219_REFERENCE_REUSE_INVALID")
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers): raise ValueError("V202219_BLOCKER_STATE_INVALID")
        return Result(True,checkpoint_digest=checkpoint_digest.lower(),integrity_ref=integrity_ref,recovery_ref=recovery_ref)
