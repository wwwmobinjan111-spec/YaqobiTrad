"""YaqobiTrad v2.02.129 — certification evidence boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT="v2.02.129"
PREDECESSOR="v2.02.128"

@dataclass(frozen=True)
class CertificationEvidenceResult:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"
    activation_gate: str="LOCKED"
    fail_closed: str="ACTIVE"
    open_blocker_count: int=6
    certification: str="PENDING_REAL_PRODUCTION_RESULTS"

class CertificationEvidenceBoundaryV129:
    @staticmethod
    def verify(evidence):
        if evidence is None or not all(hasattr(evidence,n) for n in ("validate","complete")):
            raise ValueError("V202129_EVIDENCE_INTERFACE_INVALID")
        if evidence.complete():
            raise ValueError("V202129_CERTIFICATION_REQUIRES_REAL_PRODUCTION_EVIDENCE")
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers):
            raise ValueError("V202129_BLOCKER_STATE_INVALID")
        return CertificationEvidenceResult(True)
