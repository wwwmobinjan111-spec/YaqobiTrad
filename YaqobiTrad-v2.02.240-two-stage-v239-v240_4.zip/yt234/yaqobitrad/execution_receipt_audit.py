"""v2.02.59: bind execution receipts to the tamper-evident audit chain."""
from __future__ import annotations
import hashlib
import json
from dataclasses import dataclass

@dataclass(frozen=True)
class ReceiptAuditBinding:
    client_order_id: str
    provider_order_id: str
    receipt_digest: str
    audit_hash: str


def receipt_digest(receipt) -> str:
    payload = {
        "client_order_id": receipt.client_order_id,
        "provider_order_id": receipt.provider_order_id,
        "status": receipt.status,
        "side": receipt.side,
        "quantity": float(receipt.quantity),
        "price": float(receipt.price),
    }
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()


class ExecutionReceiptAuditBinder:
    """Create and verify a one-to-one receipt/audit binding."""
    EVENT = "EXECUTION_RECEIPT_COMMITTED"

    def __init__(self, audit_log):
        self.audit = audit_log
        self._bindings: dict[str, ReceiptAuditBinding] = {}

    def bind(self, receipt):
        digest = receipt_digest(receipt)
        existing = self._bindings.get(receipt.client_order_id)
        if existing is not None:
            if existing.provider_order_id != receipt.provider_order_id or existing.receipt_digest != digest:
                raise ValueError("RECEIPT_BINDING_MISMATCH")
            return existing
        record = self.audit.append(self.EVENT, {
            "client_order_id": receipt.client_order_id,
            "provider_order_id": receipt.provider_order_id,
            "receipt_digest": digest,
        })
        binding = ReceiptAuditBinding(receipt.client_order_id, receipt.provider_order_id,
                                      digest, record["hash"])
        self._bindings[receipt.client_order_id] = binding
        return binding

    def verify(self, receipt) -> bool:
        binding = self._bindings.get(receipt.client_order_id)
        if binding is None or not self.audit.verify():
            return False
        return (binding.provider_order_id == receipt.provider_order_id
                and binding.receipt_digest == receipt_digest(receipt)
                and any(r.get("hash") == binding.audit_hash and
                        r.get("event") == self.EVENT and
                        r.get("data", {}).get("client_order_id") == receipt.client_order_id and
                        r.get("data", {}).get("provider_order_id") == receipt.provider_order_id and
                        r.get("data", {}).get("receipt_digest") == binding.receipt_digest
                        for r in self.audit.entries))
