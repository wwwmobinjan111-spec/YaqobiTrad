"""YaqobiTrad v2.02.127 — verification/reconciliation boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT="v2.02.127"
PREDECESSOR="v2.02.126"

@dataclass(frozen=True)
class VerificationReconciliationResult:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"
    activation_gate: str="LOCKED"
    fail_closed: str="ACTIVE"
    open_blocker_count: int=6
    certification: str="PENDING_REAL_PRODUCTION_RESULTS"

class VerificationReconciliationBoundaryV127:
    @staticmethod
    def verify(reconciler):
        if reconciler is None or not all(hasattr(reconciler,n) for n in ("verify","reconcile")):
            raise ValueError("V202127_RECONCILIATION_INTERFACE_INVALID")
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers):
            raise ValueError("V202127_BLOCKER_STATE_INVALID")
        return VerificationReconciliationResult(True)
