"""YaqobiTrad v2.02.235 — production blocker evidence matrix boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT='v2.02.235'; PREDECESSOR='v2.02.234'
@dataclass(frozen=True)
class Result:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str='SAFE_OFF'
    activation_gate: str='LOCKED'
    fail_closed: str='ACTIVE'
    open_blocker_count: int=6
    certification: str='PENDING_REAL_PRODUCTION_RESULTS'
    evidence_required: tuple[str,...]=()

class ProductionBlockerEvidenceMatrixBoundaryV235:
    REQUIRED=(
        'production_provider_execution','production_auth_authorization',
        'production_secret_management','production_portfolio_persistence',
        'production_monitoring','live_provider_e2e')
    @classmethod
    def verify(cls, checkpoint):
        req=('valid','checkpoint','predecessor','live_trading','activation_gate','fail_closed')
        if checkpoint is None or not all(hasattr(checkpoint,n) for n in req): raise ValueError('V202235_CHECKPOINT_INTERFACE_INVALID')
        if not checkpoint.valid or checkpoint.checkpoint!=PREDECESSOR or checkpoint.predecessor!='v2.02.233': raise ValueError('V202235_LINEAGE_INVALID')
        if (checkpoint.live_trading,checkpoint.activation_gate,checkpoint.fail_closed)!=('SAFE_OFF','LOCKED','ACTIVE'): raise ValueError('V202235_SAFETY_STATE_INVALID')
        blockers=tuple(b.blocker_id for b in open_production_blockers())
        if blockers!=cls.REQUIRED: raise ValueError('V202235_BLOCKER_MATRIX_INVALID')
        return Result(True,evidence_required=blockers)
