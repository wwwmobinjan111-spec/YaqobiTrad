"""YaqobiTrad v2.02.105 — durable verification snapshot reconstruction."""
from __future__ import annotations
import copy, hashlib, json
from dataclasses import dataclass
from .audit import AuditLog
from .production_blockers import open_production_blockers

CHECKPOINT="v2.02.105"; PREDECESSOR="v2.02.104"; ATTESTATION_EVENT="MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED"; ATTESTATION_SCHEMA="v2.02.99"
@dataclass(frozen=True)
class SnapshotReconstructionResult:
    valid: bool
    checkpoint: str=CHECKPOINT; predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"; activation_gate: str="LOCKED"; fail_closed: str="ACTIVE"
    open_blocker_count: int=6; certification: str="PENDING_REAL_PRODUCTION_RESULTS"; snapshot_digest: str=""
class DurableVerificationSnapshotReconstruction:
    @staticmethod
    def _snapshot(a): return {"entries":copy.deepcopy(a.entries),"prev_hash":a.prev_hash}
    @staticmethod
    def _canonical(s): return json.dumps(s,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()
    @classmethod
    def _digest(cls,s): return hashlib.sha256(cls._canonical(s)).hexdigest()
    def verify(self,audit_path,*,expected_anchor_hash,expected_bound_audit_hash,expected_evidence_digest,expected_snapshot_digest):
        a=AuditLog(audit_path)
        if not a.verify(): raise ValueError("V202105_AUDIT_CHAIN_INVALID")
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers): raise ValueError("V202105_BLOCKER_STATE_INVALID")
        anchors=[e for e in a.entries if e.get("event")==ATTESTATION_EVENT]
        if len(anchors)!=1 or not a.entries or a.entries[-1] is not anchors[0]: raise ValueError("V202105_TERMINAL_ATTESTATION_INVALID")
        anchor=anchors[0]; d=anchor.get("data",{})
        if d.get("schema_version")!=ATTESTATION_SCHEMA: raise ValueError("V202105_PREDECESSOR_SCHEMA_INVALID")
        if anchor.get("hash")!=expected_anchor_hash: raise ValueError("V202105_ANCHOR_HASH_MISMATCH")
        if d.get("bound_audit_hash")!=expected_bound_audit_hash: raise ValueError("V202105_BOUND_AUDIT_HASH_MISMATCH")
        if d.get("evidence_digest")!=expected_evidence_digest: raise ValueError("V202105_EVIDENCE_DIGEST_MISMATCH")
        if len(a.entries)<2 or d.get("continuity_hash")!=a.entries[-2].get("hash"): raise ValueError("V202105_CONTINUITY_LINK_INVALID")
        snap=self._snapshot(a); digest=self._digest(snap)
        if digest!=expected_snapshot_digest: raise ValueError("V202105_SNAPSHOT_DIGEST_MISMATCH")
        # Reconstruct from canonical bytes; the reconstructed object must hash identically.
        reconstructed=json.loads(self._canonical(snap).decode("utf-8"))
        if self._digest(reconstructed)!=digest: raise ValueError("V202105_RECONSTRUCTION_DIGEST_MISMATCH")
        # A fresh audit reload must reproduce the same canonical state.
        fresh=AuditLog(audit_path)
        if self._digest(self._snapshot(fresh))!=digest: raise ValueError("V202105_RELOAD_DIGEST_MISMATCH")
        # Caller-visible copies cannot mutate the live audit state.
        isolated=copy.deepcopy(reconstructed)
        isolated["entries"][-1]["data"]["evidence_digest"]="MUTATION_SENTINEL"
        if self._digest(isolated)==digest or a.entries[-1]["data"].get("evidence_digest")!=expected_evidence_digest:
            raise ValueError("V202105_RECONSTRUCTION_ISOLATION_FAILURE")
        return SnapshotReconstructionResult(True,snapshot_digest=digest)
