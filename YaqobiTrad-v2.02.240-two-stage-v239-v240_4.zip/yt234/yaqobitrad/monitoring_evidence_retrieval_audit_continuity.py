"""YaqobiTrad v2.02.95 — monitoring evidence retrieval audit continuity.

Extends v2.02.94 by verifying that the audit binding survives a durable
round-trip without changing the evidence binding or prior audit history.
Any persistence/reload integrity failure is fail-closed.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

from .audit import AuditLog
from .monitoring_evidence_retrieval_audit_binding import MonitoringEvidenceRetrievalAuditBinding
from .production_blockers import open_production_blockers

SCHEMA_VERSION = "v2.02.95"
EVENT = "MONITORING_EVIDENCE_RETRIEVAL_AUDIT_CONTINUITY_VERIFIED"


def _canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def _digest(value: object) -> str:
    return hashlib.sha256(_canonical(value)).hexdigest()


@dataclass(frozen=True)
class MonitoringEvidenceAuditContinuityResult:
    valid: bool
    reason: str
    evidence_digest: str
    audit_hash: str
    persisted: bool
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"


class MonitoringEvidenceRetrievalAuditContinuity:
    """Verify durable continuity of a v2.02.94 retrieval/audit binding."""

    def __init__(self, binding: MonitoringEvidenceRetrievalAuditBinding):
        self.binding = binding

    def bind_and_verify(
        self,
        evidence_path: str,
        audit_path: str,
        *,
        now: float,
        max_age: float,
    ) -> MonitoringEvidenceAuditContinuityResult:
        if not self.binding.audit.verify():
            raise ValueError("MONITORING_RETRIEVAL_AUDIT_CONTINUITY_CHAIN_INVALID")
        self.binding.audit.path = audit_path
        before = _digest(self.binding.audit.entries)

        bound = self.binding.bind(evidence_path, now=now, max_age=max_age)
        if not self.binding.audit.verify():
            raise ValueError("MONITORING_RETRIEVAL_AUDIT_CONTINUITY_CHAIN_INVALID_AFTER_BIND")
        if _digest(self.binding.audit.entries[:-1]) != before:
            raise ValueError("MONITORING_RETRIEVAL_AUDIT_CONTINUITY_HISTORY_MUTATED")

        restored = AuditLog(audit_path)
        if not restored.verify():
            raise ValueError("MONITORING_RETRIEVAL_AUDIT_CONTINUITY_PERSISTENCE_INVALID")
        if not restored.entries:
            raise ValueError("MONITORING_RETRIEVAL_AUDIT_CONTINUITY_EMPTY")
        last = restored.entries[-1]
        if last.get("hash") != bound.audit_hash:
            raise ValueError("MONITORING_RETRIEVAL_AUDIT_CONTINUITY_HASH_MISMATCH")
        if last.get("data", {}).get("evidence_digest") != bound.evidence_digest:
            raise ValueError("MONITORING_RETRIEVAL_AUDIT_CONTINUITY_DIGEST_MISMATCH")

        continuity = restored.append(
            EVENT,
            {
                "schema_version": SCHEMA_VERSION,
                "bound_audit_hash": bound.audit_hash,
                "evidence_digest": bound.evidence_digest,
            },
        )
        if not restored.verify():
            raise ValueError("MONITORING_RETRIEVAL_AUDIT_CONTINUITY_CHAIN_INVALID_AFTER_CONTINUITY")
        final = AuditLog(audit_path)
        if not final.verify():
            raise ValueError("MONITORING_RETRIEVAL_AUDIT_CONTINUITY_RELOAD_FAILED")
        if final.entries[-1]["hash"] != continuity["hash"]:
            raise ValueError("MONITORING_RETRIEVAL_AUDIT_CONTINUITY_FINAL_HASH_MISMATCH")
        if not open_production_blockers():
            raise ValueError("MONITORING_BLOCKER_STATE_UNEXPECTED")

        return MonitoringEvidenceAuditContinuityResult(
            valid=True,
            reason="MONITORING_EVIDENCE_RETRIEVAL_AUDIT_CONTINUITY_VERIFIED",
            evidence_digest=bound.evidence_digest,
            audit_hash=bound.audit_hash,
            persisted=True,
        )
