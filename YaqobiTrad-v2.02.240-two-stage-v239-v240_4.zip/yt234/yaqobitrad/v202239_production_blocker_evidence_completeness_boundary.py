"""YaqobiTrad v2.02.239 — production blocker evidence completeness boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT='v2.02.239'; PREDECESSOR='v2.02.238'

@dataclass(frozen=True)
class Result:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str='SAFE_OFF'
    activation_gate: str='LOCKED'
    fail_closed: str='ACTIVE'
    open_blocker_count: int=6
    certification: str='PENDING_REAL_PRODUCTION_RESULTS'
    evidence_complete: bool=False
    closure_authorized: bool=False

class ProductionBlockerEvidenceCompletenessBoundaryV239:
    REQUIRED=tuple(b.blocker_id for b in open_production_blockers())

    @classmethod
    def verify(cls, checkpoint, *, evidence_ids=()):
        req=('valid','checkpoint','predecessor','live_trading','activation_gate','fail_closed')
        if checkpoint is None or not all(hasattr(checkpoint,n) for n in req):
            raise ValueError('V202239_CHECKPOINT_INTERFACE_INVALID')
        if not checkpoint.valid or checkpoint.checkpoint!='v2.02.238' or checkpoint.predecessor!='v2.02.237':
            raise ValueError('V202239_LINEAGE_INVALID')
        if (checkpoint.live_trading,checkpoint.activation_gate,checkpoint.fail_closed)!=('SAFE_OFF','LOCKED','ACTIVE'):
            raise ValueError('V202239_SAFETY_STATE_INVALID')
        if len(cls.REQUIRED)!=6 or tuple(b.blocker_id for b in open_production_blockers())!=cls.REQUIRED:
            raise ValueError('V202239_BLOCKER_SET_INVALID')
        evidence=tuple(evidence_ids)
        if any(x not in cls.REQUIRED for x in evidence):
            raise ValueError('V202239_EVIDENCE_ID_INVALID')
        if len(set(evidence)) != len(evidence):
            raise ValueError('V202239_EVIDENCE_DUPLICATE')
        complete=set(evidence)==set(cls.REQUIRED)
        # Complete evidence inventory is necessary but does not itself authorize closure.
        return Result(True,evidence_complete=complete,closure_authorized=False)
