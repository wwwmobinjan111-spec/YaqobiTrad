"""v2.02.69: fail-closed evidence release verification boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .evidence_release_distribution_gate import EvidenceReleaseDistributionGate

@dataclass(frozen=True)
class EvidenceReleaseVerificationDecision:
    verified: bool
    reason: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"

class EvidenceReleaseVerificationGate:
    """Verify a distributed evidence release only after distribution succeeds."""

    EVENT = "EVIDENCE_RELEASE_VERIFIED"

    def __init__(self, audit, distribution_gate: EvidenceReleaseDistributionGate):
        self.audit = audit
        self.distribution_gate = distribution_gate
        self._verified: dict[str, str] = {}

    def verify_release(self, checkpoint) -> EvidenceReleaseVerificationDecision:
        if not self.audit.verify():
            self._verified.pop(checkpoint.checkpoint, None)
            return EvidenceReleaseVerificationDecision(False, "AUDIT_CHAIN_INVALID")

        existing = self._verified.get(checkpoint.checkpoint)
        if existing is not None:
            if not self.distribution_gate.distributed:
                self._verified.pop(checkpoint.checkpoint, None)
                return EvidenceReleaseVerificationDecision(False, "DISTRIBUTION_NOT_VERIFIED")
            return EvidenceReleaseVerificationDecision(True, "EVIDENCE_RELEASE_VERIFIED")

        distribution = self.distribution_gate.distribute(checkpoint)
        if not distribution.distributed:
            self._verified.pop(checkpoint.checkpoint, None)
            return EvidenceReleaseVerificationDecision(False, "DISTRIBUTION_NOT_VERIFIED")

        if not self.audit.verify():
            self._verified.pop(checkpoint.checkpoint, None)
            return EvidenceReleaseVerificationDecision(False, "AUDIT_CHAIN_INVALID")

        head = self.audit.entries[-1]["hash"] if self.audit.entries else None
        self.audit.append(self.EVENT, {
            "checkpoint": checkpoint.checkpoint,
            "distribution_audit_head": head,
        })
        self._verified[checkpoint.checkpoint] = head or ""
        return EvidenceReleaseVerificationDecision(True, "EVIDENCE_RELEASE_VERIFIED")

    @property
    def verified(self) -> bool:
        return bool(self._verified) and self.audit.verify()
