"""YaqobiTrad v2.02.220 — Provider Failover Evidence Attestation Durability Reconciliation Major Global Checkpoint."""
from __future__ import annotations
import hashlib, json
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT="v2.02.220"; PREDECESSOR="v2.02.219"

@dataclass(frozen=True)
class ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointResult:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"
    activation_gate: str="LOCKED"
    fail_closed: str="ACTIVE"
    open_blocker_count: int=6
    certification: str="PENDING_REAL_PRODUCTION_RESULTS"
    integrity_digest: str=""
    recovery_digest: str=""
    checkpoint_digest: str=""

class ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointV220:
    @staticmethod
    def _digest(value, field):
        if not isinstance(value,str) or len(value)!=64 or any(c not in "0123456789abcdefABCDEF" for c in value):
            raise ValueError(f"V202220_{field.upper()}_DIGEST_INVALID")
        return value.lower()

    @classmethod
    def verify(cls, integrity, *, expected_integrity_digest=None):
        required=("valid","checkpoint","predecessor","checkpoint_digest","integrity_ref","recovery_ref","live_trading","activation_gate","fail_closed")
        if integrity is None or not all(hasattr(integrity,n) for n in required):
            raise ValueError("V202220_INTEGRITY_INTERFACE_INVALID")
        if not integrity.valid:
            raise ValueError("V202220_INTEGRITY_INVALID")
        if (integrity.checkpoint,integrity.predecessor)!=(PREDECESSOR,"v2.02.218"):
            raise ValueError("V202220_INTEGRITY_LINEAGE_INVALID")
        checkpoint_digest=cls._digest(integrity.checkpoint_digest,"checkpoint_digest")
        refs=[integrity.integrity_ref,integrity.recovery_ref]
        if any(not isinstance(x,str) or not x.startswith("evidence://") or "=" in x for x in refs):
            raise ValueError("V202220_EVIDENCE_REF_INVALID")
        if len(set(refs))!=2:
            raise ValueError("V202220_REFERENCE_REUSE_INVALID")
        if (integrity.live_trading,integrity.activation_gate,integrity.fail_closed)!=("SAFE_OFF","LOCKED","ACTIVE"):
            raise ValueError("V202220_SAFETY_STATE_INVALID")
        integrity_digest=hashlib.sha256(json.dumps({"checkpoint":integrity.checkpoint,"predecessor":integrity.predecessor,"checkpoint_digest":checkpoint_digest,"refs":refs},sort_keys=True,separators=(",",":")).encode()).hexdigest()
        if expected_integrity_digest is not None and integrity_digest!=cls._digest(expected_integrity_digest,"integrity_digest"):
            raise ValueError("V202220_INTEGRITY_DIGEST_MISMATCH")
        recovery_digest=hashlib.sha256(integrity.recovery_ref.encode()).hexdigest()
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers):
            raise ValueError("V202220_BLOCKER_STATE_INVALID")
        payload={"checkpoint":CHECKPOINT,"predecessor":PREDECESSOR,"integrity_digest":integrity_digest,"recovery_digest":recovery_digest,"live_trading":"SAFE_OFF","activation_gate":"LOCKED","fail_closed":"ACTIVE"}
        final_digest=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":"),ensure_ascii=True).encode()).hexdigest()
        return ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointResult(True,integrity_digest=integrity_digest,recovery_digest=recovery_digest,checkpoint_digest=final_digest)
