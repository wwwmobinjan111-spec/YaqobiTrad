"""v2.02.62: fail-closed evidence retention integrity boundary."""
from __future__ import annotations

from dataclasses import dataclass

from .audit import AuditLog
from .evidence_retention import RetentionPolicy, retention_blocks_activation


@dataclass(frozen=True)
class RetentionVerification:
    valid: bool
    reason: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"


class EvidenceRetentionGate:
    """Require verified immutable remote retention before evidence is releasable."""

    EVENT = "EVIDENCE_RETENTION_VERIFIED"

    def __init__(self, audit: AuditLog):
        self.audit = audit
        self._verified: bool = False

    def verify(self, policy: RetentionPolicy) -> RetentionVerification:
        if not self.audit.verify():
            self._verified = False
            return RetentionVerification(False, "AUDIT_CHAIN_INVALID")
        if retention_blocks_activation(policy):
            self._verified = False
            return RetentionVerification(False, "RETENTION_POLICY_NOT_VERIFIED")
        self._verified = True
        self.audit.append(self.EVENT, {
            "minimum_days": policy.minimum_days,
            "immutable": policy.immutable,
            "remote": policy.remote,
            "verified": policy.verified,
        })
        return RetentionVerification(True, "RETENTION_VERIFIED")

    @property
    def verified(self) -> bool:
        return self._verified and self.audit.verify()

    def release_allowed(self) -> bool:
        return self.verified
