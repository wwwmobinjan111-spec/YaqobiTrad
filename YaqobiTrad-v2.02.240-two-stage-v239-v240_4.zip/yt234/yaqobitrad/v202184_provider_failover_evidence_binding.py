"""YaqobiTrad v2.02.184 — provider failover evidence binding boundary."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

CHECKPOINT = "v2.02.184"
PREDECESSOR = "v2.02.183"


@dataclass(frozen=True)
class ProviderFailoverEvidenceBindingResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    evidence_ref: str = ""
    evidence_digest: str = ""
    selected_provider: str = ""
    attempted_providers: tuple[str, ...] = ()
    failover_used: bool = False
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"


class ProviderFailoverEvidenceBindingV184:
    """Bind provider-failover verification evidence without enabling trading."""

    @staticmethod
    def _validate_verification(result) -> None:
        required = (
            "valid", "checkpoint", "predecessor", "selected_provider",
            "attempted_providers", "failover_used", "live_trading",
            "activation_gate", "fail_closed",
        )
        if result is None or not all(hasattr(result, n) for n in required):
            raise ValueError("V202184_VERIFICATION_INTERFACE_INVALID")
        if not result.valid:
            raise ValueError("V202184_VERIFICATION_INVALID")
        if (result.checkpoint, result.predecessor) != (PREDECESSOR, "v2.02.182"):
            raise ValueError("V202184_VERIFICATION_LINEAGE_INVALID")
        attempted = result.attempted_providers
        if not isinstance(attempted, tuple) or not attempted or any(
            not isinstance(x, str) or not x.strip() for x in attempted
        ):
            raise ValueError("V202184_PROVIDER_ATTEMPTS_INVALID")
        if len(set(attempted)) != len(attempted):
            raise ValueError("V202184_PROVIDER_ATTEMPTS_DUPLICATE")
        if result.selected_provider not in attempted:
            raise ValueError("V202184_SELECTED_PROVIDER_INVALID")
        if (result.live_trading, result.activation_gate, result.fail_closed) != (
            "SAFE_OFF", "LOCKED", "ACTIVE"
        ):
            raise ValueError("V202184_SAFETY_STATE_INVALID")
        if not isinstance(result.failover_used, bool):
            raise ValueError("V202184_FAILOVER_FLAG_INVALID")

    @classmethod
    def bind(cls, result, *, evidence_ref: str) -> ProviderFailoverEvidenceBindingResult:
        cls._validate_verification(result)
        if not isinstance(evidence_ref, str) or not evidence_ref.strip():
            raise ValueError("V202184_EVIDENCE_REF_INVALID")

        payload = {
            "checkpoint": CHECKPOINT,
            "predecessor": PREDECESSOR,
            "evidence_ref": evidence_ref.strip(),
            "selected_provider": result.selected_provider,
            "attempted_providers": list(result.attempted_providers),
            "failover_used": result.failover_used,
            "live_trading": "SAFE_OFF",
            "activation_gate": "LOCKED",
            "fail_closed": "ACTIVE",
        }
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()
        digest = hashlib.sha256(canonical).hexdigest()
        return ProviderFailoverEvidenceBindingResult(
            valid=True,
            evidence_ref=evidence_ref.strip(),
            evidence_digest=digest,
            selected_provider=result.selected_provider,
            attempted_providers=result.attempted_providers,
            failover_used=result.failover_used,
        )
