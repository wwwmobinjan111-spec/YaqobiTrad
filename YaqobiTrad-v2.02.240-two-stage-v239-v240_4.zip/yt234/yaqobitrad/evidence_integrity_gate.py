"""v2.02.84 — fail-closed evidence integrity gate.

Binds evidence to the current blocker registry and checkpoint safety state.
This gate never closes production blockers and never unlocks live trading.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

from .production_blockers import open_production_blockers
from .global_checkpoint import global_checkpoint, checkpoint_is_fail_closed


@dataclass(frozen=True)
class EvidenceIntegrityDecision:
    valid: bool
    reason: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"


def _canonical(payload: object) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()


def evidence_digest(audit) -> str:
    return hashlib.sha256(_canonical(audit.entries)).hexdigest()


class EvidenceIntegrityGate:
    """Verify evidence has not been altered and safety/blocker state is intact."""

    def __init__(self, audit, checkpoint=None):
        self.audit = audit
        self.checkpoint = checkpoint or global_checkpoint()
        self._sealed_digest = evidence_digest(audit)
        self._blockers = tuple(b.blocker_id for b in open_production_blockers())

    def verify(self) -> EvidenceIntegrityDecision:
        if not self.audit.verify():
            return EvidenceIntegrityDecision(False, "AUDIT_CHAIN_INVALID")
        if evidence_digest(self.audit) != self._sealed_digest:
            return EvidenceIntegrityDecision(False, "EVIDENCE_DIGEST_MISMATCH")
        if tuple(b.blocker_id for b in open_production_blockers()) != self._blockers:
            return EvidenceIntegrityDecision(False, "PRODUCTION_BLOCKER_SET_CHANGED")
        if not checkpoint_is_fail_closed():
            return EvidenceIntegrityDecision(False, "FAIL_CLOSED_STATE_INVALID")
        if self.checkpoint.certification != "PENDING_REAL_PRODUCTION_RESULTS":
            return EvidenceIntegrityDecision(False, "CERTIFICATION_STATE_INVALID")
        return EvidenceIntegrityDecision(True, "EVIDENCE_INTEGRITY_VERIFIED")

    @property
    def intact(self) -> bool:
        return self.verify().valid
