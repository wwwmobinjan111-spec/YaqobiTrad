"""YaqobiTrad v2.02.132 — activation preflight boundary; never authorizes live trading."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT="v2.02.132"
PREDECESSOR="v2.02.131"

@dataclass(frozen=True)
class ActivationPreflightResult:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"
    activation_gate: str="LOCKED"
    fail_closed: str="ACTIVE"
    open_blocker_count: int=6
    certification: str="PENDING_REAL_PRODUCTION_RESULTS"

class ActivationPreflightV132:
    @staticmethod
    def verify(state) -> ActivationPreflightResult:
        if state is None or not all(hasattr(state,n) for n in ("activation_gate","live_trading","fail_closed")):
            raise ValueError("V202132_STATE_INTERFACE_INVALID")
        if state.activation_gate != "LOCKED" or state.live_trading != "SAFE_OFF" or state.fail_closed != "ACTIVE":
            raise ValueError("V202132_SAFETY_STATE_INVALID")
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers):
            raise ValueError("V202132_BLOCKER_STATE_INVALID")
        return ActivationPreflightResult(True)
