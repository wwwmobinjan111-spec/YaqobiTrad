"""YaqobiTrad v2.02.186 — provider failover evidence attestation boundary."""
from __future__ import annotations
import hashlib, json
from dataclasses import dataclass

CHECKPOINT = "v2.02.186"
PREDECESSOR = "v2.02.185"

@dataclass(frozen=True)
class ProviderFailoverEvidenceAttestationResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    continuity_digest: str = ""
    attestation_digest: str = ""
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"

class ProviderFailoverEvidenceAttestationV186:
    """Attest v2.02.185 continuity evidence without changing safety state."""
    @staticmethod
    def _payload(continuity):
        required = ("valid","checkpoint","predecessor","evidence_ref","evidence_digest",
                    "continuity_digest","live_trading","activation_gate","fail_closed")
        if continuity is None or not all(hasattr(continuity, n) for n in required):
            raise ValueError("V202186_CONTINUITY_INTERFACE_INVALID")
        if not continuity.valid:
            raise ValueError("V202186_CONTINUITY_INVALID")
        if (continuity.checkpoint, continuity.predecessor) != (PREDECESSOR, "v2.02.184"):
            raise ValueError("V202186_CONTINUITY_LINEAGE_INVALID")
        if not isinstance(continuity.continuity_digest, str) or len(continuity.continuity_digest) != 64:
            raise ValueError("V202186_CONTINUITY_DIGEST_INVALID")
        if not isinstance(continuity.evidence_digest, str) or len(continuity.evidence_digest) != 64:
            raise ValueError("V202186_EVIDENCE_DIGEST_INVALID")
        if (continuity.live_trading, continuity.activation_gate, continuity.fail_closed) != ("SAFE_OFF","LOCKED","ACTIVE"):
            raise ValueError("V202186_SAFETY_STATE_INVALID")
        return {
            "checkpoint": continuity.checkpoint,
            "predecessor": continuity.predecessor,
            "evidence_ref": continuity.evidence_ref.strip(),
            "evidence_digest": continuity.evidence_digest,
            "continuity_digest": continuity.continuity_digest,
            "live_trading": "SAFE_OFF", "activation_gate": "LOCKED", "fail_closed": "ACTIVE",
        }
    @classmethod
    def attest(cls, continuity, *, expected_continuity_digest=None):
        payload = cls._payload(continuity)
        if expected_continuity_digest is not None and payload["continuity_digest"] != expected_continuity_digest:
            raise ValueError("V202186_CONTINUITY_DIGEST_MISMATCH")
        canonical = json.dumps(payload, sort_keys=True, separators=(",",":"), ensure_ascii=True).encode()
        attestation_digest = hashlib.sha256(canonical).hexdigest()
        return ProviderFailoverEvidenceAttestationResult(valid=True, continuity_digest=payload["continuity_digest"], attestation_digest=attestation_digest)
