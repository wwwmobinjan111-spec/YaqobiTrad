"""YaqobiTrad v2.02.201 — post-checkpoint continuity boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT="v2.02.201"; PREDECESSOR="v2.02.200"
@dataclass(frozen=True)
class ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointContinuityBoundaryResult:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"
    activation_gate: str="LOCKED"
    fail_closed: str="ACTIVE"
    open_blocker_count: int=6
    certification: str="PENDING_REAL_PRODUCTION_RESULTS"
    checkpoint_digest: str=""

class ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointContinuityBoundaryV201:
    @staticmethod
    def _ref(value, field):
        if not isinstance(value,str) or not value.strip() or not value.startswith("evidence://") or "=" in value:
            raise ValueError(f"V202201_{field.upper()}_INVALID")
        return value
    @classmethod
    def verify(cls, state, *, checkpoint_digest, reconciliation_ref, provenance_ref):
        required=("checkpoint","predecessor","live_trading","activation_gate","fail_closed","checkpoint_digest")
        if state is None or not all(hasattr(state,n) for n in required):
            raise ValueError("V202201_STATE_INTERFACE_INVALID")
        if (state.checkpoint,state.predecessor)!=(CHECKPOINT,PREDECESSOR):
            raise ValueError("V202201_LINEAGE_INVALID")
        if (state.live_trading,state.activation_gate,state.fail_closed)!=("SAFE_OFF","LOCKED","ACTIVE"):
            raise ValueError("V202201_SAFETY_STATE_INVALID")
        for k,v in {"checkpoint_digest":checkpoint_digest,"reconciliation_ref":reconciliation_ref,"provenance_ref":provenance_ref}.items():
            if k=="checkpoint_digest":
                if not isinstance(v,str) or len(v)!=64 or any(c not in "0123456789abcdefABCDEF" for c in v):
                    raise ValueError("V202201_CHECKPOINT_DIGEST_INVALID")
            else: cls._ref(v,k)
        if checkpoint_digest.lower()!=state.checkpoint_digest.lower():
            raise ValueError("V202201_CHECKPOINT_DIGEST_MISMATCH")
        if reconciliation_ref==provenance_ref:
            raise ValueError("V202201_REFERENCE_REUSE_INVALID")
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers):
            raise ValueError("V202201_BLOCKER_STATE_INVALID")
        return ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointContinuityBoundaryResult(True,checkpoint_digest=checkpoint_digest.lower())
