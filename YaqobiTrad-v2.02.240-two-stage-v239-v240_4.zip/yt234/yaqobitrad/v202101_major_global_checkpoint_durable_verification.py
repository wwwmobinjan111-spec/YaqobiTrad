"""YaqobiTrad v2.02.101 — durable verification of the v2.02.100 checkpoint."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json

from .audit import AuditLog
from .production_blockers import open_production_blockers

CHECKPOINT = "v2.02.101"
PREDECESSOR = "v2.02.100"
ATTESTATION_SCHEMA = "v2.02.99"
ATTESTATION_EVENT = "MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED"

@dataclass(frozen=True)
class DurableCheckpointResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    open_blocker_count: int = 6
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"
    checkpoint_digest: str = ""

class MajorGlobalCheckpointDurableVerification:
    """Read-only reload/reverification gate; it never mutates the audit ledger."""
    @staticmethod
    def _canonical(anchor_hash, bound_hash, evidence_digest, continuity_hash, blockers):
        return {
            "checkpoint": CHECKPOINT,
            "predecessor": PREDECESSOR,
            "anchor_hash": anchor_hash,
            "bound_audit_hash": bound_hash,
            "evidence_digest": evidence_digest,
            "continuity_hash": continuity_hash,
            "blockers": [b.blocker_id for b in blockers],
            "safety": {"live_trading":"SAFE_OFF","activation_gate":"LOCKED","fail_closed":"ACTIVE"},
            "certification": "PENDING_REAL_PRODUCTION_RESULTS",
        }

    def verify(self, audit_path: str, *, expected_anchor_hash: str,
               expected_bound_audit_hash: str, expected_evidence_digest: str,
               expected_checkpoint_digest: str) -> DurableCheckpointResult:
        first = AuditLog(audit_path)
        if not first.verify():
            raise ValueError("V202101_AUDIT_CHAIN_INVALID")
        blockers = open_production_blockers()
        if len(blockers) != 6 or any(b.state != "OPEN" for b in blockers):
            raise ValueError("V202101_BLOCKER_STATE_INVALID")
        anchors = [e for e in first.entries if e.get("event") == ATTESTATION_EVENT]
        if len(anchors) != 1 or not first.entries or first.entries[-1] is not anchors[0]:
            raise ValueError("V202101_TERMINAL_ATTESTATION_INVALID")
        anchor = anchors[0]
        data = anchor.get("data", {})
        if data.get("schema_version") != ATTESTATION_SCHEMA:
            raise ValueError("V202101_PREDECESSOR_SCHEMA_INVALID")
        if anchor.get("hash") != expected_anchor_hash:
            raise ValueError("V202101_ANCHOR_HASH_MISMATCH")
        if data.get("bound_audit_hash") != expected_bound_audit_hash:
            raise ValueError("V202101_BOUND_AUDIT_HASH_MISMATCH")
        if data.get("evidence_digest") != expected_evidence_digest:
            raise ValueError("V202101_EVIDENCE_DIGEST_MISMATCH")
        if len(first.entries) < 2 or data.get("continuity_hash") != first.entries[-2].get("hash"):
            raise ValueError("V202101_CONTINUITY_LINK_INVALID")
        canonical = self._canonical(expected_anchor_hash, expected_bound_audit_hash,
                                    expected_evidence_digest, data["continuity_hash"], blockers)
        digest = hashlib.sha256(json.dumps(canonical, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        if digest != expected_checkpoint_digest:
            raise ValueError("V202101_CHECKPOINT_DIGEST_MISMATCH")

        # Independent durable reload: the persisted ledger must reproduce the same state.
        second = AuditLog(audit_path)
        if second.entries != first.entries or second.prev_hash != first.prev_hash:
            raise ValueError("V202101_RELOAD_STATE_MISMATCH")
        if not second.verify():
            raise ValueError("V202101_RELOADED_AUDIT_INVALID")
        return DurableCheckpointResult(True, checkpoint_digest=digest)
