"""YaqobiTrad v2.02.232 — Provider Failover Evidence Attestation Durability Reconciliation Recovery Replay Boundary."""
from __future__ import annotations
import hashlib, json
from dataclasses import dataclass
from .production_blockers import open_production_blockers
CHECKPOINT="v2.02.232"; PREDECESSOR="v2.02.231"
@dataclass(frozen=True)
class Result:
    valid: bool; checkpoint: str=CHECKPOINT; predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"; activation_gate: str="LOCKED"; fail_closed: str="ACTIVE"
    open_blocker_count: int=6; certification: str="PENDING_REAL_PRODUCTION_RESULTS"
    continuity_digest: str=""; replay_digest: str=""; checkpoint_digest: str=""
class ProviderFailoverEvidenceAttestationDurabilityReconciliationRecoveryReplayBoundaryV232:
    @staticmethod
    def _digest(v,f):
        if not isinstance(v,str) or len(v)!=64 or any(c not in "0123456789abcdefABCDEF" for c in v): raise ValueError(f"V202232_{f.upper()}_DIGEST_INVALID")
        return v.lower()
    @classmethod
    def verify(cls, continuity, *, expected_continuity_digest=None):
        req=("valid","checkpoint","predecessor","checkpoint_digest","predecessor_digest","recovery_continuity_digest","live_trading","activation_gate","fail_closed")
        if continuity is None or not all(hasattr(continuity,n) for n in req): raise ValueError("V202232_CONTINUITY_INTERFACE_INVALID")
        if not continuity.valid: raise ValueError("V202232_CONTINUITY_INVALID")
        if (continuity.checkpoint,continuity.predecessor)!=(PREDECESSOR,"v2.02.230"): raise ValueError("V202232_LINEAGE_INVALID")
        if (continuity.live_trading,continuity.activation_gate,continuity.fail_closed)!=("SAFE_OFF","LOCKED","ACTIVE"): raise ValueError("V202232_SAFETY_STATE_INVALID")
        cd=cls._digest(continuity.checkpoint_digest,"checkpoint_digest"); pd=cls._digest(continuity.predecessor_digest,"predecessor_digest"); rd=cls._digest(continuity.recovery_continuity_digest,"continuity_digest")
        if expected_continuity_digest is not None and rd!=cls._digest(expected_continuity_digest,"continuity_digest"): raise ValueError("V202232_CONTINUITY_DIGEST_MISMATCH")
        replay=hashlib.sha256(json.dumps({"checkpoint":PREDECESSOR,"predecessor":"v2.02.230","checkpoint_digest":cd,"predecessor_digest":pd,"continuity_digest":rd,"live_trading":"SAFE_OFF","activation_gate":"LOCKED","fail_closed":"ACTIVE"},sort_keys=True,separators=(",",":"),ensure_ascii=True).encode()).hexdigest()
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers): raise ValueError("V202232_BLOCKER_STATE_INVALID")
        fd=hashlib.sha256(json.dumps({"checkpoint":CHECKPOINT,"predecessor":PREDECESSOR,"continuity_digest":rd,"replay_digest":replay,"live_trading":"SAFE_OFF","activation_gate":"LOCKED","fail_closed":"ACTIVE"},sort_keys=True,separators=(",",":"),ensure_ascii=True).encode()).hexdigest()
        return Result(True,continuity_digest=rd,replay_digest=replay,checkpoint_digest=fd)
