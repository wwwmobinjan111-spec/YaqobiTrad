"""YaqobiTrad v2.02.149 — security incident evidence attestation recovery continuity boundary.

Source-level boundary only. It validates recovery-continuity evidence references,
preserves the production fail-closed state, and does not claim production deployment
or closure of any production blocker.
"""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT = "v2.02.149"
PREDECESSOR = "v2.02.148"

@dataclass(frozen=True)
class SecurityIncidentEvidenceAttestationRecoveryContinuityBoundaryResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    open_blocker_count: int = 6
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"
    integrity_ref: str = ""
    recovery_ref: str = ""

class SecurityIncidentEvidenceAttestationRecoveryContinuityBoundaryV149:
    @staticmethod
    def _ref(value: str, field: str) -> str:
        if not isinstance(value, str) or not value.strip() or not value.startswith("evidence://"):
            raise ValueError(f"V202149_{field.upper()}_INVALID")
        if "=" in value or any(token in value.upper() for token in ("TOKEN", "SECRET", "PASSWORD", "PRIVATE_KEY")):
            raise ValueError(f"V202149_{field.upper()}_SECRET_OR_ASSIGNMENT_INVALID")
        return value

    @classmethod
    def verify(cls, state, *, integrity_ref: str, recovery_ref: str):
        if state is None or not all(hasattr(state, n) for n in ("activation_gate", "live_trading", "fail_closed")):
            raise ValueError("V202149_STATE_INTERFACE_INVALID")
        if (state.activation_gate, state.live_trading, state.fail_closed) != ("LOCKED", "SAFE_OFF", "ACTIVE"):
            raise ValueError("V202149_SAFETY_STATE_INVALID")
        integrity_ref = cls._ref(integrity_ref, "integrity_ref")
        recovery_ref = cls._ref(recovery_ref, "recovery_ref")
        blockers = open_production_blockers()
        if len(blockers) != 6 or any(b.state != "OPEN" for b in blockers):
            raise ValueError("V202149_BLOCKER_STATE_INVALID")
        return SecurityIncidentEvidenceAttestationRecoveryContinuityBoundaryResult(
            True, integrity_ref=integrity_ref, recovery_ref=recovery_ref
        )
