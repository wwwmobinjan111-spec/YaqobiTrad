"""YaqobiTrad v2.02.141 — security incident/audit evidence pipeline boundary.

Source-level boundary only. It validates non-secret evidence references and
preserves the production fail-closed state. It does not claim that a real
production security incident/audit evidence pipeline has been deployed or
that any production security blocker has been closed.
"""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT = "v2.02.141"
PREDECESSOR = "v2.02.140"

@dataclass(frozen=True)
class SecurityIncidentAuditEvidencePipelineBoundaryResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    open_blocker_count: int = 6
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"

class SecurityIncidentAuditEvidencePipelineBoundaryV141:
    @staticmethod
    def verify(state, *, incident_ref: str | None = None,
               audit_evidence_ref: str | None = None) -> SecurityIncidentAuditEvidencePipelineBoundaryResult:
        if state is None or not all(hasattr(state, n) for n in ("activation_gate", "live_trading", "fail_closed")):
            raise ValueError("V202141_STATE_INTERFACE_INVALID")
        if state.activation_gate != "LOCKED" or state.live_trading != "SAFE_OFF" or state.fail_closed != "ACTIVE":
            raise ValueError("V202141_SAFETY_STATE_INVALID")
        for name, value in (("incident_ref", incident_ref), ("audit_evidence_ref", audit_evidence_ref)):
            if value is not None:
                if not isinstance(value, str) or not value.strip() or "=" in value or len(value.strip()) < 3:
                    raise ValueError(f"V202141_{name.upper()}_INVALID")
        blockers = open_production_blockers()
        if len(blockers) != 6 or any(b.state != "OPEN" for b in blockers):
            raise ValueError("V202141_BLOCKER_STATE_INVALID")
        return SecurityIncidentAuditEvidencePipelineBoundaryResult(True)
