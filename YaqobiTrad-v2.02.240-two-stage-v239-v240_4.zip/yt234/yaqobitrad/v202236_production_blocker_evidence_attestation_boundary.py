"""YaqobiTrad v2.02.236 — production blocker evidence attestation boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT='v2.02.236'; PREDECESSOR='v2.02.235'
@dataclass(frozen=True)
class Result:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str='SAFE_OFF'
    activation_gate: str='LOCKED'
    fail_closed: str='ACTIVE'
    open_blocker_count: int=6
    certification: str='PENDING_REAL_PRODUCTION_RESULTS'
    attestation_authority: str='REAL_PRODUCTION_EVIDENCE_ONLY'

class ProductionBlockerEvidenceAttestationBoundaryV236:
    @staticmethod
    def verify(checkpoint, *, evidence_attested=False):
        req=('valid','checkpoint','predecessor','live_trading','activation_gate','fail_closed')
        if checkpoint is None or not all(hasattr(checkpoint,n) for n in req): raise ValueError('V202236_CHECKPOINT_INTERFACE_INVALID')
        if not checkpoint.valid or checkpoint.checkpoint!='v2.02.235' or checkpoint.predecessor!='v2.02.234': raise ValueError('V202236_LINEAGE_INVALID')
        if (checkpoint.live_trading,checkpoint.activation_gate,checkpoint.fail_closed)!=('SAFE_OFF','LOCKED','ACTIVE'): raise ValueError('V202236_SAFETY_STATE_INVALID')
        if len(open_production_blockers())!=6: raise ValueError('V202236_BLOCKER_COUNT_INVALID')
        if evidence_attested is True: raise ValueError('V202236_REAL_PRODUCTION_ATTESTATION_REQUIRED')
        return Result(True)
