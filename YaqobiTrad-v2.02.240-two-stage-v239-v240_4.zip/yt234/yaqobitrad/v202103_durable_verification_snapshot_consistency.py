"""YaqobiTrad v2.02.103 — durable verification snapshot consistency."""
from __future__ import annotations
from dataclasses import dataclass
import copy, hashlib, json
from .audit import AuditLog
from .production_blockers import open_production_blockers

CHECKPOINT="v2.02.103"; PREDECESSOR="v2.02.102"; ATTESTATION_SCHEMA="v2.02.99"; ATTESTATION_EVENT="MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED"
@dataclass(frozen=True)
class SnapshotConsistencyResult:
    valid: bool
    checkpoint: str=CHECKPOINT; predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"; activation_gate: str="LOCKED"; fail_closed: str="ACTIVE"
    open_blocker_count: int=6; certification: str="PENDING_REAL_PRODUCTION_RESULTS"; snapshot_digest: str=""
class DurableVerificationSnapshotConsistency:
    @staticmethod
    def _snapshot(a): return {"entries":copy.deepcopy(a.entries),"prev_hash":a.prev_hash}
    @staticmethod
    def _digest(s): return hashlib.sha256(json.dumps(s,sort_keys=True,separators=(",",":")).encode()).hexdigest()
    def verify(self,audit_path,*,expected_anchor_hash,expected_bound_audit_hash,expected_evidence_digest,expected_snapshot_digest):
        a=AuditLog(audit_path)
        if not a.verify(): raise ValueError("V202103_AUDIT_CHAIN_INVALID")
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers): raise ValueError("V202103_BLOCKER_STATE_INVALID")
        anchors=[e for e in a.entries if e.get("event")==ATTESTATION_EVENT]
        if len(anchors)!=1 or not a.entries or a.entries[-1] is not anchors[0]: raise ValueError("V202103_TERMINAL_ATTESTATION_INVALID")
        anchor=anchors[0]; d=anchor.get("data",{})
        if d.get("schema_version")!=ATTESTATION_SCHEMA: raise ValueError("V202103_PREDECESSOR_SCHEMA_INVALID")
        if anchor.get("hash")!=expected_anchor_hash: raise ValueError("V202103_ANCHOR_HASH_MISMATCH")
        if d.get("bound_audit_hash")!=expected_bound_audit_hash: raise ValueError("V202103_BOUND_AUDIT_HASH_MISMATCH")
        if d.get("evidence_digest")!=expected_evidence_digest: raise ValueError("V202103_EVIDENCE_DIGEST_MISMATCH")
        if len(a.entries)<2 or d.get("continuity_hash")!=a.entries[-2].get("hash"): raise ValueError("V202103_CONTINUITY_LINK_INVALID")
        s=self._snapshot(a); digest=self._digest(s)
        if digest!=expected_snapshot_digest: raise ValueError("V202103_SNAPSHOT_DIGEST_MISMATCH")
        reloads=[AuditLog(audit_path) for _ in range(3)]
        for r in reloads:
            if r.entries!=a.entries or r.prev_hash!=a.prev_hash: raise ValueError("V202103_RELOAD_STATE_MISMATCH")
            if self._digest(self._snapshot(r))!=digest: raise ValueError("V202103_RELOAD_DIGEST_MISMATCH")
        # Deep-copy isolation must not mutate durable source.
        isolated=self._snapshot(a); isolated["entries"][-1]["data"]["evidence_digest"]="MUTATION_SENTINEL"
        if a.entries[-1]["data"].get("evidence_digest")!=expected_evidence_digest: raise ValueError("V202103_SNAPSHOT_MUTATION_LEAK")
        return SnapshotConsistencyResult(True,snapshot_digest=digest)
