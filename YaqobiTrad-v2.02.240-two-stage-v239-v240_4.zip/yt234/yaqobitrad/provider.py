"""Read-only Binance public market-data provider and freshness bridge."""
from __future__ import annotations
import json
from time import time
import time as _time
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from .market import Candle, validate_candle

class BinancePublicProvider:
    """Read-only public Binance klines adapter; never submits orders."""
    def __init__(self, base_url="https://api.binance.com", timeout=5.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = float(timeout)

    def fetch_latest_closed_candle(self, symbol: str, interval: str = "1m") -> Candle:
        if not symbol or not interval:
            raise ValueError("symbol and interval are required")
        qs = urlencode({"symbol": symbol.upper(), "interval": interval, "limit": 2})
        req = Request(f"{self.base_url}/api/v3/klines?{qs}", headers={"User-Agent": "YaqobiTrad-readonly/1"})
        with urlopen(req, timeout=self.timeout) as resp:
            rows = json.loads(resp.read().decode("utf-8"))
        if not isinstance(rows, list) or not rows:
            raise ValueError("invalid Binance kline response")
        now_ms = int(_time.time() * 1000)
        closed_rows = [r for r in rows if len(r) >= 7 and int(r[6]) <= now_ms]
        if not closed_rows:
            raise ValueError("no closed Binance kline available")
        row = closed_rows[-1]
        if len(row) < 7:
            raise ValueError("invalid Binance kline row")
        candle = Candle(
            open_time=int(row[0]), close_time=int(row[6]),
            open=float(row[1]), high=float(row[2]), low=float(row[3]),
            close=float(row[4]), volume=float(row[5]),
            closed=True,
        )
        ok, reason = validate_candle(candle)
        if not ok:
            raise ValueError(reason)
        return candle

class ProviderFreshnessBridge:
    def __init__(self, max_age_seconds: float = 90.0):
        if max_age_seconds < 0:
            raise ValueError("max_age_seconds must be non-negative")
        self.max_age_seconds = float(max_age_seconds)
        self.last_close_ms: int | None = None

    def observe(self, candle: Candle) -> bool:
        if self.last_close_ms is not None and candle.close_time <= self.last_close_ms:
            return False
        self.last_close_ms = candle.close_time
        return True

    def is_fresh(self, now_ms: int | None = None) -> bool:
        if self.last_close_ms is None:
            return False
        now = int(time() * 1000) if now_ms is None else int(now_ms)
        return now - self.last_close_ms <= self.max_age_seconds * 1000

    def fail_closed_state(self) -> dict[str, str]:
        if not self.is_fresh():
            return {"live_trading":"SAFE_OFF","activation_gate":"LOCKED","state":"BLOCKED"}
        return {"live_trading":"SAFE_OFF","activation_gate":"LOCKED","state":"OBSERVABLE"}
