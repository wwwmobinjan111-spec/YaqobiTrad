"""YaqobiTrad v2.02.185 — provider failover evidence continuity boundary."""
from __future__ import annotations
import hashlib
import json
from dataclasses import dataclass

CHECKPOINT = "v2.02.185"
PREDECESSOR = "v2.02.184"

@dataclass(frozen=True)
class ProviderFailoverEvidenceContinuityResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    evidence_ref: str = ""
    evidence_digest: str = ""
    continuity_digest: str = ""
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"

class ProviderFailoverEvidenceContinuityV185:
    """Verify that v2.02.184 evidence can be replayed without mutation or activation."""
    @staticmethod
    def _payload(binding):
        required = ("valid","checkpoint","predecessor","evidence_ref","evidence_digest",
                    "selected_provider","attempted_providers","failover_used",
                    "live_trading","activation_gate","fail_closed")
        if binding is None or not all(hasattr(binding, n) for n in required):
            raise ValueError("V202185_BINDING_INTERFACE_INVALID")
        if not binding.valid:
            raise ValueError("V202185_BINDING_INVALID")
        if (binding.checkpoint, binding.predecessor) != (PREDECESSOR, "v2.02.183"):
            raise ValueError("V202185_BINDING_LINEAGE_INVALID")
        if not isinstance(binding.evidence_ref, str) or not binding.evidence_ref.strip():
            raise ValueError("V202185_EVIDENCE_REF_INVALID")
        if not isinstance(binding.evidence_digest, str) or len(binding.evidence_digest) != 64:
            raise ValueError("V202185_EVIDENCE_DIGEST_INVALID")
        if (binding.live_trading, binding.activation_gate, binding.fail_closed) != ("SAFE_OFF","LOCKED","ACTIVE"):
            raise ValueError("V202185_SAFETY_STATE_INVALID")
        return {
            "checkpoint": binding.checkpoint, "predecessor": binding.predecessor,
            "evidence_ref": binding.evidence_ref.strip(), "evidence_digest": binding.evidence_digest,
            "selected_provider": binding.selected_provider,
            "attempted_providers": list(binding.attempted_providers),
            "failover_used": binding.failover_used,
            "live_trading": "SAFE_OFF", "activation_gate": "LOCKED", "fail_closed": "ACTIVE",
        }
    @classmethod
    def verify(cls, binding, *, expected_evidence_digest=None):
        payload = cls._payload(binding)
        if expected_evidence_digest is not None and payload["evidence_digest"] != expected_evidence_digest:
            raise ValueError("V202185_EVIDENCE_DIGEST_MISMATCH")
        canonical = json.dumps(payload, sort_keys=True, separators=(",",":"), ensure_ascii=True).encode()
        continuity_digest = hashlib.sha256(canonical).hexdigest()
        return ProviderFailoverEvidenceContinuityResult(
            valid=True, evidence_ref=payload["evidence_ref"],
            evidence_digest=payload["evidence_digest"], continuity_digest=continuity_digest)
