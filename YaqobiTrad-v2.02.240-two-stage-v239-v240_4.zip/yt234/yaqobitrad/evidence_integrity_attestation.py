"""v2.02.85 — fail-closed evidence integrity attestation.

Creates a portable attestation from a verified v2.02.84 evidence-integrity
state and revalidates the exact evidence digest, production blocker set, and
checkpoint safety state. Attestation never closes blockers or unlocks trading.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

from .evidence_integrity_gate import EvidenceIntegrityGate, evidence_digest
from .production_blockers import open_production_blockers
from .global_checkpoint import global_checkpoint, checkpoint_is_fail_closed


@dataclass(frozen=True)
class EvidenceIntegrityAttestation:
    checkpoint: str
    evidence_digest: str
    blocker_ids: tuple[str, ...]
    activation_gate: str
    fail_closed: str
    live_trading: str
    attestation_digest: str


@dataclass(frozen=True)
class EvidenceIntegrityAttestationDecision:
    valid: bool
    reason: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"


def _canonical(payload: object) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()


def _attestation_digest(*, checkpoint: str, digest: str, blocker_ids: tuple[str, ...],
                        activation_gate: str, fail_closed: str, live_trading: str) -> str:
    payload = {
        "checkpoint": checkpoint,
        "evidence_digest": digest,
        "blocker_ids": blocker_ids,
        "activation_gate": activation_gate,
        "fail_closed": fail_closed,
        "live_trading": live_trading,
    }
    return hashlib.sha256(_canonical(payload)).hexdigest()


class EvidenceIntegrityAttestationGate:
    """Attest and later revalidate a previously verified evidence state."""

    def __init__(self, audit, checkpoint=None):
        self.audit = audit
        self.checkpoint = checkpoint or global_checkpoint()
        self._attestation: EvidenceIntegrityAttestation | None = None

    def attest(self) -> tuple[EvidenceIntegrityAttestation | None, EvidenceIntegrityAttestationDecision]:
        integrity = EvidenceIntegrityGate(self.audit, self.checkpoint).verify()
        if not integrity.valid:
            return None, EvidenceIntegrityAttestationDecision(False, integrity.reason)
        blocker_ids = tuple(b.blocker_id for b in open_production_blockers())
        digest = evidence_digest(self.audit)
        attestation = EvidenceIntegrityAttestation(
            checkpoint=self.checkpoint.checkpoint,
            evidence_digest=digest,
            blocker_ids=blocker_ids,
            activation_gate=self.checkpoint.activation_gate,
            fail_closed=self.checkpoint.fail_closed,
            live_trading=self.checkpoint.live_trading,
            attestation_digest=_attestation_digest(
                checkpoint=self.checkpoint.checkpoint,
                digest=digest,
                blocker_ids=blocker_ids,
                activation_gate=self.checkpoint.activation_gate,
                fail_closed=self.checkpoint.fail_closed,
                live_trading=self.checkpoint.live_trading,
            ),
        )
        self._attestation = attestation
        return attestation, EvidenceIntegrityAttestationDecision(True, "EVIDENCE_INTEGRITY_ATTESTED")

    def verify(self, attestation: EvidenceIntegrityAttestation | None = None) -> EvidenceIntegrityAttestationDecision:
        target = attestation or self._attestation
        if target is None:
            return EvidenceIntegrityAttestationDecision(False, "ATTESTATION_MISSING")
        if not self.audit.verify():
            return EvidenceIntegrityAttestationDecision(False, "AUDIT_CHAIN_INVALID")
        expected = _attestation_digest(
            checkpoint=target.checkpoint,
            digest=target.evidence_digest,
            blocker_ids=target.blocker_ids,
            activation_gate=target.activation_gate,
            fail_closed=target.fail_closed,
            live_trading=target.live_trading,
        )
        if expected != target.attestation_digest:
            return EvidenceIntegrityAttestationDecision(False, "ATTESTATION_DIGEST_MISMATCH")
        if evidence_digest(self.audit) != target.evidence_digest:
            return EvidenceIntegrityAttestationDecision(False, "EVIDENCE_DIGEST_MISMATCH")
        if tuple(b.blocker_id for b in open_production_blockers()) != target.blocker_ids:
            return EvidenceIntegrityAttestationDecision(False, "PRODUCTION_BLOCKER_SET_CHANGED")
        checkpoint = self.checkpoint
        if checkpoint.checkpoint != target.checkpoint:
            return EvidenceIntegrityAttestationDecision(False, "CHECKPOINT_IDENTITY_CHANGED")
        if (checkpoint.activation_gate, checkpoint.fail_closed, checkpoint.live_trading) != (
            target.activation_gate, target.fail_closed, target.live_trading
        ):
            return EvidenceIntegrityAttestationDecision(False, "CHECKPOINT_SAFETY_STATE_CHANGED")
        if not checkpoint_is_fail_closed():
            return EvidenceIntegrityAttestationDecision(False, "FAIL_CLOSED_STATE_INVALID")
        return EvidenceIntegrityAttestationDecision(True, "EVIDENCE_INTEGRITY_ATTESTATION_VERIFIED")

    @property
    def attested(self) -> bool:
        return self._attestation is not None and self.verify().valid
