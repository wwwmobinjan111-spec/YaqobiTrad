"""v2.02.66: fail-closed evidence release commitment boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .evidence_release_finalization_gate import EvidenceReleaseFinalizationGate

@dataclass(frozen=True)
class EvidenceReleaseCommitmentDecision:
    committed: bool
    reason: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"

class EvidenceReleaseCommitmentGate:
    """Commit an evidence release only after successful finalization."""

    EVENT = "EVIDENCE_RELEASE_COMMITTED"

    def __init__(self, audit, finalization_gate: EvidenceReleaseFinalizationGate):
        self.audit = audit
        self.finalization_gate = finalization_gate
        self._committed: dict[str, str] = {}

    def commit(self, checkpoint) -> EvidenceReleaseCommitmentDecision:
        if not self.audit.verify():
            self._committed.pop(checkpoint.checkpoint, None)
            return EvidenceReleaseCommitmentDecision(False, "AUDIT_CHAIN_INVALID")

        existing = self._committed.get(checkpoint.checkpoint)
        if existing is not None:
            if not self.finalization_gate.finalized:
                self._committed.pop(checkpoint.checkpoint, None)
                return EvidenceReleaseCommitmentDecision(False, "FINALIZATION_NOT_VERIFIED")
            return EvidenceReleaseCommitmentDecision(True, "EVIDENCE_RELEASE_COMMITTED")

        finalization = self.finalization_gate.finalize(checkpoint)
        if not finalization.finalized:
            self._committed.pop(checkpoint.checkpoint, None)
            return EvidenceReleaseCommitmentDecision(False, "FINALIZATION_NOT_VERIFIED")

        if not self.audit.verify():
            self._committed.pop(checkpoint.checkpoint, None)
            return EvidenceReleaseCommitmentDecision(False, "AUDIT_CHAIN_INVALID")

        head = self.audit.entries[-1]["hash"] if self.audit.entries else None
        self.audit.append(self.EVENT, {
            "checkpoint": checkpoint.checkpoint,
            "finalization_audit_head": head,
        })
        self._committed[checkpoint.checkpoint] = head or ""
        return EvidenceReleaseCommitmentDecision(True, "EVIDENCE_RELEASE_COMMITTED")

    @property
    def committed(self) -> bool:
        return bool(self._committed) and self.audit.verify()
