"""v2.02.63: fail-closed evidence release authorization boundary."""
from __future__ import annotations

from dataclasses import dataclass

from .evidence_retention_gate import EvidenceRetentionGate
from .checkpoint_evidence_seal import CheckpointEvidenceSealer


@dataclass(frozen=True)
class EvidenceReleaseDecision:
    allowed: bool
    reason: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"


class EvidenceReleaseGate:
    """Release evidence only when retention and checkpoint evidence are intact."""

    EVENT = "EVIDENCE_RELEASE_AUTHORIZED"

    def __init__(self, audit, retention_gate: EvidenceRetentionGate, sealer: CheckpointEvidenceSealer):
        self.audit = audit
        self.retention_gate = retention_gate
        self.sealer = sealer
        self._authorized = False

    def authorize(self, checkpoint) -> EvidenceReleaseDecision:
        self._authorized = False
        if not self.audit.verify():
            return EvidenceReleaseDecision(False, "AUDIT_CHAIN_INVALID")
        if not self.retention_gate.release_allowed():
            return EvidenceReleaseDecision(False, "RETENTION_NOT_VERIFIED")
        if not self.sealer.verify(checkpoint):
            return EvidenceReleaseDecision(False, "CHECKPOINT_EVIDENCE_INVALID")
        self.audit.append(self.EVENT, {"checkpoint": checkpoint.checkpoint})
        self._authorized = True
        return EvidenceReleaseDecision(True, "EVIDENCE_RELEASE_AUTHORIZED")

    @property
    def authorized(self) -> bool:
        return self._authorized and self.audit.verify()
