from dataclasses import dataclass


@dataclass(frozen=True)
class SecurityIncidentEvidenceRecoveryVerificationAttestationResultV145:
    valid: bool
    open_blocker_count: int
    live_trading: str
    activation_gate: str
    fail_closed: str
    predecessor: str
    attestation_ref: str


class SecurityIncidentEvidenceRecoveryVerificationAttestationBoundaryV145:
    """Fail-closed attestation boundary for v2.02.144 recovery verification evidence."""

    PREDECESSOR = "v2.02.144"
    REQUIRED_BLOCKER_COUNT = 6

    @staticmethod
    def _validate_ref(value: str, field: str) -> str:
        if not isinstance(value, str) or not value.startswith("evidence://"):
            raise ValueError(f"{field} must use an evidence:// reference")
        if any(token in value.upper() for token in ("TOKEN=", "SECRET=", "PASSWORD=", "PRIVATE_KEY=")):
            raise ValueError(f"{field} must not contain plaintext secret material")
        return value

    @classmethod
    def verify(cls, state, *, recovery_ref: str, verification_ref: str, attestation_ref: str):
        recovery_ref = cls._validate_ref(recovery_ref, "recovery_ref")
        verification_ref = cls._validate_ref(verification_ref, "verification_ref")
        attestation_ref = cls._validate_ref(attestation_ref, "attestation_ref")

        if getattr(state, "activation_gate", None) != "LOCKED":
            raise ValueError("activation gate must remain LOCKED")
        if getattr(state, "live_trading", None) != "SAFE_OFF":
            raise ValueError("live trading must remain SAFE_OFF")
        if getattr(state, "fail_closed", None) != "ACTIVE":
            raise ValueError("fail-closed must remain ACTIVE")

        return SecurityIncidentEvidenceRecoveryVerificationAttestationResultV145(
            valid=True,
            open_blocker_count=cls.REQUIRED_BLOCKER_COUNT,
            live_trading=state.live_trading,
            activation_gate=state.activation_gate,
            fail_closed=state.fail_closed,
            predecessor=cls.PREDECESSOR,
            attestation_ref=attestation_ref,
        )
