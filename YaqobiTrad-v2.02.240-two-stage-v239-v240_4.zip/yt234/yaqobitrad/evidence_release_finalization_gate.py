"""v2.02.65: fail-closed evidence release finalization boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .evidence_release_reconciliation_gate import EvidenceReleaseReconciliationGate

@dataclass(frozen=True)
class EvidenceReleaseFinalizationDecision:
    finalized: bool
    reason: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"

class EvidenceReleaseFinalizationGate:
    """Finalize an evidence release only after successful reconciliation."""

    EVENT = "EVIDENCE_RELEASE_FINALIZED"

    def __init__(self, audit, reconciliation_gate: EvidenceReleaseReconciliationGate):
        self.audit = audit
        self.reconciliation_gate = reconciliation_gate
        self._finalized: dict[str, str] = {}

    def finalize(self, checkpoint) -> EvidenceReleaseFinalizationDecision:
        if not self.audit.verify():
            self._finalized.pop(checkpoint.checkpoint, None)
            return EvidenceReleaseFinalizationDecision(False, "AUDIT_CHAIN_INVALID")

        existing = self._finalized.get(checkpoint.checkpoint)
        if existing is not None:
            if not self.reconciliation_gate.reconciled:
                self._finalized.pop(checkpoint.checkpoint, None)
                return EvidenceReleaseFinalizationDecision(False, "RECONCILIATION_NOT_VERIFIED")
            return EvidenceReleaseFinalizationDecision(True, "EVIDENCE_RELEASE_FINALIZED")

        reconciliation = self.reconciliation_gate.reconcile(checkpoint)
        if not reconciliation.reconciled:
            self._finalized.pop(checkpoint.checkpoint, None)
            return EvidenceReleaseFinalizationDecision(False, "RECONCILIATION_NOT_VERIFIED")

        if not self.audit.verify():
            self._finalized.pop(checkpoint.checkpoint, None)
            return EvidenceReleaseFinalizationDecision(False, "AUDIT_CHAIN_INVALID")

        head = self.audit.entries[-1]["hash"] if self.audit.entries else None
        self.audit.append(self.EVENT, {
            "checkpoint": checkpoint.checkpoint,
            "reconciliation_audit_head": head,
        })
        self._finalized[checkpoint.checkpoint] = head or ""
        return EvidenceReleaseFinalizationDecision(True, "EVIDENCE_RELEASE_FINALIZED")

    @property
    def finalized(self) -> bool:
        return bool(self._finalized) and self.audit.verify()
