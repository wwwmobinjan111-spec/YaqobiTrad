"""YaqobiTrad v2.02.91 — Production Monitoring Evidence Boundary.

This source-level boundary validates monitoring evidence before it can be
treated as activation evidence. It never closes the production monitoring
blocker and remains fail-closed when evidence is missing, stale, malformed,
or unhealthy.
"""
from dataclasses import dataclass
from typing import Mapping, Any
from .monitoring import MonitoringState
from .production_blockers import open_production_blockers

@dataclass(frozen=True)
class MonitoringEvidenceResult:
    valid: bool
    reason: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"

class MonitoringEvidenceBoundary:
    REQUIRED_KEYS = ("timestamp", "healthy", "heartbeat")

    def __init__(self, state: MonitoringState):
        self.state = state

    def verify(self, evidence: Mapping[str, Any], now: float, max_age: float) -> MonitoringEvidenceResult:
        if not isinstance(evidence, Mapping):
            raise ValueError("MONITORING_EVIDENCE_INVALID")
        if any(key not in evidence for key in self.REQUIRED_KEYS):
            raise ValueError("MONITORING_EVIDENCE_INVALID")
        if max_age < 0:
            raise ValueError("MONITORING_MAX_AGE_INVALID")
        try:
            timestamp = float(evidence["timestamp"])
            heartbeat = float(evidence["heartbeat"])
        except (TypeError, ValueError):
            raise ValueError("MONITORING_EVIDENCE_INVALID")
        if not bool(evidence["healthy"]):
            raise ValueError("MONITORING_UNHEALTHY_FAIL_CLOSED")
        if heartbeat > now or timestamp > now:
            raise ValueError("MONITORING_FUTURE_TIMESTAMP")
        if now - heartbeat > max_age:
            raise ValueError("MONITORING_HEARTBEAT_STALE")
        if self.state.stale(now, max_age):
            raise ValueError("MONITORING_STATE_STALE")
        if not open_production_blockers():
            raise ValueError("MONITORING_BLOCKER_STATE_UNEXPECTED")
        return MonitoringEvidenceResult(
            valid=True,
            reason="MONITORING_EVIDENCE_BOUNDARY_VERIFIED",
        )
