"""YaqobiTrad v2.02.119 — durable verification certificate persistence."""
from __future__ import annotations
import copy, hashlib, json
from dataclasses import dataclass
from .audit import AuditLog
from .production_blockers import open_production_blockers

CHECKPOINT="v2.02.119"
PREDECESSOR="v2.02.118"

@dataclass(frozen=True)
class DurableVerificationCertificatePersistenceResult:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"
    activation_gate: str="LOCKED"
    fail_closed: str="ACTIVE"
    open_blocker_count: int=6
    certification: str="PENDING_REAL_PRODUCTION_RESULTS"
    certificate_digest: str=""
    persistence_digest: str=""

class DurableVerificationCertificatePersistenceV119:
    @staticmethod
    def _canonical(v):
        return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()
    @classmethod
    def _digest(cls,v): return hashlib.sha256(cls._canonical(v)).hexdigest()
    @staticmethod
    def _snapshot(a): return {"entries":copy.deepcopy(a.entries),"prev_hash":a.prev_hash}

    @classmethod
    def certificate_digest(cls, *, snapshot_digest, lineage_digest):
        return cls._digest({"checkpoint":CHECKPOINT,"predecessor":PREDECESSOR,"snapshot_digest":snapshot_digest,"lineage_digest":lineage_digest,"status":"VALID"})

    def verify(self,audit_path,*,expected_snapshot_digest,expected_lineage_digest,expected_certificate_digest):
        a=AuditLog(audit_path)
        if not a.verify(): raise ValueError("V202119_AUDIT_CHAIN_INVALID")
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers): raise ValueError("V202119_BLOCKER_STATE_INVALID")
        snap=self._snapshot(a); snapshot_digest=self._digest(snap)
        if snapshot_digest!=expected_snapshot_digest: raise ValueError("V202119_SNAPSHOT_DIGEST_MISMATCH")
        if not expected_lineage_digest: raise ValueError("V202119_LINEAGE_DIGEST_MISSING")
        certificate={"checkpoint":CHECKPOINT,"predecessor":PREDECESSOR,"snapshot_digest":snapshot_digest,"lineage_digest":expected_lineage_digest,"status":"VALID"}
        cd=self._digest(certificate)
        if cd!=expected_certificate_digest: raise ValueError("V202119_CERTIFICATE_DIGEST_MISMATCH")
        roundtrip=json.loads(self._canonical(certificate).decode())
        if self._digest(roundtrip)!=cd: raise ValueError("V202119_CERTIFICATE_CANONICAL_MISMATCH")
        fresh=AuditLog(audit_path)
        if self._digest(self._snapshot(fresh))!=snapshot_digest: raise ValueError("V202119_PERSISTENCE_RELOAD_MISMATCH")
        persisted=copy.deepcopy(roundtrip)
        persisted["lineage_digest"]="MUTATION_SENTINEL"
        if self._digest(certificate)!=cd: raise ValueError("V202119_CERTIFICATE_MUTATION_FAILURE")
        second=AuditLog(audit_path)
        if self._digest(self._snapshot(second))!=snapshot_digest: raise ValueError("V202119_SOURCE_PERSISTENCE_MUTATED")
        return DurableVerificationCertificatePersistenceResult(True,certificate_digest=cd,persistence_digest=self._digest(self._snapshot(fresh)))
