"""YaqobiTrad v2.02.237 — production blocker evidence collection boundary."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT='v2.02.237'; PREDECESSOR='v2.02.236'

@dataclass(frozen=True)
class Result:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    live_trading: str='SAFE_OFF'
    activation_gate: str='LOCKED'
    fail_closed: str='ACTIVE'
    open_blocker_count: int=6
    certification: str='PENDING_REAL_PRODUCTION_RESULTS'
    evidence_collection_ready: bool=True
    collected_blocker_count: int=0

class ProductionBlockerEvidenceCollectionBoundaryV237:
    REQUIRED=tuple(b.blocker_id for b in open_production_blockers())

    @classmethod
    def verify(cls, checkpoint, *, collected_blocker_ids=()):
        req=('valid','checkpoint','predecessor','live_trading','activation_gate','fail_closed')
        if checkpoint is None or not all(hasattr(checkpoint,n) for n in req):
            raise ValueError('V202237_CHECKPOINT_INTERFACE_INVALID')
        if not checkpoint.valid or checkpoint.checkpoint!='v2.02.236' or checkpoint.predecessor!='v2.02.235':
            raise ValueError('V202237_LINEAGE_INVALID')
        if (checkpoint.live_trading,checkpoint.activation_gate,checkpoint.fail_closed)!=('SAFE_OFF','LOCKED','ACTIVE'):
            raise ValueError('V202237_SAFETY_STATE_INVALID')
        if tuple(b.blocker_id for b in open_production_blockers())!=cls.REQUIRED or len(cls.REQUIRED)!=6:
            raise ValueError('V202237_BLOCKER_SET_INVALID')
        collected=tuple(collected_blocker_ids)
        if any(x not in cls.REQUIRED for x in collected) or len(set(collected))!=len(collected):
            raise ValueError('V202237_EVIDENCE_COLLECTION_INVALID')
        return Result(True,collected_blocker_count=len(collected))
