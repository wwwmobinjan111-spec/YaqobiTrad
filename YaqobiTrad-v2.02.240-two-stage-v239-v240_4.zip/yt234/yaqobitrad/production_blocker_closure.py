"""v2.02.83: fail-closed production blocker closure authority.

A version/release change cannot close a production blocker by itself.
Closure requires explicit production evidence for the exact blocker ID.
This module never unlocks live trading.
"""
from __future__ import annotations

from .production_blockers import PRODUCTION_BLOCKERS


class ProductionBlockerClosureAuthority:
    def __init__(self, evidence: dict[str, bool] | None = None):
        self._evidence = dict(evidence or {})

    def can_close(self, blocker_id: str) -> bool:
        known = {b.blocker_id for b in PRODUCTION_BLOCKERS}
        return blocker_id in known and self._evidence.get(blocker_id, False) is True

    def closure_state(self, blocker_id: str) -> str:
        return "RESOLVED" if self.can_close(blocker_id) else "OPEN"

    def all_current_states(self) -> tuple[tuple[str, str], ...]:
        return tuple((b.blocker_id, self.closure_state(b.blocker_id)) for b in PRODUCTION_BLOCKERS)
