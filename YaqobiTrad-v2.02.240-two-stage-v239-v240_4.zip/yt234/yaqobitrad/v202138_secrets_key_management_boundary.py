"""YaqobiTrad v2.02.138 — secrets and key-management boundary.

Source-level boundary only. It validates the shape of a production secret
reference without accepting plaintext secrets, and never authorizes live
trading or closes the production secret-management blocker.
"""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT = "v2.02.138"
PREDECESSOR = "v2.02.137"

@dataclass(frozen=True)
class SecretsKeyManagementBoundaryResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    open_blocker_count: int = 6
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"

class SecretsKeyManagementBoundaryV138:
    @staticmethod
    def verify(state, *, secret_ref: str | None = None) -> SecretsKeyManagementBoundaryResult:
        if state is None or not all(hasattr(state, n) for n in ("activation_gate", "live_trading", "fail_closed")):
            raise ValueError("V202138_STATE_INTERFACE_INVALID")
        if state.activation_gate != "LOCKED" or state.live_trading != "SAFE_OFF" or state.fail_closed != "ACTIVE":
            raise ValueError("V202138_SAFETY_STATE_INVALID")
        if secret_ref is not None:
            if not isinstance(secret_ref, str) or not secret_ref.strip() or "=" in secret_ref:
                raise ValueError("V202138_SECRET_REFERENCE_INVALID")
            if len(secret_ref.strip()) < 3:
                raise ValueError("V202138_SECRET_REFERENCE_INVALID")
        blockers = open_production_blockers()
        if len(blockers) != 6 or any(b.state != "OPEN" for b in blockers):
            raise ValueError("V202138_BLOCKER_STATE_INVALID")
        return SecretsKeyManagementBoundaryResult(True)
