"""YaqobiTrad v2.02.92 — monitoring evidence retention boundary.

Source-level boundary only. It requires an already-valid monitoring evidence
record plus an independently verified immutable/remote retention policy before
that evidence may be treated as retained activation evidence. It never closes
production blockers and remains fail-closed.
"""
from dataclasses import dataclass
from typing import Mapping, Any

from .evidence_retention import RetentionPolicy, retention_blocks_activation
from .monitoring_evidence_boundary import MonitoringEvidenceBoundary
from .production_blockers import open_production_blockers

@dataclass(frozen=True)
class MonitoringEvidenceRetentionResult:
    valid: bool
    reason: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"


class MonitoringEvidenceRetentionBoundary:
    def __init__(self, monitoring_boundary: MonitoringEvidenceBoundary):
        self.monitoring_boundary = monitoring_boundary

    def verify(
        self,
        evidence: Mapping[str, Any],
        now: float,
        max_age: float,
        policy: RetentionPolicy,
    ) -> MonitoringEvidenceRetentionResult:
        if not isinstance(policy, RetentionPolicy):
            raise ValueError("MONITORING_RETENTION_POLICY_INVALID")
        if retention_blocks_activation(policy):
            raise ValueError("MONITORING_RETENTION_NOT_VERIFIED")
        self.monitoring_boundary.verify(evidence, now=now, max_age=max_age)
        if not open_production_blockers():
            raise ValueError("MONITORING_BLOCKER_STATE_UNEXPECTED")
        return MonitoringEvidenceRetentionResult(
            valid=True,
            reason="MONITORING_EVIDENCE_RETENTION_BOUNDARY_VERIFIED",
        )
