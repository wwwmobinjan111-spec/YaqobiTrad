"""YaqobiTrad v2.02.147 — security incident evidence attestation continuity boundary.

Source-level boundary only. It validates continuity references for the security
incident evidence attestation chain and preserves the production fail-closed
state. It does not claim production deployment or closure of security blockers.
"""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT = "v2.02.147"
PREDECESSOR = "v2.02.146"

@dataclass(frozen=True)
class SecurityIncidentEvidenceAttestationContinuityBoundaryResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    open_blocker_count: int = 6
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"
    previous_attestation_ref: str = ""
    continuity_ref: str = ""

class SecurityIncidentEvidenceAttestationContinuityBoundaryV147:
    @staticmethod
    def _ref(value: str, field: str) -> str:
        if not isinstance(value, str) or not value.startswith("evidence://") or not value.strip():
            raise ValueError(f"V202147_{field.upper()}_INVALID")
        if "=" in value or any(token in value.upper() for token in ("TOKEN", "SECRET", "PASSWORD", "PRIVATE_KEY")):
            raise ValueError(f"V202147_{field.upper()}_SECRET_OR_ASSIGNMENT_INVALID")
        return value

    @classmethod
    def verify(cls, state, *, previous_attestation_ref: str, continuity_ref: str) -> SecurityIncidentEvidenceAttestationContinuityBoundaryResult:
        if state is None or not all(hasattr(state, n) for n in ("activation_gate", "live_trading", "fail_closed")):
            raise ValueError("V202147_STATE_INTERFACE_INVALID")
        if state.activation_gate != "LOCKED" or state.live_trading != "SAFE_OFF" or state.fail_closed != "ACTIVE":
            raise ValueError("V202147_SAFETY_STATE_INVALID")
        previous_attestation_ref = cls._ref(previous_attestation_ref, "previous_attestation_ref")
        continuity_ref = cls._ref(continuity_ref, "continuity_ref")
        blockers = open_production_blockers()
        if len(blockers) != 6 or any(b.state != "OPEN" for b in blockers):
            raise ValueError("V202147_BLOCKER_STATE_INVALID")
        return SecurityIncidentEvidenceAttestationContinuityBoundaryResult(
            True, previous_attestation_ref=previous_attestation_ref, continuity_ref=continuity_ref
        )
