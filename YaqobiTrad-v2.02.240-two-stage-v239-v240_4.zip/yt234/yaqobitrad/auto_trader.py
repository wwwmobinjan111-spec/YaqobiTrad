"""Integrated 1M paper AutoTrader cycle with position lifecycle."""
from __future__ import annotations

from dataclasses import dataclass
from .market import Candle
from .strategy import StrategyEngine
from .risk import RiskEngine
from .execution import ExecutionEngine
from .account_policy import AccountPolicy
from .portfolio import DurablePortfolio
from .audit import AuditLog


@dataclass(frozen=True)
class CycleResult:
    status: str
    symbol: str
    close_time: int
    action: str
    price: float
    reason: str | None = None
    client_order_id: str | None = None


@dataclass
class PaperPosition:
    symbol: str
    side: str
    quantity: float
    entry_price: float
    stop_loss: float | None
    take_profit: float | None
    entry_order_id: str


class OneMinuteAutoTrader:
    """Connect validated 1M candles through strategy, risk, admission, execution and lifecycle."""

    def __init__(self, account_policy: AccountPolicy, strategy=None, risk=None,
                 execution=None, portfolio: DurablePortfolio | None = None,
                 audit: AuditLog | None = None):
        self.account_policy = account_policy
        self.strategy = strategy or StrategyEngine()
        self.risk = risk or RiskEngine()
        self.execution = execution or ExecutionEngine(self.risk, account_policy=account_policy)
        self.portfolio = portfolio
        self.audit = audit
        self.positions: dict[str, PaperPosition] = {}
        self._last_close_time: dict[str, int] = {}
        self._sequence = 0
        self.recovery_blocked = False
        self.recovery_reason: str | None = None
        self.restore_state()

    def restore_state(self) -> dict[str, object]:
        """Restore durable paper positions after process restart."""
        if self.portfolio is None:
            return {"status": "NO_PORTFOLIO"}
        if not self.portfolio.reconcile():
            self.recovery_blocked = True
            self.recovery_reason = "PORTFOLIO_RECONCILIATION_FAILED"
            return {"status": "BLOCKED", "reason": self.recovery_reason}
        restored = {}
        for symbol, data in self.portfolio.positions.items():
            try:
                restored[symbol] = PaperPosition(
                    symbol=symbol,
                    side=str(data["side"]),
                    quantity=float(data["quantity"]),
                    entry_price=float(data["entry_price"]),
                    stop_loss=data.get("stop_loss"),
                    take_profit=data.get("take_profit"),
                    entry_order_id=str(data.get("entry_order_id", "RESTORED")),
                )
            except (KeyError, TypeError, ValueError):
                self.recovery_blocked = True
                self.recovery_reason = "INVALID_PERSISTED_POSITION"
                return {"status": "BLOCKED", "reason": self.recovery_reason}
        self.positions = restored
        self.account_policy.open_positions = len(restored)
        self.account_policy.position_value = sum(
            p.quantity * p.entry_price for p in restored.values()
        )
        self.recovery_blocked = False
        self.recovery_reason = None
        return {"status": "RESTORED", "positions": len(restored)}

    def reconcile_state(self) -> dict[str, object]:
        """Compare runtime positions with the durable portfolio snapshot."""
        if self.portfolio is None:
            return {"status": "NO_PORTFOLIO"}
        runtime = self._snapshot_positions()
        durable = dict(self.portfolio.positions)
        if runtime != durable:
            self.recovery_blocked = True
            self.recovery_reason = "POSITION_STATE_MISMATCH"
            return {"status": "BLOCKED", "reason": self.recovery_reason,
                    "runtime": runtime, "durable": durable}
        if not self.portfolio.reconcile():
            self.recovery_blocked = True
            self.recovery_reason = "PORTFOLIO_RECONCILIATION_FAILED"
            return {"status": "BLOCKED", "reason": self.recovery_reason}
        self.recovery_blocked = False
        self.recovery_reason = None
        return {"status": "RECONCILED", "positions": len(runtime)}

    def _record(self, event: str, symbol: str, **data) -> None:
        if self.audit is not None:
            self.audit.append(event, {"symbol": symbol, **data})

    def _snapshot_positions(self) -> dict:
        return {
            s: {"side": p.side, "quantity": p.quantity, "entry_price": p.entry_price,
                "stop_loss": p.stop_loss, "take_profit": p.take_profit,
                "entry_order_id": p.entry_order_id}
            for s, p in self.positions.items()
        }

    def _persist(self, event: str, balance: float = 0.0) -> None:
        if self.portfolio is not None:
            self.portfolio.append(event, balance, self._snapshot_positions())

    def _exit_trigger(self, position: PaperPosition, candle: Candle) -> tuple[str, float] | None:
        if position.side == "LONG":
            if position.stop_loss is not None and candle.low <= position.stop_loss:
                return "SL", position.stop_loss
            if position.take_profit is not None and candle.high >= position.take_profit:
                return "TP", position.take_profit
        else:
            if position.stop_loss is not None and candle.high >= position.stop_loss:
                return "SL", position.stop_loss
            if position.take_profit is not None and candle.low <= position.take_profit:
                return "TP", position.take_profit
        return None

    def _close_position(self, symbol: str, candle: Candle, reason: str, price: float) -> CycleResult:
        position = self.positions[symbol]
        exit_side = "SELL" if position.side == "LONG" else "BUY"
        self._sequence += 1
        order_id = f"1m-{symbol.replace('/', '')}-{candle.close_time}-EXIT-{self._sequence}"
        result = self.execution.paper_submit(
            exit_side, position.quantity, price, client_order_id=order_id,
            symbol=symbol, timeframe="1M", risk_pct=0.0,
            stop_loss=position.stop_loss, take_profit=position.take_profit,
            current_position_value=position.quantity * position.entry_price,
            portfolio_exposure=0.0, reduce_only=True,
        )
        if result.get("status") != "PAPER_FILLED":
            return CycleResult("BLOCKED", symbol, candle.close_time, exit_side, price,
                               str(result.get("reason", result.get("status"))), order_id)
        pnl = ((price - position.entry_price) if position.side == "LONG"
               else (position.entry_price - price)) * position.quantity
        del self.positions[symbol]
        self.account_policy.open_positions = max(0, self.account_policy.open_positions - 1)
        self.account_policy.position_value = 0.0
        self.risk.record_order()
        self._record("POSITION_EXIT", symbol, reason=reason, side=position.side,
                     quantity=position.quantity, entry_price=position.entry_price,
                     exit_price=price, pnl=pnl, order_id=order_id)
        self._persist("EXIT", balance=pnl)
        return CycleResult("EXITED", symbol, candle.close_time, exit_side, price,
                           reason, order_id)

    def on_candle_set(self, symbol: str, candles: list[Candle], *, quantity: float,
                      stop_loss: float | None, take_profit: float | None,
                      current_position_value: float = 0.0,
                      portfolio_exposure: float = 0.0) -> CycleResult:
        symbol = symbol.upper()
        if self.recovery_blocked:
            return CycleResult("BLOCKED", symbol, 0, "HOLD", 0.0, self.recovery_reason or "RECOVERY_BLOCKED")
        if not candles:
            return CycleResult("BLOCKED", symbol, 0, "HOLD", 0.0, "NO_CANDLES")
        latest = candles[-1]
        if not latest.closed:
            return CycleResult("BLOCKED", symbol, latest.close_time, "HOLD", latest.close,
                                "CANDLE_NOT_CLOSED")
        previous = self._last_close_time.get(symbol)
        if previous is not None and latest.close_time <= previous:
            return CycleResult("BLOCKED", symbol, latest.close_time, "HOLD", latest.close,
                                "NON_INCREASING_CANDLE")
        self._last_close_time[symbol] = latest.close_time

        if symbol in self.positions:
            trigger = self._exit_trigger(self.positions[symbol], latest)
            if trigger is not None:
                reason, price = trigger
                return self._close_position(symbol, latest, reason, price)
            return CycleResult("POSITION_OPEN", symbol, latest.close_time,
                               self.positions[symbol].side, latest.close)

        decision = self.strategy.decide(symbol, candles)
        if decision.action == "HOLD":
            return CycleResult("NO_ACTION", decision.symbol, decision.close_time, "HOLD", decision.price)

        self._sequence += 1
        order_id = f"1m-{decision.symbol.replace('/', '')}-{decision.close_time}-{self._sequence}"
        result = self.execution.paper_submit(
            decision.action, quantity, decision.price, client_order_id=order_id,
            symbol=decision.symbol, timeframe="1M", risk_pct=1.0,
            stop_loss=stop_loss, take_profit=take_profit,
            current_position_value=current_position_value,
            portfolio_exposure=portfolio_exposure,
        )
        if result.get("status") == "PAPER_FILLED":
            side = "LONG" if decision.action == "BUY" else "SHORT"
            self.positions[decision.symbol] = PaperPosition(
                decision.symbol, side, float(quantity), float(decision.price),
                stop_loss, take_profit, order_id)
            self.account_policy.open_positions += 1
            self.account_policy.position_value = quantity * decision.price
            self.risk.record_order()
            self._record("POSITION_ENTRY", decision.symbol, side=side, quantity=quantity,
                         entry_price=decision.price, stop_loss=stop_loss,
                         take_profit=take_profit, order_id=order_id)
            self._persist("ENTRY")
            return CycleResult("EXECUTED", decision.symbol, decision.close_time, decision.action,
                               decision.price, client_order_id=order_id)
        return CycleResult("BLOCKED", decision.symbol, decision.close_time, decision.action,
                           decision.price, str(result.get("reason", result.get("status"))), order_id)
