"""YaqobiTrad v2.02.130 — MAJOR GLOBAL CHECKPOINT."""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT="v2.02.130"
PREDECESSOR="v2.02.129"
MAJOR_GLOBAL_CHECKPOINT=True

@dataclass(frozen=True)
class MajorGlobalCheckpointResult:
    valid: bool
    checkpoint: str=CHECKPOINT
    predecessor: str=PREDECESSOR
    major_global_checkpoint: bool=True
    live_trading: str="SAFE_OFF"
    activation_gate: str="LOCKED"
    fail_closed: str="ACTIVE"
    open_blocker_count: int=6
    certification: str="PENDING_REAL_PRODUCTION_RESULTS"

class MajorGlobalCheckpointV130:
    @staticmethod
    def verify(state):
        if state is None or not all(hasattr(state,n) for n in ("activation_gate","live_trading","fail_closed")):
            raise ValueError("V202130_STATE_INTERFACE_INVALID")
        if state.activation_gate != "LOCKED" or state.live_trading != "SAFE_OFF" or state.fail_closed != "ACTIVE":
            raise ValueError("V202130_SAFETY_STATE_INVALID")
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers):
            raise ValueError("V202130_BLOCKER_STATE_INVALID")
        return MajorGlobalCheckpointResult(True)
