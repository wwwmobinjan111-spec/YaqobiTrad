"""YaqobiTrad v2.02.98 — monitoring evidence audit continuity anchor recovery.

Provides a read-only recovery verification boundary for the durable v2.02.97
anchor verification. The verifier reloads the persisted ledger, confirms the
anchor remains the terminal trusted record, and proves a second independent
reload preserves the same chain identity. Any malformed, missing, duplicated,
or mismatched state fails closed.
"""
from __future__ import annotations

from dataclasses import dataclass

from .audit import AuditLog
from .production_blockers import open_production_blockers

SCHEMA_VERSION = "v2.02.98"
ANCHOR_EVENT = "MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED"


@dataclass(frozen=True)
class MonitoringEvidenceAuditContinuityAnchorRecoveryResult:
    valid: bool
    reason: str
    bound_audit_hash: str
    evidence_digest: str
    anchor_hash: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"


class MonitoringEvidenceAuditContinuityAnchorRecovery:
    """Read-only recovery verification of the persisted v2.02.96 anchor."""

    def verify_recovery(
        self,
        audit_path: str,
        *,
        expected_bound_audit_hash: str,
        expected_evidence_digest: str,
        expected_anchor_hash: str,
    ) -> MonitoringEvidenceAuditContinuityAnchorRecoveryResult:
        first = AuditLog(audit_path)
        if not first.verify():
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_RECOVERY_CHAIN_INVALID")
        if not open_production_blockers():
            raise ValueError("MONITORING_BLOCKER_STATE_UNEXPECTED")

        anchors = [e for e in first.entries if e.get("event") == ANCHOR_EVENT]
        if len(anchors) != 1:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_RECOVERY_CARDINALITY_INVALID")
        anchor = anchors[0]
        if first.entries[-1] is not anchor:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_RECOVERY_NOT_TERMINAL")

        data = anchor.get("data", {})
        if data.get("schema_version") != "v2.02.96":
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_RECOVERY_SCHEMA_MISMATCH")
        if data.get("bound_audit_hash") != expected_bound_audit_hash:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_RECOVERY_BOUND_HASH_MISMATCH")
        if data.get("evidence_digest") != expected_evidence_digest:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_RECOVERY_DIGEST_MISMATCH")
        if anchor.get("hash") != expected_anchor_hash:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_RECOVERY_ANCHOR_HASH_MISMATCH")
        if len(first.entries) < 2 or data.get("continuity_hash") != first.entries[-2].get("hash"):
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_RECOVERY_CONTINUITY_LINK_MISMATCH")
        if anchor.get("prev_hash") != first.entries[-2].get("hash"):
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_RECOVERY_PREV_HASH_MISMATCH")

        snapshot = tuple(first.entries)
        second = AuditLog(audit_path)
        if not second.verify() or tuple(second.entries) != snapshot:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_RECOVERY_RELOAD_INVALID")
        third = AuditLog(audit_path)
        if not third.verify() or tuple(third.entries) != snapshot:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_RECOVERY_SECOND_RELOAD_INVALID")
        if third.entries[-1].get("hash") != expected_anchor_hash:
            raise ValueError("MONITORING_EVIDENCE_AUDIT_ANCHOR_RECOVERY_IDENTITY_MISMATCH")

        return MonitoringEvidenceAuditContinuityAnchorRecoveryResult(
            valid=True,
            reason="MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHOR_RECOVERY_VERIFIED",
            bound_audit_hash=expected_bound_audit_hash,
            evidence_digest=expected_evidence_digest,
            anchor_hash=expected_anchor_hash,
        )
