"""Fail-closed execution control layer; no live exchange submission."""
from __future__ import annotations
from dataclasses import dataclass
from . import config
from .account_policy import AccountPolicy
from .activation_gate import ActivationBoundary

@dataclass(frozen=True)
class ExecutionRecord:
    client_order_id: str
    status: str
    side: str
    quantity: float
    price: float
    sequence: int

class ExecutionControl:
    """Deterministic execution control with idempotency and reconciliation.

    This layer never talks to an exchange. Live submission remains blocked until
    an explicitly integrated and independently verified exchange adapter exists.
    """
    def __init__(self):
        self._records: dict[str, ExecutionRecord] = {}
        self._pending: set[str] = set()
        self._sequence = 0

    def submit_paper(self, client_order_id, side, quantity, price):
        if not client_order_id:
            return {"status":"BLOCKED", "reason":"CLIENT_ORDER_ID_REQUIRED"}
        if client_order_id in self._records:
            r = self._records[client_order_id]
            return {"status":"IDEMPOTENT_REPLAY", "client_order_id":r.client_order_id,
                    "sequence":r.sequence, "original_status":r.status}
        if side not in {"BUY", "SELL"} or quantity <= 0 or price <= 0:
            return {"status":"BLOCKED", "reason":"INVALID_ORDER"}
        # v2.02.57: explicit two-phase commit marker prevents an ambiguous
        # execution from being mistaken for a durable fill.
        self._pending.add(client_order_id)
        try:
            self._sequence += 1
            r = ExecutionRecord(client_order_id,"PAPER_FILLED",side,float(quantity),float(price),self._sequence)
            self._records[client_order_id] = r
            self._pending.discard(client_order_id)
            return {"status":r.status,"client_order_id":r.client_order_id,"sequence":r.sequence}
        except Exception:
            self._pending.discard(client_order_id)
            raise

    def reconcile(self):
        # Any leftover pending marker means the last commit is ambiguous.
        if self._pending:
            return False
        seqs = [r.sequence for r in self._records.values()]
        if len(seqs) != len(set(seqs)):
            return False
        return sorted(seqs) == list(range(1, len(seqs)+1))

    def live_submit(self, *args, **kwargs):
        return {"status":"BLOCKED", "reason":"LIVE_PROVIDER_ADAPTER_NOT_VERIFIED"}

class ExecutionEngine:
    def __init__(self, risk_engine, account_policy=None):
        self.risk = risk_engine
        self.account_policy = account_policy
        self.control = ExecutionControl()
        self.activation = ActivationBoundary()

    def submit(self, side, quantity, price, current_position_value=0.0, client_order_id=None,
               symbol="BTC/USDT", timeframe="1M", risk_pct=0.0,
               stop_loss=None, take_profit=None, portfolio_exposure=0.0, reduce_only=False):
        # v2.02.55: every live-intent path must pass the centralized runtime
        # activation boundary before any policy or provider operation.
        boundary = self.activation.evaluate("LIVE")
        if boundary.status != "ALLOWED":
            # Preserve the established execution API reason while enforcing the
            # centralized boundary first. Unsafe runtime states retain the
            # boundary reason so fail-closed diagnostics are not hidden.
            reason = boundary.reason or "ACTIVATION_BOUNDARY_BLOCKED"
            if reason == "LIVE_TRADING_DISABLED":
                reason = "ACTIVATION_GATE_LOCKED"
            return {"status": "BLOCKED", "reason": reason}
        if self.account_policy is not None:
            decision = self.account_policy.admit_order(
                side=side, symbol=symbol, timeframe=timeframe, quantity=quantity,
                price=price, risk_pct=risk_pct, stop_loss=stop_loss,
                take_profit=take_profit, current_position_value=current_position_value,
                portfolio_exposure=portfolio_exposure,
                activation_gate=config.ACTIVATION_GATE,
                live_trading=config.LIVE_TRADING,
                reduce_only=reduce_only,
            )
            if decision["status"] != "APPROVED":
                return decision
        # v2.02.56: final pre-submit revalidation closes the TOCTOU window
        # between admission/policy checks and the actual execution commit.
        final_boundary = self.activation.evaluate("LIVE")
        if final_boundary.status != "ALLOWED":
            reason = final_boundary.reason or "ACTIVATION_BOUNDARY_BLOCKED"
            if reason == "LIVE_TRADING_DISABLED":
                reason = "ACTIVATION_GATE_LOCKED"
            return {"status": "BLOCKED", "reason": reason}
        # The centralized gate intentionally never allows LIVE, so this branch
        # remains fail-closed even if runtime configuration changes mid-call.
        return {"status": "BLOCKED", "reason": "LIVE_TRADING_DISABLED"}

    def paper_submit(self, side, quantity, price, client_order_id=None,
                     symbol="BTC/USDT", timeframe="1M", risk_pct=0.0,
                     stop_loss=None, take_profit=None, current_position_value=0.0,
                     portfolio_exposure=0.0, reduce_only=False):
        boundary = self.activation.evaluate("PAPER")
        if boundary.status != "ALLOWED":
            return {"status": "BLOCKED", "reason": boundary.reason}
        if self.account_policy is not None:
            decision = self.account_policy.admit_order(
                side=side, symbol=symbol, timeframe=timeframe, quantity=quantity,
                price=price, risk_pct=risk_pct, stop_loss=stop_loss,
                take_profit=take_profit, current_position_value=current_position_value,
                portfolio_exposure=portfolio_exposure,
                activation_gate=config.ACTIVATION_GATE,
                live_trading=config.LIVE_TRADING,
                reduce_only=reduce_only,
            )
            if decision["status"] != "APPROVED":
                return decision
        value = quantity * price
        ok, reason = self.risk.approve(value, current_position_value=current_position_value,
                                       portfolio_exposure=portfolio_exposure)
        if not ok:
            return {"status": "BLOCKED", "reason": reason}
        # v2.02.56: final pre-commit revalidation closes the TOCTOU window
        # after policy/risk evaluation and before the paper execution commit.
        final_boundary = self.activation.evaluate("PAPER")
        if final_boundary.status != "ALLOWED":
            return {"status": "BLOCKED", "reason": final_boundary.reason}
        if client_order_id is None:
            client_order_id = f"paper-{self.control._sequence + 1}"
        return self.control.submit_paper(client_order_id, side, quantity, price)
