"""v2.02.87 — durable audit/evidence recovery gate.

Persists the hash-chained audit ledger together with the v2.02.86 attestation
in one canonical, atomically replaced envelope. Recovery reconstructs a fresh
AuditLog, validates the ledger, re-validates the attestation, and rejects any
mutation, truncation, schema mismatch, or digest mismatch. This gate never
changes blockers or safety state.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from dataclasses import asdict

from .audit import AuditLog
from .evidence_integrity_attestation import EvidenceIntegrityAttestationGate
from .evidence_integrity_attestation_persistence import (
    serialize_attestation,
    deserialize_attestation,
)

SCHEMA_VERSION = "v2.02.87"
_REQUIRED = ("schema_version", "audit", "attestation", "envelope_digest")


def _canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def _digest(value: object) -> str:
    return hashlib.sha256(_canonical(value)).hexdigest()


def persist_audit_evidence(audit: AuditLog, attestation, path: str) -> str:
    if not audit.verify():
        raise ValueError("AUDIT_CHAIN_INVALID")
    att = json.loads(serialize_attestation(attestation))
    body = {"schema_version": SCHEMA_VERSION, "audit": {
        "entries": audit.entries, "prev_hash": audit.prev_hash
    }, "attestation": att}
    payload = {**body, "envelope_digest": _digest(body)}
    directory = os.path.dirname(os.path.abspath(path))
    os.makedirs(directory, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".evidence-", dir=directory)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f, sort_keys=True, separators=(",", ":"))
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
    return path


def recover_audit_evidence(path: str) -> tuple[AuditLog, object]:
    try:
        with open(path, encoding="utf-8") as f:
            payload = json.load(f)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        raise ValueError("EVIDENCE_PERSISTENCE_INVALID") from exc
    if not isinstance(payload, dict) or set(payload) != set(_REQUIRED):
        raise ValueError("EVIDENCE_SCHEMA_INVALID")
    if payload["schema_version"] != SCHEMA_VERSION:
        raise ValueError("EVIDENCE_SCHEMA_VERSION_INVALID")
    body = {k: payload[k] for k in ("schema_version", "audit", "attestation")}
    if _digest(body) != payload["envelope_digest"]:
        raise ValueError("EVIDENCE_ENVELOPE_DIGEST_MISMATCH")
    audit_data = payload["audit"]
    if not isinstance(audit_data, dict) or set(audit_data) != {"entries", "prev_hash"}:
        raise ValueError("AUDIT_SCHEMA_INVALID")
    # AuditLog performs hash-chain verification on load; use its exact durable
    # loader by writing the already-validated ledger to an isolated temp file.
    fd, tmp = tempfile.mkstemp(prefix=".recovery-audit-", suffix=".json")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(audit_data, f, sort_keys=True, separators=(",", ":"))
        audit = AuditLog(tmp)
    except Exception as exc:
        raise ValueError("AUDIT_RECOVERY_FAILED") from exc
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
    try:
        attestation = deserialize_attestation(json.dumps(payload["attestation"], sort_keys=True, separators=(",", ":")))
    except ValueError as exc:
        raise ValueError("ATTESTATION_RECOVERY_FAILED") from exc
    return audit, attestation


def verify_recovered_evidence(original_gate: EvidenceIntegrityAttestationGate, path: str):
    audit, attestation = recover_audit_evidence(path)
    recovered_gate = EvidenceIntegrityAttestationGate(audit, original_gate.checkpoint)
    result = recovered_gate.verify(attestation)
    return result, audit, attestation
