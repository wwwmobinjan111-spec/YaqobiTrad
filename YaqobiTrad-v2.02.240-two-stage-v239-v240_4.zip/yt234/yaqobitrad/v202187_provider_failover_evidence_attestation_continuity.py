"""YaqobiTrad v2.02.187 — provider failover evidence attestation continuity boundary."""
from __future__ import annotations
import hashlib, json
from dataclasses import dataclass

CHECKPOINT = "v2.02.187"
PREDECESSOR = "v2.02.186"

@dataclass(frozen=True)
class ProviderFailoverEvidenceAttestationContinuityResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    attestation_digest: str = ""
    continuity_digest: str = ""
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"

class ProviderFailoverEvidenceAttestationContinuityV187:
    """Carry forward v2.02.186 attestation deterministically without activation."""
    @staticmethod
    def _payload(attestation):
        required=("valid","checkpoint","predecessor","continuity_digest","attestation_digest",
                  "live_trading","activation_gate","fail_closed")
        if attestation is None or not all(hasattr(attestation,n) for n in required):
            raise ValueError("V202187_ATTESTATION_INTERFACE_INVALID")
        if not attestation.valid:
            raise ValueError("V202187_ATTESTATION_INVALID")
        if (attestation.checkpoint,attestation.predecessor)!=(PREDECESSOR,"v2.02.185"):
            raise ValueError("V202187_ATTESTATION_LINEAGE_INVALID")
        for name in ("continuity_digest","attestation_digest"):
            value=getattr(attestation,name)
            if not isinstance(value,str) or len(value)!=64:
                raise ValueError("V202187_DIGEST_INVALID")
        if (attestation.live_trading,attestation.activation_gate,attestation.fail_closed)!=("SAFE_OFF","LOCKED","ACTIVE"):
            raise ValueError("V202187_SAFETY_STATE_INVALID")
        return {"checkpoint":attestation.checkpoint,"predecessor":attestation.predecessor,
                "continuity_digest":attestation.continuity_digest,"attestation_digest":attestation.attestation_digest,
                "live_trading":"SAFE_OFF","activation_gate":"LOCKED","fail_closed":"ACTIVE"}
    @classmethod
    def carry_forward(cls, attestation, *, expected_attestation_digest=None):
        payload=cls._payload(attestation)
        if expected_attestation_digest is not None and payload["attestation_digest"]!=expected_attestation_digest:
            raise ValueError("V202187_ATTESTATION_DIGEST_MISMATCH")
        canonical=json.dumps(payload,sort_keys=True,separators=(",",":"),ensure_ascii=True).encode()
        digest=hashlib.sha256(canonical).hexdigest()
        return ProviderFailoverEvidenceAttestationContinuityResult(valid=True,
            attestation_digest=payload["attestation_digest"],continuity_digest=digest)
