"""Execution-provider boundary for YaqobiTrad.

Paper-only adapter is executable and deterministic. Live submission remains blocked.
"""
from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class ProviderOrder:
    client_order_id: str
    status: str
    side: str
    quantity: float
    price: float
    provider_order_id: str

@dataclass(frozen=True)
class ExecutionReceipt:
    client_order_id: str
    provider_order_id: str
    status: str
    side: str
    quantity: float
    price: float

    def valid_for(self, client_order_id, side, quantity, price):
        return (self.client_order_id == client_order_id
                and self.status == "FILLED"
                and self.side == side
                and self.quantity == float(quantity)
                and self.price == float(price))


class ProviderTransientError(RuntimeError):
    """Injected transient provider failure used by deterministic recovery tests."""


class PaperExecutionProvider:
    """Deterministic provider adapter with idempotent recovery semantics."""
    def __init__(self, *, fail_after_create_once: bool = False):
        self.orders: dict[str, ProviderOrder] = {}
        self._seq = 0
        self._fail_after_create_once = fail_after_create_once

    def submit(self, client_order_id, side, quantity, price):
        if client_order_id in self.orders:
            return self.orders[client_order_id]
        if side not in {"BUY", "SELL"} or quantity <= 0 or price <= 0:
            raise ValueError("INVALID_ORDER")
        self._seq += 1
        order = ProviderOrder(client_order_id, "FILLED", side, float(quantity), float(price), f"PAPER-{self._seq}")
        self.orders[client_order_id] = order
        if self._fail_after_create_once:
            self._fail_after_create_once = False
            raise ProviderTransientError("PROVIDER_RESPONSE_LOST_AFTER_CREATE")
        return order

    def submit_with_recovery(self, client_order_id, side, quantity, price, *, max_retries=1):
        attempts = 0
        while True:
            try:
                return self.submit(client_order_id, side, quantity, price), attempts
            except ProviderTransientError:
                if attempts >= max_retries:
                    raise
                attempts += 1

    def get_order(self, client_order_id):
        return self.orders.get(client_order_id)

    def reconcile_order(self, client_order_id):
        """Return the provider-known order for recovery reconciliation."""
        return self.orders.get(client_order_id)

    def receipt(self, client_order_id):
        order = self.orders.get(client_order_id)
        if order is None:
            return None
        return ExecutionReceipt(order.client_order_id, order.provider_order_id,
                                order.status, order.side, order.quantity, order.price)

    def verify_receipt(self, client_order_id, side, quantity, price):
        receipt = self.receipt(client_order_id)
        return receipt is not None and receipt.valid_for(client_order_id, side, quantity, price)

    def reconcile(self, expected_ids):
        expected = set(expected_ids)
        actual = set(self.orders)
        return expected == actual and len(actual) == len(expected)

class LiveExecutionProvider:
    """Explicit fail-closed placeholder for the not-yet-verified live adapter."""
    def submit(self, *args, **kwargs):
        return {"status": "BLOCKED", "reason": "LIVE_PROVIDER_ADAPTER_NOT_VERIFIED"}
