"""YaqobiTrad v2.02.94 — monitoring evidence retrieval audit binding.

Source-level boundary only. A successful v2.02.93 evidence retrieval can be
bound to an append-only hash-chained audit record. Audit integrity and the
retrieved evidence digest are checked before and after the append. Any
integrity failure is fail-closed; no production blocker is closed.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Mapping

from .audit import AuditLog
from .monitoring_evidence_retrieval_boundary import MonitoringEvidenceRetrievalBoundary
from .production_blockers import open_production_blockers

SCHEMA_VERSION = "v2.02.94"


def _canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def _digest(value: object) -> str:
    return hashlib.sha256(_canonical(value)).hexdigest()


@dataclass(frozen=True)
class MonitoringEvidenceAuditBindingResult:
    valid: bool
    reason: str
    evidence_digest: str
    audit_hash: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"


class MonitoringEvidenceRetrievalAuditBinding:
    """Bind a verified read-only retrieval to the existing audit chain."""

    def __init__(
        self,
        retrieval_boundary: MonitoringEvidenceRetrievalBoundary,
        audit: AuditLog,
    ):
        self.retrieval_boundary = retrieval_boundary
        self.audit = audit

    def bind(
        self,
        path: str,
        *,
        now: float,
        max_age: float,
    ) -> MonitoringEvidenceAuditBindingResult:
        if not self.audit.verify():
            raise ValueError("MONITORING_RETRIEVAL_AUDIT_CHAIN_INVALID")
        before_entries = len(self.audit.entries)
        before_digest = _digest(self.audit.entries)

        result = self.retrieval_boundary.retrieve(path, now=now, max_age=max_age)
        evidence_digest = _digest(result.evidence)
        record = self.audit.append(
            "MONITORING_EVIDENCE_RETRIEVAL_VERIFIED",
            {
                "schema_version": SCHEMA_VERSION,
                "evidence_digest": evidence_digest,
                "reason": result.reason,
            },
        )

        if not self.audit.verify():
            raise ValueError("MONITORING_RETRIEVAL_AUDIT_CHAIN_INVALID_AFTER_BIND")
        if len(self.audit.entries) != before_entries + 1:
            raise ValueError("MONITORING_RETRIEVAL_AUDIT_APPEND_INVALID")
        if _digest(self.audit.entries[:-1]) != before_digest:
            raise ValueError("MONITORING_RETRIEVAL_AUDIT_HISTORY_MUTATED")
        if not open_production_blockers():
            raise ValueError("MONITORING_BLOCKER_STATE_UNEXPECTED")
        if record.get("data", {}).get("evidence_digest") != evidence_digest:
            raise ValueError("MONITORING_RETRIEVAL_AUDIT_DIGEST_MISMATCH")

        return MonitoringEvidenceAuditBindingResult(
            valid=True,
            reason="MONITORING_EVIDENCE_RETRIEVAL_AUDIT_BOUND",
            evidence_digest=evidence_digest,
            audit_hash=record["hash"],
        )
