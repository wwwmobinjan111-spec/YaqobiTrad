"""YaqobiTrad v2.02.102 — durable verification snapshot isolation."""
from __future__ import annotations

from dataclasses import dataclass
import copy
import hashlib
import json

from .audit import AuditLog
from .production_blockers import open_production_blockers

CHECKPOINT = "v2.02.102"
PREDECESSOR = "v2.02.101"
ATTESTATION_SCHEMA = "v2.02.99"
ATTESTATION_EVENT = "MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED"

@dataclass(frozen=True)
class SnapshotIsolationResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    open_blocker_count: int = 6
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"
    snapshot_digest: str = ""

class DurableVerificationSnapshotIsolation:
    """Read-only isolation gate for durable checkpoint state."""
    @staticmethod
    def _snapshot(entries, prev_hash):
        return {"entries": copy.deepcopy(entries), "prev_hash": prev_hash}

    @staticmethod
    def _digest(snapshot):
        return hashlib.sha256(json.dumps(snapshot, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

    def verify(self, audit_path: str, *, expected_anchor_hash: str,
               expected_bound_audit_hash: str, expected_evidence_digest: str,
               expected_snapshot_digest: str) -> SnapshotIsolationResult:
        first = AuditLog(audit_path)
        if not first.verify():
            raise ValueError("V202102_AUDIT_CHAIN_INVALID")
        blockers = open_production_blockers()
        if len(blockers) != 6 or any(b.state != "OPEN" for b in blockers):
            raise ValueError("V202102_BLOCKER_STATE_INVALID")
        anchors = [e for e in first.entries if e.get("event") == ATTESTATION_EVENT]
        if len(anchors) != 1 or not first.entries or first.entries[-1] is not anchors[0]:
            raise ValueError("V202102_TERMINAL_ATTESTATION_INVALID")
        anchor = anchors[0]
        data = anchor.get("data", {})
        if data.get("schema_version") != ATTESTATION_SCHEMA:
            raise ValueError("V202102_PREDECESSOR_SCHEMA_INVALID")
        if anchor.get("hash") != expected_anchor_hash:
            raise ValueError("V202102_ANCHOR_HASH_MISMATCH")
        if data.get("bound_audit_hash") != expected_bound_audit_hash:
            raise ValueError("V202102_BOUND_AUDIT_HASH_MISMATCH")
        if data.get("evidence_digest") != expected_evidence_digest:
            raise ValueError("V202102_EVIDENCE_DIGEST_MISMATCH")
        if len(first.entries) < 2 or data.get("continuity_hash") != first.entries[-2].get("hash"):
            raise ValueError("V202102_CONTINUITY_LINK_INVALID")

        snapshot = self._snapshot(first.entries, first.prev_hash)
        digest = self._digest(snapshot)
        if digest != expected_snapshot_digest:
            raise ValueError("V202102_SNAPSHOT_DIGEST_MISMATCH")

        # Two fresh durable reloads must reproduce the exact immutable snapshot.
        second = AuditLog(audit_path)
        third = AuditLog(audit_path)
        if second.entries != first.entries or third.entries != first.entries:
            raise ValueError("V202102_RELOAD_ENTRIES_MISMATCH")
        if second.prev_hash != first.prev_hash or third.prev_hash != first.prev_hash:
            raise ValueError("V202102_RELOAD_PREV_HASH_MISMATCH")
        if self._digest(self._snapshot(second.entries, second.prev_hash)) != digest:
            raise ValueError("V202102_RELOAD_DIGEST_MISMATCH")
        if self._digest(self._snapshot(third.entries, third.prev_hash)) != digest:
            raise ValueError("V202102_RELOAD_DIGEST_MISMATCH")

        # Prove the verification snapshot is isolated from source mutation.
        isolated = self._snapshot(first.entries, first.prev_hash)
        isolated["entries"][-1]["data"]["evidence_digest"] = "MUTATION_SENTINEL"
        if first.entries[-1]["data"].get("evidence_digest") != expected_evidence_digest:
            raise ValueError("V202102_SNAPSHOT_MUTATION_LEAK")
        return SnapshotIsolationResult(True, snapshot_digest=digest)
