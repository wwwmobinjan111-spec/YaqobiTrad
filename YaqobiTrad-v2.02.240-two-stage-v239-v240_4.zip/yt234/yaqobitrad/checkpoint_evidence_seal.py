"""v2.02.61: bind a global checkpoint to an immutable audit/evidence seal."""
from __future__ import annotations
import hashlib
import json
from dataclasses import dataclass

@dataclass(frozen=True)
class CheckpointEvidenceSeal:
    checkpoint: str
    audit_hash: str
    evidence_digest: str
    seal_digest: str


def _canonical(payload: dict) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()


class CheckpointEvidenceSealer:
    """Create one immutable evidence seal per checkpoint against the audit chain."""
    EVENT = "GLOBAL_CHECKPOINT_EVIDENCE_SEALED"

    def __init__(self, audit_log):
        self.audit = audit_log
        self._seals: dict[str, CheckpointEvidenceSeal] = {}

    @staticmethod
    def evidence_digest(checkpoint) -> str:
        payload = {
            "checkpoint": checkpoint.checkpoint,
            "tested_domains": list(checkpoint.tested_domains),
            "open_blocker_count": checkpoint.open_blocker_count,
            "activation_gate": checkpoint.activation_gate,
            "fail_closed": checkpoint.fail_closed,
            "live_trading": checkpoint.live_trading,
            "certification": checkpoint.certification,
        }
        return hashlib.sha256(_canonical(payload)).hexdigest()

    def seal(self, checkpoint) -> CheckpointEvidenceSeal:
        existing = self._seals.get(checkpoint.checkpoint)
        digest = self.evidence_digest(checkpoint)
        if existing is not None:
            if existing.evidence_digest != digest:
                raise ValueError("CHECKPOINT_EVIDENCE_MISMATCH")
            if not self.verify(checkpoint):
                raise ValueError("CHECKPOINT_EVIDENCE_INVALID")
            return existing
        if not self.audit.verify():
            raise ValueError("AUDIT_CHAIN_INVALID")
        record = self.audit.append(self.EVENT, {
            "checkpoint": checkpoint.checkpoint,
            "evidence_digest": digest,
        })
        seal_payload = {
            "checkpoint": checkpoint.checkpoint,
            "audit_hash": record["hash"],
            "evidence_digest": digest,
        }
        seal_digest = hashlib.sha256(_canonical(seal_payload)).hexdigest()
        seal = CheckpointEvidenceSeal(checkpoint.checkpoint, record["hash"], digest, seal_digest)
        self._seals[checkpoint.checkpoint] = seal
        return seal

    def verify(self, checkpoint) -> bool:
        seal = self._seals.get(checkpoint.checkpoint)
        if seal is None or not self.audit.verify():
            return False
        digest = self.evidence_digest(checkpoint)
        if digest != seal.evidence_digest:
            return False
        expected_seal = hashlib.sha256(_canonical({
            "checkpoint": seal.checkpoint,
            "audit_hash": seal.audit_hash,
            "evidence_digest": seal.evidence_digest,
        })).hexdigest()
        if expected_seal != seal.seal_digest:
            return False
        return any(
            r.get("hash") == seal.audit_hash
            and r.get("event") == self.EVENT
            and r.get("data", {}).get("checkpoint") == seal.checkpoint
            and r.get("data", {}).get("evidence_digest") == seal.evidence_digest
            for r in self.audit.entries
        )
