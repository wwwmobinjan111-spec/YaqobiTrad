"""YaqobiTrad v2.02.146 — security incident evidence attestation integrity boundary.

Source-level boundary only. It validates an attestation integrity reference and
preserves the production fail-closed state. It does not claim that a real
production attestation-integrity service has been deployed or that any
production security blocker has been closed.
"""
from __future__ import annotations
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT = "v2.02.146"
PREDECESSOR = "v2.02.145"

@dataclass(frozen=True)
class SecurityIncidentEvidenceAttestationIntegrityBoundaryResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    open_blocker_count: int = 6
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"
    integrity_ref: str = ""

class SecurityIncidentEvidenceAttestationIntegrityBoundaryV146:
    @staticmethod
    def verify(state, *, integrity_ref: str) -> SecurityIncidentEvidenceAttestationIntegrityBoundaryResult:
        if state is None or not all(hasattr(state, n) for n in ("activation_gate", "live_trading", "fail_closed")):
            raise ValueError("V202146_STATE_INTERFACE_INVALID")
        if state.activation_gate != "LOCKED" or state.live_trading != "SAFE_OFF" or state.fail_closed != "ACTIVE":
            raise ValueError("V202146_SAFETY_STATE_INVALID")
        if not isinstance(integrity_ref, str) or not integrity_ref.startswith("evidence://") or not integrity_ref.strip():
            raise ValueError("V202146_INTEGRITY_REF_INVALID")
        if "=" in integrity_ref or any(token in integrity_ref.upper() for token in ("TOKEN", "SECRET", "PASSWORD", "PRIVATE_KEY")):
            raise ValueError("V202146_INTEGRITY_REF_SECRET_OR_ASSIGNMENT_INVALID")
        blockers = open_production_blockers()
        if len(blockers) != 6 or any(b.state != "OPEN" for b in blockers):
            raise ValueError("V202146_BLOCKER_STATE_INVALID")
        return SecurityIncidentEvidenceAttestationIntegrityBoundaryResult(True, integrity_ref=integrity_ref)
