"""v2.02.89 — Audit durability recovery isolation gate.

Verifies that repeated evidence recovery is read-only: the durable artifact
must remain byte-for-byte stable across repeated recovery attempts, while the
recovered audit/attestation state remains identical and production blockers
and safety state remain unchanged. This gate never unlocks trading.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass

from .audit_durability_evidence_gate import recover_audit_evidence, verify_recovered_evidence
from .evidence_integrity_attestation import EvidenceIntegrityAttestationGate
from .evidence_integrity_attestation_persistence import serialize_attestation
from .production_blockers import open_production_blockers


@dataclass(frozen=True)
class RecoveryIsolationDecision:
    valid: bool
    reason: str
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"


def _file_digest(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


class AuditDurabilityRecoveryIsolationGate:
    """Require repeated recovery to be strictly read-only and stable."""

    def __init__(self, original_gate: EvidenceIntegrityAttestationGate):
        self.original_gate = original_gate

    def verify(self, path: str, expected_audit, expected_attestation) -> RecoveryIsolationDecision:
        before_blockers = tuple(b.blocker_id for b in open_production_blockers())
        try:
            before_digest = _file_digest(path)
        except OSError as exc:
            raise ValueError("EVIDENCE_PERSISTENCE_INVALID") from exc

        first, first_att = recover_audit_evidence(path)
        after_first_digest = _file_digest(path)
        second, second_att = recover_audit_evidence(path)
        after_second_digest = _file_digest(path)

        if before_digest != after_first_digest or after_first_digest != after_second_digest:
            return RecoveryIsolationDecision(False, "DURABLE_ARTIFACT_MUTATED_DURING_RECOVERY")
        if not first.verify() or not second.verify():
            return RecoveryIsolationDecision(False, "RECOVERED_AUDIT_INVALID")
        if first.entries != expected_audit.entries or first.prev_hash != expected_audit.prev_hash:
            return RecoveryIsolationDecision(False, "RECOVERED_AUDIT_DRIFT")
        if second.entries != first.entries or second.prev_hash != first.prev_hash:
            return RecoveryIsolationDecision(False, "RECOVERY_NONDETERMINISTIC")
        if serialize_attestation(first_att) != serialize_attestation(expected_attestation):
            return RecoveryIsolationDecision(False, "RECOVERED_ATTESTATION_DRIFT")
        if serialize_attestation(second_att) != serialize_attestation(first_att):
            return RecoveryIsolationDecision(False, "RECOVERY_ATTESTATION_NONDETERMINISTIC")

        result, _, _ = verify_recovered_evidence(self.original_gate, path)
        if not result.valid:
            return RecoveryIsolationDecision(False, result.reason)

        final_digest = _file_digest(path)
        if final_digest != before_digest:
            return RecoveryIsolationDecision(False, "DURABLE_ARTIFACT_MUTATED_DURING_VERIFICATION")

        after_blockers = tuple(b.blocker_id for b in open_production_blockers())
        if before_blockers != after_blockers:
            return RecoveryIsolationDecision(False, "PRODUCTION_BLOCKER_SET_CHANGED")
        return RecoveryIsolationDecision(True, "AUDIT_DURABILITY_RECOVERY_ISOLATION_VERIFIED")
