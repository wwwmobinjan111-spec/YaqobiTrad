"""YaqobiTrad v2.02.189 — provider failover evidence attestation durability continuity boundary."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

CHECKPOINT = "v2.02.189"
PREDECESSOR = "v2.02.188"


@dataclass(frozen=True)
class ProviderFailoverEvidenceAttestationDurabilityContinuityResult:
    valid: bool
    checkpoint: str = CHECKPOINT
    predecessor: str = PREDECESSOR
    continuity_digest: str = ""
    durability_digest: str = ""
    live_trading: str = "SAFE_OFF"
    activation_gate: str = "LOCKED"
    fail_closed: str = "ACTIVE"
    certification: str = "PENDING_REAL_PRODUCTION_RESULTS"


class ProviderFailoverEvidenceAttestationDurabilityContinuityV189:
    """Carry forward v2.02.188 durability evidence with deterministic continuity."""

    @staticmethod
    def _payload(durability):
        required = (
            "valid", "checkpoint", "predecessor", "continuity_digest",
            "durability_digest", "live_trading", "activation_gate", "fail_closed",
        )
        if durability is None or not all(hasattr(durability, name) for name in required):
            raise ValueError("V202189_DURABILITY_INTERFACE_INVALID")
        if not durability.valid:
            raise ValueError("V202189_DURABILITY_INVALID")
        if (durability.checkpoint, durability.predecessor) != (PREDECESSOR, "v2.02.187"):
            raise ValueError("V202189_DURABILITY_LINEAGE_INVALID")
        for name in ("continuity_digest", "durability_digest"):
            value = getattr(durability, name)
            if not isinstance(value, str) or len(value) != 64:
                raise ValueError("V202189_DIGEST_INVALID")
        if (durability.live_trading, durability.activation_gate, durability.fail_closed) != (
            "SAFE_OFF", "LOCKED", "ACTIVE"
        ):
            raise ValueError("V202189_SAFETY_STATE_INVALID")
        return {
            "checkpoint": durability.checkpoint,
            "predecessor": durability.predecessor,
            "continuity_digest": durability.continuity_digest,
            "durability_digest": durability.durability_digest,
            "live_trading": "SAFE_OFF",
            "activation_gate": "LOCKED",
            "fail_closed": "ACTIVE",
        }

    @classmethod
    def carry_forward(cls, durability, *, expected_durability_digest=None):
        payload = cls._payload(durability)
        if (
            expected_durability_digest is not None
            and payload["durability_digest"] != expected_durability_digest
        ):
            raise ValueError("V202189_DURABILITY_DIGEST_MISMATCH")
        canonical = json.dumps(
            payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True
        ).encode()
        digest = hashlib.sha256(canonical).hexdigest()
        return ProviderFailoverEvidenceAttestationDurabilityContinuityResult(
            valid=True,
            continuity_digest=digest,
            durability_digest=payload["durability_digest"],
        )
