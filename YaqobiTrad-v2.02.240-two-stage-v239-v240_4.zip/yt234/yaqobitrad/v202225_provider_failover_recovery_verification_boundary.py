"""YaqobiTrad v2.02.225 — provider failover recovery verification boundary."""
from __future__ import annotations
import hashlib, json
from dataclasses import dataclass
from .production_blockers import open_production_blockers

CHECKPOINT="v2.02.225"; PREDECESSOR="v2.02.224"

@dataclass(frozen=True)
class Result:
    valid: bool
    checkpoint: str=CHECKPOINT; predecessor: str=PREDECESSOR
    live_trading: str="SAFE_OFF"; activation_gate: str="LOCKED"; fail_closed: str="ACTIVE"
    open_blocker_count: int=6; certification: str="PENDING_REAL_PRODUCTION_RESULTS"
    predecessor_digest: str=""; recovery_verification_digest: str=""; checkpoint_digest: str=""

class ProviderFailoverRecoveryVerificationBoundaryV225:
    @staticmethod
    def _digest(value, field):
        if not isinstance(value,str) or len(value)!=64 or any(c not in "0123456789abcdefABCDEF" for c in value):
            raise ValueError(f"V202225_{field.upper()}_DIGEST_INVALID")
        return value.lower()

    @classmethod
    def verify(cls, checkpoint, *, expected_predecessor_digest=None):
        required=("valid","checkpoint","predecessor","checkpoint_digest","integrity_digest","recovery_digest","live_trading","activation_gate","fail_closed")
        if checkpoint is None or not all(hasattr(checkpoint,n) for n in required):
            raise ValueError("V202225_CHECKPOINT_INTERFACE_INVALID")
        if not checkpoint.valid:
            raise ValueError("V202225_CHECKPOINT_INVALID")
        if (checkpoint.checkpoint, checkpoint.predecessor)!=(PREDECESSOR,"v2.02.223"):
            raise ValueError("V202225_LINEAGE_INVALID")
        if (checkpoint.live_trading,checkpoint.activation_gate,checkpoint.fail_closed)!=("SAFE_OFF","LOCKED","ACTIVE"):
            raise ValueError("V202225_SAFETY_STATE_INVALID")
        predecessor_digest=cls._digest(checkpoint.checkpoint_digest,"checkpoint_digest")
        integrity_digest=cls._digest(checkpoint.integrity_digest,"integrity_digest")
        recovery_digest=cls._digest(checkpoint.recovery_digest,"recovery_digest")
        if expected_predecessor_digest is not None and predecessor_digest!=cls._digest(expected_predecessor_digest,"predecessor_digest"):
            raise ValueError("V202225_PREDECESSOR_DIGEST_MISMATCH")
        payload={"checkpoint":PREDECESSOR,"predecessor":"v2.02.223","checkpoint_digest":predecessor_digest,"integrity_digest":integrity_digest,"recovery_digest":recovery_digest,"live_trading":"SAFE_OFF","activation_gate":"LOCKED","fail_closed":"ACTIVE"}
        recovery_digest_v=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":"),ensure_ascii=True).encode()).hexdigest()
        blockers=open_production_blockers()
        if len(blockers)!=6 or any(b.state!="OPEN" for b in blockers):
            raise ValueError("V202225_BLOCKER_STATE_INVALID")
        final={"checkpoint":CHECKPOINT,"predecessor":PREDECESSOR,"predecessor_digest":predecessor_digest,"recovery_verification_digest":recovery_digest_v,"live_trading":"SAFE_OFF","activation_gate":"LOCKED","fail_closed":"ACTIVE"}
        final_digest=hashlib.sha256(json.dumps(final,sort_keys=True,separators=(",",":"),ensure_ascii=True).encode()).hexdigest()
        return Result(True,predecessor_digest=predecessor_digest,recovery_verification_digest=recovery_digest_v,checkpoint_digest=final_digest)
