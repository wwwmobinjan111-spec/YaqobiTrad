from yaqobitrad.account_policy import AccountLimits, AccountPolicy
from yaqobitrad.auto_trader import OneMinuteAutoTrader
from yaqobitrad.market import Candle
from yaqobitrad.portfolio import DurablePortfolio


def candles(n=21, start=100.0, last_close=None, last_high=None, last_low=None, t0=0):
    out=[]
    for i in range(n):
        p=start+i
        close=p+0.8
        high=p+1
        low=p-1
        if i == n-1:
            close = close if last_close is None else last_close
            high = high if last_high is None else last_high
            low = low if last_low is None else last_low
        out.append(Candle(t0+i*60,t0+(i+1)*60,p,high,low,close,10.0,True))
    return out


def policy():
    return AccountPolicy("paper-recovery", role="TRADER", trading_mode="PAPER", limits=AccountLimits(
        allowed_symbols=frozenset({"BTC/USDT"}), max_order_value=1000, max_position_value=5000,
        max_risk_per_trade_pct=2, require_stop_loss=True, require_take_profit=True))


def test_restart_restores_position_and_reconciles(tmp_path):
    path = tmp_path / "portfolio.json"
    portfolio = DurablePortfolio(str(path), balance=1000)
    first = OneMinuteAutoTrader(policy(), portfolio=portfolio)
    entry = first.on_candle_set("BTC/USDT", candles(), quantity=1, stop_loss=119, take_profit=125)
    assert entry.status == "EXECUTED"
    assert first.reconcile_state()["status"] == "RECONCILED"

    restored = OneMinuteAutoTrader(policy(), portfolio=DurablePortfolio(str(path)))
    assert restored.positions["BTC/USDT"].side == "LONG"
    assert restored.account_policy.open_positions == 1
    assert restored.reconcile_state()["status"] == "RECONCILED"


def test_runtime_durable_position_mismatch_is_blocked(tmp_path):
    portfolio = DurablePortfolio(str(tmp_path / "portfolio.json"))
    bot = OneMinuteAutoTrader(policy(), portfolio=portfolio)
    bot.positions["BTC/USDT"] = bot.positions.get("BTC/USDT") or __import__(
        "yaqobitrad.auto_trader", fromlist=["PaperPosition"]
    ).PaperPosition("BTC/USDT", "LONG", 1, 100, 99, 110, "x")
    result = bot.reconcile_state()
    assert result["status"] == "BLOCKED"
    assert result["reason"] == "POSITION_STATE_MISMATCH"


def test_recovery_block_prevents_trading_after_mismatch(tmp_path):
    portfolio = DurablePortfolio(str(tmp_path / "portfolio.json"))
    bot = OneMinuteAutoTrader(policy(), portfolio=portfolio)
    bot.positions["BTC/USDT"] = __import__(
        "yaqobitrad.auto_trader", fromlist=["PaperPosition"]
    ).PaperPosition("BTC/USDT", "LONG", 1, 100, 99, 110, "x")
    blocked = bot.reconcile_state()
    assert blocked["reason"] == "POSITION_STATE_MISMATCH"
    result = bot.on_candle_set("BTC/USDT", candles(), quantity=1, stop_loss=99, take_profit=110)
    assert result.status == "BLOCKED"
    assert result.reason == "POSITION_STATE_MISMATCH"
