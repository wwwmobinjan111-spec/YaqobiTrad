import pytest
from yaqobitrad.security import Authenticator
from yaqobitrad.v202122_production_auth_authorization_boundary import ProductionAuthAuthorizationBoundaryV122 as V

def test_auth_boundary_validates_authenticator():
    a=Authenticator(); a.add_user("u","p",{"TRADER"})
    r=V.verify(a)
    assert r.valid and r.auth_authorization_blocker=="OPEN" and r.open_blocker_count==6

def test_auth_boundary_rejects_invalid_interface():
    with pytest.raises(ValueError,match="AUTH_INTERFACE"):
        V.verify(object())

def test_auth_boundary_preserves_fail_closed_state():
    a=Authenticator(); a.add_user("u","p",{"TRADER"})
    r=V.verify(a)
    assert (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")
