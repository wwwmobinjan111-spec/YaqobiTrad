from types import SimpleNamespace
import pytest
from yaqobitrad.v202210_provider_failover_evidence_attestation_durability_reconciliation_major_global_checkpoint import ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointV210

def integrity():
 return SimpleNamespace(valid=True,checkpoint="v2.02.209",predecessor="v2.02.208",checkpoint_digest="a"*64,integrity_ref="evidence://v202.02.209/integrity",recovery_ref="evidence://v202.02.208/recovery",live_trading="SAFE_OFF",activation_gate="LOCKED",fail_closed="ACTIVE")

def test_v202210_major_checkpoint_verifies_chain_and_safety():
 r=ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointV210.verify(integrity()); assert r.valid and r.checkpoint=="v2.02.210" and r.predecessor=="v2.02.209" and r.open_blocker_count==6 and len(r.checkpoint_digest)==64 and (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")

def test_v202210_checkpoint_digest_deterministic():
 a=ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointV210.verify(integrity()); b=ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointV210.verify(integrity()); assert a.checkpoint_digest==b.checkpoint_digest

def test_v202210_rejects_digest_mismatch():
 with pytest.raises(ValueError,match="V202210_INTEGRITY_DIGEST_MISMATCH"): ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointV210.verify(integrity(),expected_integrity_digest="d"*64)

def test_v202210_rejects_lineage_mismatch():
 x=integrity(); x.predecessor="v2.02.207"
 with pytest.raises(ValueError,match="V202210_INTEGRITY_LINEAGE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointV210.verify(x)

def test_v202210_rejects_unsafe_state():
 x=integrity(); x.activation_gate="OPEN"
 with pytest.raises(ValueError,match="V202210_SAFETY_STATE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointV210.verify(x)
