from types import SimpleNamespace
from yaqobitrad.v202137_production_environment_boundary import ProductionEnvironmentBoundaryV137
from yaqobitrad.v202138_secrets_key_management_boundary import SecretsKeyManagementBoundaryV138

STATE = SimpleNamespace(activation_gate="LOCKED", live_trading="SAFE_OFF", fail_closed="ACTIVE")

def test_v137_production_environment_preserves_safe_state():
    r = ProductionEnvironmentBoundaryV137.verify(STATE)
    assert r.valid and r.open_blocker_count == 6 and r.certification == "PENDING_REAL_PRODUCTION_RESULTS"

def test_v137_rejects_non_production_environment():
    try:
        ProductionEnvironmentBoundaryV137.verify(STATE, environment="paper")
    except ValueError:
        pass
    else:
        raise AssertionError

def test_v138_secret_reference_does_not_open_live():
    r = SecretsKeyManagementBoundaryV138.verify(STATE, secret_ref="vault://yaqobitrad/live-key")
    assert r.valid and r.live_trading == "SAFE_OFF" and r.activation_gate == "LOCKED"

def test_v138_rejects_plaintext_like_reference():
    try:
        SecretsKeyManagementBoundaryV138.verify(STATE, secret_ref="API_KEY=plaintext")
    except ValueError:
        pass
    else:
        raise AssertionError
