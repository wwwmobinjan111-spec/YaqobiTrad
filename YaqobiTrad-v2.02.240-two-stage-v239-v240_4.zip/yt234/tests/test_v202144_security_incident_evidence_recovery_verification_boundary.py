from types import SimpleNamespace
from yaqobitrad.v202144_security_incident_evidence_recovery_verification_boundary import SecurityIncidentEvidenceRecoveryVerificationBoundaryV144

STATE = SimpleNamespace(activation_gate="LOCKED", live_trading="SAFE_OFF", fail_closed="ACTIVE")

def test_v144_recovery_and_verification_refs_preserve_safe_state():
    r = SecurityIncidentEvidenceRecoveryVerificationBoundaryV144.verify(
        STATE,
        recovery_ref="evidence://security-incident/recovery/2026-09",
        verification_ref="evidence://security-incident/recovery-verification/2026-09",
    )
    assert r.valid and r.open_blocker_count == 6
    assert r.live_trading == "SAFE_OFF" and r.activation_gate == "LOCKED"
    assert r.fail_closed == "ACTIVE"
    assert r.predecessor == "v2.02.143"

def test_v144_rejects_plaintext_recovery_or_verification_reference():
    for kwargs in ({"recovery_ref": "TOKEN=plaintext"}, {"verification_ref": "SECRET=plaintext"}):
        try:
            SecurityIncidentEvidenceRecoveryVerificationBoundaryV144.verify(STATE, **kwargs)
        except ValueError:
            pass
        else:
            raise AssertionError
