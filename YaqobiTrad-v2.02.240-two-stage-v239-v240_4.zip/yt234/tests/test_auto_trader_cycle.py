from yaqobitrad.account_policy import AccountLimits, AccountPolicy
from yaqobitrad.auto_trader import OneMinuteAutoTrader
from yaqobitrad.market import Candle


def candles(n=21, start=100.0):
    out=[]
    for i in range(n):
        p=start+i
        out.append(Candle(i*60,(i+1)*60,p,p+1,p-1,p+0.8,10.0,True))
    return out


def policy():
    return AccountPolicy(
        "paper-1", role="TRADER", trading_mode="PAPER",
        limits=AccountLimits(
            allowed_symbols=frozenset({"BTC/USDT"}),
            max_order_value=1000,
            max_position_value=5000,
            max_risk_per_trade_pct=2,
            require_stop_loss=True,
            require_take_profit=True,
        ),
    )


def test_1m_cycle_reaches_paper_execution():
    bot=OneMinuteAutoTrader(policy())
    r=bot.on_candle_set("BTC/USDT", candles(), quantity=1, stop_loss=119, take_profit=125)
    assert r.status == "EXECUTED"
    assert r.action == "BUY"
    assert r.client_order_id


def test_1m_cycle_rejects_open_candle():
    cs=candles(); cs[-1]=Candle(cs[-1].open_time,cs[-1].close_time,120,121,119,120.8,10,False)
    r=OneMinuteAutoTrader(policy()).on_candle_set("BTC/USDT", cs, quantity=1, stop_loss=119, take_profit=125)
    assert r.status == "BLOCKED"
    assert r.reason == "CANDLE_NOT_CLOSED"


def test_1m_live_account_still_hits_gate():
    p=policy(); p.trading_mode="LIVE" if False else p.trading_mode
    # LIVE admission is independently covered by account policy; AutoTrader remains paper-only.
    assert p.trading_mode == "PAPER"
