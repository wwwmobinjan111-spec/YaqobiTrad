from yaqobitrad.execution import ExecutionEngine
from yaqobitrad.risk import RiskEngine
from yaqobitrad import config


def test_paper_revalidates_activation_boundary_before_commit(monkeypatch):
    engine = ExecutionEngine(RiskEngine())
    original = engine.activation.evaluate
    calls = {"n": 0}

    def flip_after_first(action):
        calls["n"] += 1
        result = original(action)
        if calls["n"] == 1:
            monkeypatch.setattr(config, "FAIL_CLOSED", False)
        return result

    class Wrapper:
        def evaluate(self, action):
            return flip_after_first(action)
    engine.activation = Wrapper()
    result = engine.paper_submit("BUY", 1, 100, client_order_id="v256-1")
    assert result["status"] == "BLOCKED"
    assert result["reason"] == "UNSAFE_STATE"
    assert engine.control.reconcile() is True


def test_paper_commits_only_after_final_safe_boundary(monkeypatch):
    engine = ExecutionEngine(RiskEngine())
    original = engine.activation.evaluate
    calls = {"n": 0}

    def observe(action):
        calls["n"] += 1
        return original(action)

    class Wrapper:
        def evaluate(self, action):
            return observe(action)
    engine.activation = Wrapper()
    result = engine.paper_submit("BUY", 1, 100, client_order_id="v256-2")
    assert result["status"] == "PAPER_FILLED"
    assert calls["n"] == 2


def test_live_path_never_commits_even_after_final_revalidation():
    engine = ExecutionEngine(RiskEngine())
    result = engine.submit("BUY", 1, 100, client_order_id="v256-live")
    assert result["status"] == "BLOCKED"
    assert result["reason"] in {"ACTIVATION_GATE_LOCKED", "LIVE_TRADING_DISABLED"}


def test_invalid_runtime_state_is_rejected_at_final_boundary(monkeypatch):
    engine = ExecutionEngine(RiskEngine())
    original = engine.activation.evaluate
    calls = {"n": 0}

    def invalidate_on_second(action):
        calls["n"] += 1
        if calls["n"] == 2:
            monkeypatch.setattr(config, "ACTIVATION_GATE", "OPEN")
        return original(action)

    class Wrapper:
        def evaluate(self, action):
            return invalidate_on_second(action)
    engine.activation = Wrapper()
    result = engine.paper_submit("BUY", 1, 100, client_order_id="v256-3")
    assert result["status"] == "BLOCKED"
    assert result["reason"] == "UNSAFE_STATE"
