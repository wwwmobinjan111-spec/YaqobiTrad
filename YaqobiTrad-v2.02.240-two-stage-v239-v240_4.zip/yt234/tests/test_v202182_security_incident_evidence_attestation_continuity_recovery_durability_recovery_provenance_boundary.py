from yaqobitrad.v202182_security_incident_evidence_attestation_continuity_recovery_durability_recovery_provenance_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryProvenanceBoundaryV182
class SafeState: activation_gate="LOCKED"; live_trading="SAFE_OFF"; fail_closed="ACTIVE"
def test_v202182_accepts_distinct_refs():
 r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryProvenanceBoundaryV182.verify(SafeState(),state_ref="evidence://state/v182",continuity_ref="evidence://continuity/v182",recovery_ref="evidence://recovery/v182",lineage_ref="evidence://lineage/v182",attestation_ref="evidence://attestation/v182")
 assert r.valid and r.checkpoint=="v2.02.182" and r.predecessor=="v2.02.181" and r.open_blocker_count==6
def test_v202182_rejects_reuse():
 try: SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryProvenanceBoundaryV182.verify(SafeState(),state_ref="evidence://same",continuity_ref="evidence://continuity",recovery_ref="evidence://recovery",lineage_ref="evidence://lineage",attestation_ref="evidence://same")
 except ValueError as e: assert str(e)=="V202182_REFERENCE_REUSE_INVALID"
 else: raise AssertionError("reference reuse was not rejected")
