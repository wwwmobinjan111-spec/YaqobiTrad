from yaqobitrad.audit import AuditLog
from yaqobitrad.checkpoint_evidence_seal import CheckpointEvidenceSealer
from yaqobitrad.evidence_release_gate import EvidenceReleaseGate
from yaqobitrad.evidence_release_reconciliation_gate import EvidenceReleaseReconciliationGate
from yaqobitrad.evidence_release_finalization_gate import EvidenceReleaseFinalizationGate
from yaqobitrad.evidence_retention import RetentionPolicy
from yaqobitrad.evidence_retention_gate import EvidenceRetentionGate
from yaqobitrad.global_checkpoint import global_checkpoint

def setup():
    audit = AuditLog()
    retention = EvidenceRetentionGate(audit)
    assert retention.verify(RetentionPolicy(90, True, True, True)).valid
    sealer = CheckpointEvidenceSealer(audit)
    checkpoint = global_checkpoint()
    sealer.seal(checkpoint)
    release = EvidenceReleaseGate(audit, retention, sealer)
    assert release.authorize(checkpoint).allowed
    reconciliation = EvidenceReleaseReconciliationGate(audit, retention, release)
    return audit, reconciliation, checkpoint

def test_finalization_succeeds():
    audit, reconciliation, checkpoint = setup()
    gate = EvidenceReleaseFinalizationGate(audit, reconciliation)
    result = gate.finalize(checkpoint)
    assert result.finalized
    assert result.reason == "EVIDENCE_RELEASE_FINALIZED"
    assert gate.finalized
    assert audit.verify()

def test_invalid_audit_blocks_finalization():
    audit, reconciliation, checkpoint = setup()
    audit.entries[0]["data"]["minimum_days"] = 1
    gate = EvidenceReleaseFinalizationGate(audit, reconciliation)
    result = gate.finalize(checkpoint)
    assert not result.finalized
    assert result.reason == "AUDIT_CHAIN_INVALID"
    assert not gate.finalized

def test_finalization_is_idempotent():
    audit, reconciliation, checkpoint = setup()
    gate = EvidenceReleaseFinalizationGate(audit, reconciliation)
    first = gate.finalize(checkpoint)
    count = len(audit.entries)
    second = gate.finalize(checkpoint)
    assert first.finalized and second.finalized
    assert len(audit.entries) == count
