from yaqobitrad.v202181_security_incident_evidence_attestation_continuity_recovery_durability_provenance_continuity_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityProvenanceContinuityBoundaryV181
class SafeState: activation_gate="LOCKED"; live_trading="SAFE_OFF"; fail_closed="ACTIVE"
def test_v202181_accepts_distinct_refs():
 r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityProvenanceContinuityBoundaryV181.verify(SafeState(),state_ref="evidence://state/v181",continuity_ref="evidence://continuity/v181",recovery_ref="evidence://recovery/v181",lineage_ref="evidence://lineage/v181",attestation_ref="evidence://attestation/v181")
 assert r.valid and r.checkpoint=="v2.02.181" and r.predecessor=="v2.02.180" and r.open_blocker_count==6
def test_v202181_rejects_reuse():
 try: SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityProvenanceContinuityBoundaryV181.verify(SafeState(),state_ref="evidence://same",continuity_ref="evidence://continuity",recovery_ref="evidence://recovery",lineage_ref="evidence://lineage",attestation_ref="evidence://same")
 except ValueError as e: assert str(e)=="V202181_REFERENCE_REUSE_INVALID"
 else: raise AssertionError("reference reuse was not rejected")
