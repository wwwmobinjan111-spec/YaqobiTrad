"""v2.02.89 — Audit durability recovery isolation tests."""
import json
import hashlib
import pytest

from yaqobitrad.audit import AuditLog
from yaqobitrad.audit_durability_evidence_gate import persist_audit_evidence
from yaqobitrad.durability_continuity_gate import DurabilityContinuityGate
from yaqobitrad.evidence_integrity_attestation import EvidenceIntegrityAttestationGate
from yaqobitrad.production_blockers import open_production_blockers
from yaqobitrad.durability_recovery_isolation_gate import AuditDurabilityRecoveryIsolationGate


def setup():
    audit = AuditLog()
    audit.append("EVIDENCE_CREATED", {"checkpoint": "v2.02.88"})
    audit.append("AUDIT_DURABILITY_CONTINUITY_VERIFIED", {"checkpoint": "v2.02.88"})
    gate = EvidenceIntegrityAttestationGate(audit)
    attestation, result = gate.attest()
    assert result.valid
    return audit, gate, attestation


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_v20289_recovery_is_read_only(tmp_path):
    audit, gate, attestation = setup()
    path = tmp_path / "evidence.json"
    persist_audit_evidence(audit, attestation, str(path))
    before = digest(path)
    result = AuditDurabilityRecoveryIsolationGate(gate).verify(str(path), audit, attestation)
    assert result.valid
    assert result.reason == "AUDIT_DURABILITY_RECOVERY_ISOLATION_VERIFIED"
    assert digest(path) == before


def test_v20289_repeated_recovery_preserves_exact_state(tmp_path):
    audit, gate, attestation = setup()
    path = tmp_path / "evidence.json"
    persist_audit_evidence(audit, attestation, str(path))
    result = AuditDurabilityRecoveryIsolationGate(gate).verify(str(path), audit, attestation)
    assert result.valid
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"


def test_v20289_detects_post_recovery_artifact_mutation(tmp_path):
    audit, gate, attestation = setup()
    path = tmp_path / "evidence.json"
    persist_audit_evidence(audit, attestation, str(path))
    data = json.loads(path.read_text())
    data["audit"]["entries"][0]["event"] = "MUTATED"
    # Recompute envelope digest so the mutation reaches the recovery layer.
    body = {k: data[k] for k in ("schema_version", "audit", "attestation")}
    data["envelope_digest"] = hashlib.sha256(
        json.dumps(body, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    path.write_text(json.dumps(data, sort_keys=True, separators=(",", ":")))
    with pytest.raises(ValueError, match="AUDIT_RECOVERY_FAILED"):
        AuditDurabilityRecoveryIsolationGate(gate).verify(str(path), audit, attestation)


def test_v20289_missing_artifact_fails_closed(tmp_path):
    audit, gate, attestation = setup()
    with pytest.raises(ValueError, match="EVIDENCE_PERSISTENCE_INVALID"):
        AuditDurabilityRecoveryIsolationGate(gate).verify(str(tmp_path / "missing.json"), audit, attestation)


def test_v20289_blockers_preserved(tmp_path):
    audit, gate, attestation = setup()
    before = tuple(b.blocker_id for b in open_production_blockers())
    path = tmp_path / "evidence.json"
    persist_audit_evidence(audit, attestation, str(path))
    result = AuditDurabilityRecoveryIsolationGate(gate).verify(str(path), audit, attestation)
    after = tuple(b.blocker_id for b in open_production_blockers())
    assert result.valid
    assert before == after
