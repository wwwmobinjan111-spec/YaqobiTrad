from types import SimpleNamespace
import pytest
from yaqobitrad.v202236_production_blocker_evidence_attestation_boundary import ProductionBlockerEvidenceAttestationBoundaryV236 as V

def cp(): return SimpleNamespace(valid=True,checkpoint='v2.02.235',predecessor='v2.02.234',live_trading='SAFE_OFF',activation_gate='LOCKED',fail_closed='ACTIVE')
def test_attestation_requires_real_evidence():
 r=V.verify(cp()); assert r.valid and r.open_blocker_count==6 and r.attestation_authority=='REAL_PRODUCTION_EVIDENCE_ONLY'
def test_no_closure(): assert V.verify(cp()).open_blocker_count==6
def test_fake_attestation_rejected():
 with pytest.raises(ValueError,match='V202236_REAL_PRODUCTION_ATTESTATION_REQUIRED'): V.verify(cp(),evidence_attested=True)
def test_lineage_rejected():
 x=cp(); x.predecessor='v2.02.233'
 with pytest.raises(ValueError,match='V202236_LINEAGE_INVALID'): V.verify(x)
def test_safety_preserved():
 r=V.verify(cp()); assert (r.live_trading,r.activation_gate,r.fail_closed)==('SAFE_OFF','LOCKED','ACTIVE')
