from types import SimpleNamespace
import pytest
from yaqobitrad.v202239_production_blocker_evidence_completeness_boundary import ProductionBlockerEvidenceCompletenessBoundaryV239 as V

def cp(): return SimpleNamespace(valid=True,checkpoint='v2.02.238',predecessor='v2.02.237',live_trading='SAFE_OFF',activation_gate='LOCKED',fail_closed='ACTIVE')
def test_partial_not_complete(): assert not V.verify(cp(),evidence_ids=(V.REQUIRED[0],)).evidence_complete
def test_all_six_complete_but_not_closed():
 r=V.verify(cp(),evidence_ids=V.REQUIRED); assert r.evidence_complete and not r.closure_authorized
def test_invalid_id():
 with pytest.raises(ValueError,match='V202239_EVIDENCE_ID_INVALID'): V.verify(cp(),evidence_ids=('fake',))
def test_duplicate_rejected():
 with pytest.raises(ValueError,match='V202239_EVIDENCE_DUPLICATE'): V.verify(cp(),evidence_ids=(V.REQUIRED[0],V.REQUIRED[0]))
def test_safety():
 r=V.verify(cp()); assert (r.live_trading,r.activation_gate,r.fail_closed)==('SAFE_OFF','LOCKED','ACTIVE')
