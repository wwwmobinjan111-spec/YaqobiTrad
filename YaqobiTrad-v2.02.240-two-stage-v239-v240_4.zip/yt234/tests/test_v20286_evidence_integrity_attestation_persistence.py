"""v2.02.86 — Evidence Integrity Attestation Persistence Gate tests."""
import json

import pytest

from yaqobitrad.audit import AuditLog
from yaqobitrad.evidence_integrity_attestation import EvidenceIntegrityAttestationGate
from yaqobitrad.evidence_integrity_attestation_persistence import (
    SCHEMA_VERSION,
    deserialize_attestation,
    serialize_attestation,
    verify_persisted_attestation,
)


def setup():
    audit = AuditLog()
    audit.append("EVIDENCE_CREATED", {"checkpoint": "v2.02.83"})
    gate = EvidenceIntegrityAttestationGate(audit)
    attestation, result = gate.attest()
    assert result.valid
    return audit, gate, attestation


def test_v20286_round_trip_is_deterministic_and_verifiable():
    _, gate, attestation = setup()
    payload = serialize_attestation(attestation)
    restored = deserialize_attestation(payload)
    assert serialize_attestation(restored) == payload
    result = verify_persisted_attestation(gate, payload)
    assert result.valid
    assert result.reason == "EVIDENCE_INTEGRITY_ATTESTATION_VERIFIED"


def test_v20286_schema_version_is_required():
    _, _, attestation = setup()
    data = json.loads(serialize_attestation(attestation))
    data["schema_version"] = "v2.02.85"
    with pytest.raises(ValueError, match="ATTESTATION_SCHEMA_VERSION_INVALID"):
        deserialize_attestation(json.dumps(data))


def test_v20286_unknown_or_missing_fields_are_rejected():
    _, _, attestation = setup()
    data = json.loads(serialize_attestation(attestation))
    del data["attestation_digest"]
    with pytest.raises(ValueError, match="ATTESTATION_SCHEMA_INVALID"):
        deserialize_attestation(json.dumps(data))
    data = json.loads(serialize_attestation(attestation))
    data["forged"] = "x"
    with pytest.raises(ValueError, match="ATTESTATION_SCHEMA_INVALID"):
        deserialize_attestation(json.dumps(data))


def test_v20286_persisted_tampering_remains_fail_closed():
    audit, gate, attestation = setup()
    data = json.loads(serialize_attestation(attestation))
    data["blocker_ids"] = list(data["blocker_ids"]) + ["forged"]
    result = verify_persisted_attestation(gate, json.dumps(data))
    assert result.valid is False
    assert result.reason == "ATTESTATION_DIGEST_MISMATCH"
    assert audit.verify()
