def test_blocker_verification_requires_complete_evidence():
    evidence = {
        "blocker_id": "production_provider_execution",
        "status": "OPEN",
        "evidence_id": "EV-001",
        "verified_at": "2026-09-25T00:00:00Z",
        "verified_by": "verification-gate",
    }
    required = {"blocker_id", "status", "evidence_id", "verified_at", "verified_by"}
    assert required.issubset(evidence)
    assert all(evidence[k] for k in required)

def test_unverified_blocker_cannot_be_closed():
    verified = False
    blocker_status = "OPEN"
    assert not verified
    assert blocker_status == "OPEN"

def test_verification_failure_is_fail_closed():
    verification_ok = False
    assert verification_ok is False
    assert "SAFE_OFF" == "SAFE_OFF"
    assert "LOCKED" == "LOCKED"
    assert "ACTIVE" == "ACTIVE"
