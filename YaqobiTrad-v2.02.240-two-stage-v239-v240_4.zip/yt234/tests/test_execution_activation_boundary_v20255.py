from yaqobitrad.execution import ExecutionEngine
from yaqobitrad.risk import RiskEngine
from yaqobitrad import config


def test_live_intent_is_blocked_by_central_activation_boundary():
    result = ExecutionEngine(RiskEngine()).submit("BUY", 1, 100)
    assert result["status"] == "BLOCKED"
    assert result["reason"] == "ACTIVATION_GATE_LOCKED"


def test_live_intent_never_reaches_provider_when_boundary_blocks(monkeypatch):
    engine = ExecutionEngine(RiskEngine())
    called = {"value": False}
    def forbidden(*args, **kwargs):
        called["value"] = True
        raise AssertionError("live provider must not be reached")
    engine.control.live_submit = forbidden
    result = engine.submit("BUY", 1, 100)
    assert result["status"] == "BLOCKED"
    assert called["value"] is False


def test_live_intent_fails_closed_when_runtime_gate_is_unsafe(monkeypatch):
    monkeypatch.setattr(config, "FAIL_CLOSED", False)
    result = ExecutionEngine(RiskEngine()).submit("BUY", 1, 100)
    assert result["status"] == "BLOCKED"
    assert result["reason"] == "UNSAFE_STATE"
