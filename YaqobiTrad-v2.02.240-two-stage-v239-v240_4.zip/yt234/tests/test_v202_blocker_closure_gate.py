def test_blocker_closure_requires_evidence():
    blockers = {
        "production_provider_execution": "OPEN",
        "production_auth_authorization": "OPEN",
        "production_secret_management": "OPEN",
        "production_portfolio_persistence": "OPEN",
        "production_monitoring": "OPEN",
        "live_provider_e2e": "OPEN",
    }
    closure_requires_evidence = True
    assert closure_requires_evidence
    assert all(state == "OPEN" for state in blockers.values())

def test_unverified_closure_cannot_unlock_activation():
    unverified = True
    activation_gate = "LOCKED"
    live_trading = "SAFE_OFF"
    assert unverified
    assert activation_gate == "LOCKED"
    assert live_trading == "SAFE_OFF"

def test_closure_gate_is_fail_closed():
    missing_evidence = True
    fail_closed = "ACTIVE"
    assert missing_evidence
    assert fail_closed == "ACTIVE"
