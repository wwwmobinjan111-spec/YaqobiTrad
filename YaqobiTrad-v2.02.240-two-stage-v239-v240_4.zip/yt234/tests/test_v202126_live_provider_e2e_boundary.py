from yaqobitrad.v202126_live_provider_e2e_boundary import LiveProviderE2EBoundaryV126
class Provider:
    live_enabled=False
    def submit(self,*a,**k): pass
    def reconcile(self,*a,**k): pass
def test_live_e2e_boundary_accepts_safe_provider():
    r=LiveProviderE2EBoundaryV126.verify(Provider()); assert r.valid and r.live_provider_e2e_blocker=="OPEN"
def test_live_e2e_boundary_rejects_live_enable():
    p=Provider(); p.live_enabled=True
    try: LiveProviderE2EBoundaryV126.verify(p)
    except ValueError as e: assert str(e)=="V202126_LIVE_E2E_REQUIRES_EXPLICIT_PRODUCTION_AUTHORIZATION"
    else: assert False
def test_live_e2e_boundary_preserves_safety():
    r=LiveProviderE2EBoundaryV126.verify(Provider()); assert (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")
