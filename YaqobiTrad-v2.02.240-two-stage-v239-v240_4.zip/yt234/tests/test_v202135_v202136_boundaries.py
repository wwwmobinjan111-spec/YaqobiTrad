from types import SimpleNamespace
from yaqobitrad.v202135_production_evidence_provenance_boundary import ProductionEvidenceProvenanceV135
from yaqobitrad.v202136_activation_precondition_aggregation_boundary import ActivationPreconditionAggregationV136

STATE=SimpleNamespace(activation_gate="LOCKED",live_trading="SAFE_OFF",fail_closed="ACTIVE")

def test_v135_provenance_preserves_safe_state():
    r=ProductionEvidenceProvenanceV135.verify(STATE,"digest-135")
    assert r.valid and r.open_blocker_count==6 and r.live_trading=="SAFE_OFF"

def test_v135_rejects_invalid_digest():
    try: ProductionEvidenceProvenanceV135.verify(STATE," ")
    except ValueError: pass
    else: raise AssertionError

def test_v136_aggregates_only_safe_preconditions():
    r=ActivationPreconditionAggregationV136.verify(STATE)
    assert r.valid and r.activation_gate=="LOCKED" and r.fail_closed=="ACTIVE"

def test_v136_rejects_live_state():
    bad=SimpleNamespace(activation_gate="OPEN",live_trading="LIVE",fail_closed="ACTIVE")
    try: ActivationPreconditionAggregationV136.verify(bad)
    except ValueError: pass
    else: raise AssertionError
