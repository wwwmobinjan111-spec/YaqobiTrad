import os

from yaqobitrad.activation_gate import ActivationBoundary
from yaqobitrad import config


def test_runtime_safe_boundary_allows_paper():
    result = ActivationBoundary().evaluate("PAPER")
    assert result.status == "ALLOWED"
    assert result.action == "PAPER"
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"


def test_runtime_boundary_never_allows_live():
    result = ActivationBoundary().evaluate("LIVE")
    assert result.status == "BLOCKED"
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"


def test_runtime_boundary_blocks_invalid_action():
    result = ActivationBoundary().evaluate("UNKNOWN")
    assert result.status == "BLOCKED"
    assert result.reason == "INVALID_ACTION"


def test_runtime_failure_forces_safe_boundary():
    result = ActivationBoundary().failure("runtime_fault")
    assert result.status == "FAILED_SAFE"
    assert result.action == "SHUTDOWN"
    assert result.reason == "runtime_fault"
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"


def test_paper_execution_uses_activation_boundary():
    from yaqobitrad.execution import ExecutionEngine
    from yaqobitrad.risk import RiskEngine
    result = ExecutionEngine(RiskEngine()).paper_submit("BUY", 1, 100)
    assert result["status"] == "PAPER_FILLED"


def test_paper_is_blocked_if_fail_closed_is_not_active(monkeypatch):
    monkeypatch.setattr(config, "FAIL_CLOSED", False)
    result = ActivationBoundary().evaluate("PAPER")
    assert result.status == "BLOCKED"
    assert result.reason == "UNSAFE_STATE"
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"
