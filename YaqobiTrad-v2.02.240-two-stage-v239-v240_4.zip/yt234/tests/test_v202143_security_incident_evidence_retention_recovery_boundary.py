from types import SimpleNamespace
from yaqobitrad.v202143_security_incident_evidence_retention_recovery_boundary import SecurityIncidentEvidenceRetentionRecoveryBoundaryV143

STATE = SimpleNamespace(activation_gate="LOCKED", live_trading="SAFE_OFF", fail_closed="ACTIVE")

def test_v143_retention_and_recovery_refs_preserve_safe_state():
    r = SecurityIncidentEvidenceRetentionRecoveryBoundaryV143.verify(
        STATE,
        retention_ref="evidence://security-incident/retention/2026-09",
        recovery_ref="evidence://security-incident/recovery/2026-09",
    )
    assert r.valid and r.open_blocker_count == 6
    assert r.live_trading == "SAFE_OFF" and r.activation_gate == "LOCKED"
    assert r.fail_closed == "ACTIVE"

def test_v143_rejects_plaintext_retention_or_recovery_reference():
    for kwargs in ({"retention_ref": "TOKEN=plaintext"}, {"recovery_ref": "SECRET=plaintext"}):
        try:
            SecurityIncidentEvidenceRetentionRecoveryBoundaryV143.verify(STATE, **kwargs)
        except ValueError:
            pass
        else:
            raise AssertionError
