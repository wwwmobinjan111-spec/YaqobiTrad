from types import SimpleNamespace
import pytest
from yaqobitrad.v202198_provider_failover_evidence_attestation_durability_reconciliation_recovery_boundary import ProviderFailoverEvidenceAttestationDurabilityReconciliationRecoveryBoundaryV198

def state(): return SimpleNamespace(activation_gate="LOCKED",live_trading="SAFE_OFF",fail_closed="ACTIVE")
def refs(): return dict(reconciliation_ref="evidence://v202.02.195/reconciliation",recovery_ref="evidence://v202.02.198/recovery",continuity_ref="evidence://v202.02.197/continuity",integrity_ref="evidence://v202.02.196/integrity")
def test_v202198_recovery_boundary():
 r=ProviderFailoverEvidenceAttestationDurabilityReconciliationRecoveryBoundaryV198.verify(state(),**refs()); assert r.valid and r.checkpoint=="v2.02.198" and r.predecessor=="v2.02.197" and r.open_blocker_count==6
def test_v202198_safety_is_fail_closed():
 x=state(); x.live_trading="ON"
 with pytest.raises(ValueError,match="V202198_SAFETY_STATE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationRecoveryBoundaryV198.verify(x,**refs())
def test_v202198_refs_unique():
 r=refs(); r["integrity_ref"]=r["recovery_ref"]
 with pytest.raises(ValueError,match="V202198_REFERENCE_REUSE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationRecoveryBoundaryV198.verify(state(),**r)
def test_v202198_rejects_secret():
 r=refs(); r["recovery_ref"]="evidence://v202.02.198/SECRET"
 with pytest.raises(ValueError,match="V202198_RECOVERY_REF_SECRET_OR_ASSIGNMENT_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationRecoveryBoundaryV198.verify(state(),**r)
def test_v202198_rejects_assignment():
 r=refs(); r["continuity_ref"]="evidence://v202.02.198/continuity=x"
 with pytest.raises(ValueError,match="V202198_CONTINUITY_REF_SECRET_OR_ASSIGNMENT_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationRecoveryBoundaryV198.verify(state(),**r)
