from types import SimpleNamespace
import pytest

from yaqobitrad.v202183_provider_failover_verification import ProviderFailoverVerificationV183
from yaqobitrad.v202184_provider_failover_evidence_binding import ProviderFailoverEvidenceBindingV184


class SafeState:
    activation_gate = "LOCKED"
    live_trading = "SAFE_OFF"
    fail_closed = "ACTIVE"


class Provider:
    def __init__(self, candle=None, error=None):
        self.candle = candle
        self.error = error

    def fetch_latest_closed_candle(self, symbol, interval):
        if self.error:
            raise self.error
        return self.candle


def verification():
    candle = SimpleNamespace(closed=True, close_time=1700000059999)
    return ProviderFailoverVerificationV183.verify(
        SafeState(), [
            ("primary", Provider(error=ConnectionError("primary unavailable"))),
            ("secondary", Provider(candle=candle)),
        ]
    )


def test_v202184_binds_failover_evidence_and_preserves_safety():
    r = ProviderFailoverEvidenceBindingV184.bind(
        verification(), evidence_ref="evidence://provider-failover/v183"
    )
    assert r.valid and r.checkpoint == "v2.02.184" and r.predecessor == "v2.02.183"
    assert r.selected_provider == "secondary"
    assert r.attempted_providers == ("primary", "secondary")
    assert r.failover_used is True
    assert len(r.evidence_digest) == 64
    assert (r.live_trading, r.activation_gate, r.fail_closed) == ("SAFE_OFF", "LOCKED", "ACTIVE")


def test_v202184_digest_is_deterministic_for_same_inputs():
    a = ProviderFailoverEvidenceBindingV184.bind(
        verification(), evidence_ref="evidence://provider-failover/v183"
    )
    b = ProviderFailoverEvidenceBindingV184.bind(
        verification(), evidence_ref="evidence://provider-failover/v183"
    )
    assert a.evidence_digest == b.evidence_digest


def test_v202184_rejects_invalid_evidence_ref():
    with pytest.raises(ValueError, match="V202184_EVIDENCE_REF_INVALID"):
        ProviderFailoverEvidenceBindingV184.bind(verification(), evidence_ref=" ")


def test_v202184_rejects_unsafe_verification_state():
    result = SimpleNamespace(
        valid=True, checkpoint="v2.02.183", predecessor="v2.02.182",
        selected_provider="primary", attempted_providers=("primary",),
        failover_used=False, live_trading="ENABLED", activation_gate="LOCKED", fail_closed="ACTIVE",
    )
    with pytest.raises(ValueError, match="V202184_SAFETY_STATE_INVALID"):
        ProviderFailoverEvidenceBindingV184.bind(result, evidence_ref="evidence://unsafe")


def test_v202184_rejects_duplicate_provider_attempts():
    result = SimpleNamespace(
        valid=True, checkpoint="v2.02.183", predecessor="v2.02.182",
        selected_provider="primary", attempted_providers=("primary", "primary"),
        failover_used=False, live_trading="SAFE_OFF", activation_gate="LOCKED", fail_closed="ACTIVE",
    )
    with pytest.raises(ValueError, match="V202184_PROVIDER_ATTEMPTS_DUPLICATE"):
        ProviderFailoverEvidenceBindingV184.bind(result, evidence_ref="evidence://duplicate")
