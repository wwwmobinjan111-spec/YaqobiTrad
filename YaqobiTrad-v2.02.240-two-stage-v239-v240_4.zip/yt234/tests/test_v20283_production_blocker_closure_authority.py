"""v2.02.83 — production blocker closure authority tests."""
from yaqobitrad.production_blocker_closure import ProductionBlockerClosureAuthority
from yaqobitrad.production_blockers import PRODUCTION_BLOCKERS

EXPECTED = tuple(b.blocker_id for b in PRODUCTION_BLOCKERS)


def test_v20283_no_evidence_keeps_every_production_blocker_open():
    gate = ProductionBlockerClosureAuthority()
    assert tuple(k for k, state in gate.all_current_states() if state == "OPEN") == EXPECTED


def test_v20283_unknown_or_partial_evidence_cannot_close_other_blockers():
    evidence = {EXPECTED[0]: True, "unknown": True}
    gate = ProductionBlockerClosureAuthority(evidence)
    assert gate.closure_state(EXPECTED[0]) == "RESOLVED"
    assert all(gate.closure_state(k) == "OPEN" for k in EXPECTED[1:])
    assert gate.can_close("unknown") is False


def test_v20283_empty_evidence_is_fail_closed():
    gate = ProductionBlockerClosureAuthority({})
    assert all(state == "OPEN" for _, state in gate.all_current_states())
