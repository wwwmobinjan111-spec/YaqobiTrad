from yaqobitrad.v202130_major_global_checkpoint import MajorGlobalCheckpointV130
class S:
    activation_gate="LOCKED"; live_trading="SAFE_OFF"; fail_closed="ACTIVE"
def test_major_checkpoint_valid():
    r=MajorGlobalCheckpointV130.verify(S()); assert r.valid and r.major_global_checkpoint
def test_invalid_safety_rejected():
    class X(S): live_trading="ON"
    try: MajorGlobalCheckpointV130.verify(X())
    except ValueError: return
    assert False
def test_major_checkpoint_preserves_six_blockers():
    r=MajorGlobalCheckpointV130.verify(S()); assert r.open_blocker_count==6 and r.certification.startswith("PENDING")
