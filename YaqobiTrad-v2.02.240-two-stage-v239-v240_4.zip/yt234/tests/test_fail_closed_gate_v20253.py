from yaqobitrad.fail_closed_gate import FailClosedEnforcementGate


SAFE = {
    "live_trading": "SAFE_OFF",
    "activation_gate": "LOCKED",
    "fail_closed": "ACTIVE",
}


def test_healthy_paper_state_is_allowed():
    result = FailClosedEnforcementGate().evaluate(SAFE, action="PAPER")
    assert result.status == "ALLOWED"
    assert result.action == "PAPER"
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"


def test_live_action_is_always_blocked():
    result = FailClosedEnforcementGate().evaluate(SAFE, action="LIVE")
    assert result.status == "BLOCKED"
    assert result.reason == "LIVE_TRADING_DISABLED"
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"


def test_unsafe_state_is_normalized_to_blocked():
    state = {"live_trading": "ON", "activation_gate": "UNLOCKED", "fail_closed": "INACTIVE"}
    result = FailClosedEnforcementGate().evaluate(state, action="PAPER")
    assert result.status == "BLOCKED"
    assert result.reason == "UNSAFE_STATE"
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"


def test_invalid_state_fails_closed():
    result = FailClosedEnforcementGate().evaluate(None, action="PAPER")
    assert result.status == "BLOCKED"
    assert result.reason == "INVALID_STATE"
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"


def test_invalid_action_fails_closed():
    result = FailClosedEnforcementGate().evaluate(SAFE, action="UNKNOWN")
    assert result.status == "BLOCKED"
    assert result.reason == "INVALID_ACTION"


def test_failure_forces_safe_boundary_even_from_unsafe_input():
    state = {"live_trading": "ON", "activation_gate": "UNLOCKED", "fail_closed": "INACTIVE"}
    result = FailClosedEnforcementGate().enforce_failure(state, reason="provider_error")
    assert result.status == "FAILED_SAFE"
    assert result.action == "SHUTDOWN"
    assert result.reason == "provider_error"
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"


def test_empty_failure_reason_uses_safe_default():
    result = FailClosedEnforcementGate().enforce_failure(SAFE, reason="")
    assert result.status == "FAILED_SAFE"
    assert result.reason == "UNSPECIFIED_FAILURE"
    assert result.live_trading == "SAFE_OFF"
