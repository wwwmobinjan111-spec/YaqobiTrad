from types import SimpleNamespace
import pytest
from yaqobitrad.v202201_provider_failover_evidence_attestation_durability_reconciliation_checkpoint_continuity_boundary import ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointContinuityBoundaryV201

def state(): return SimpleNamespace(checkpoint="v2.02.201",predecessor="v2.02.200",live_trading="SAFE_OFF",activation_gate="LOCKED",fail_closed="ACTIVE",checkpoint_digest="a"*64)
def test_v202201_accepts_continuous_checkpoint():
 r=ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointContinuityBoundaryV201.verify(state(),checkpoint_digest="a"*64,reconciliation_ref="evidence://v202.02.195/reconciliation",provenance_ref="evidence://v202.02.199/provenance"); assert r.valid and r.checkpoint=="v2.02.201" and r.predecessor=="v2.02.200"
def test_v202201_rejects_digest_mismatch():
 with pytest.raises(ValueError,match="V202201_CHECKPOINT_DIGEST_MISMATCH"): ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointContinuityBoundaryV201.verify(state(),checkpoint_digest="b"*64,reconciliation_ref="evidence://a",provenance_ref="evidence://b")
def test_v202201_rejects_lineage():
 s=state(); s.predecessor="v2.02.199"
 with pytest.raises(ValueError,match="V202201_LINEAGE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointContinuityBoundaryV201.verify(s,checkpoint_digest="a"*64,reconciliation_ref="evidence://a",provenance_ref="evidence://b")
def test_v202201_rejects_unsafe_state():
 s=state(); s.activation_gate="OPEN"
 with pytest.raises(ValueError,match="V202201_SAFETY_STATE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointContinuityBoundaryV201.verify(s,checkpoint_digest="a"*64,reconciliation_ref="evidence://a",provenance_ref="evidence://b")
def test_v202201_rejects_reference_reuse():
 with pytest.raises(ValueError,match="V202201_REFERENCE_REUSE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointContinuityBoundaryV201.verify(state(),checkpoint_digest="a"*64,reconciliation_ref="evidence://a",provenance_ref="evidence://a")
