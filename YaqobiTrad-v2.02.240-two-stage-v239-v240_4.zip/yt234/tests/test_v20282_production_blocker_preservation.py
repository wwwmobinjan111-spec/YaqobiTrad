"""YaqobiTrad v2.02.82 — production blocker preservation gate.

Version changes must not manufacture closure of unresolved production blockers.
This gate is source-level only and never unlocks live trading.
"""
from yaqobitrad.production_blockers import PRODUCTION_BLOCKERS, open_production_blockers
from yaqobitrad.global_checkpoint import global_checkpoint, checkpoint_is_fail_closed

EXPECTED_BLOCKERS = (
    "production_provider_execution",
    "production_auth_authorization",
    "production_secret_management",
    "production_portfolio_persistence",
    "production_monitoring",
    "live_provider_e2e",
)


def test_v20282_preserves_exact_production_blocker_set():
    observed = tuple(b.blocker_id for b in PRODUCTION_BLOCKERS)
    assert observed == EXPECTED_BLOCKERS


def test_v20282_does_not_close_blockers_without_production_evidence():
    blockers = open_production_blockers()
    assert tuple(b.blocker_id for b in blockers) == EXPECTED_BLOCKERS
    assert all(b.state == "OPEN" for b in blockers)


def test_v20282_preserves_fail_closed_activation_state():
    cp = global_checkpoint()
    assert cp.open_blocker_count == len(EXPECTED_BLOCKERS)
    assert cp.activation_gate == "LOCKED"
    assert cp.fail_closed == "ACTIVE"
    assert cp.live_trading == "SAFE_OFF"
    assert checkpoint_is_fail_closed() is True


def test_v20282_has_no_source_level_certification_claim():
    cp = global_checkpoint()
    assert cp.certification == "PENDING_REAL_PRODUCTION_RESULTS"
