from yaqobitrad.global_checkpoint import global_checkpoint, checkpoint_is_fail_closed

def test_v20281_checkpoint_version_is_current():
    assert global_checkpoint().checkpoint == "v2.02.90"

def test_v20281_preserves_safety_state():
    cp = global_checkpoint()
    assert cp.activation_gate == "LOCKED"
    assert cp.fail_closed == "ACTIVE"
    assert cp.live_trading == "SAFE_OFF"

def test_v20281_remains_fail_closed_with_open_blockers():
    assert checkpoint_is_fail_closed() is True
