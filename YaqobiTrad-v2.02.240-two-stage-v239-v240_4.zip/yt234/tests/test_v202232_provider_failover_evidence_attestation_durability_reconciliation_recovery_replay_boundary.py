from types import SimpleNamespace
import pytest
from yaqobitrad.v202232_provider_failover_evidence_attestation_durability_reconciliation_recovery_replay_boundary import ProviderFailoverEvidenceAttestationDurabilityReconciliationRecoveryReplayBoundaryV232 as V
def continuity(): return SimpleNamespace(valid=True,checkpoint="v2.02.231",predecessor="v2.02.230",checkpoint_digest="a"*64,predecessor_digest="b"*64,recovery_continuity_digest="c"*64,live_trading="SAFE_OFF",activation_gate="LOCKED",fail_closed="ACTIVE")
def test_v202232_recovery_replay_verifies_chain_and_safety():
 r=V.verify(continuity()); assert r.valid and r.checkpoint=="v2.02.232" and r.predecessor=="v2.02.231" and r.open_blocker_count==6 and len(r.replay_digest)==64 and len(r.checkpoint_digest)==64 and (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")
def test_v202232_digest_deterministic():
 a=V.verify(continuity()); b=V.verify(continuity()); assert a.replay_digest==b.replay_digest and a.checkpoint_digest==b.checkpoint_digest
def test_v202232_rejects_continuity_digest_mismatch():
 with pytest.raises(ValueError,match="V202232_CONTINUITY_DIGEST_MISMATCH"): V.verify(continuity(),expected_continuity_digest="d"*64)
def test_v202232_rejects_lineage_mismatch():
 x=continuity(); x.predecessor="v2.02.229"
 with pytest.raises(ValueError,match="V202232_LINEAGE_INVALID"): V.verify(x)
def test_v202232_rejects_unsafe_state():
 x=continuity(); x.activation_gate="OPEN"
 with pytest.raises(ValueError,match="V202232_SAFETY_STATE_INVALID"): V.verify(x)
