from yaqobitrad.audit import AuditLog
from yaqobitrad.checkpoint_evidence_seal import CheckpointEvidenceSealer
from yaqobitrad.evidence_release_gate import EvidenceReleaseGate
from yaqobitrad.evidence_release_reconciliation_gate import EvidenceReleaseReconciliationGate
from yaqobitrad.evidence_release_finalization_gate import EvidenceReleaseFinalizationGate
from yaqobitrad.evidence_release_commitment_gate import EvidenceReleaseCommitmentGate
from yaqobitrad.evidence_release_publication_gate import EvidenceReleasePublicationGate
from yaqobitrad.evidence_release_distribution_gate import EvidenceReleaseDistributionGate
from yaqobitrad.evidence_retention import RetentionPolicy
from yaqobitrad.evidence_retention_gate import EvidenceRetentionGate
from yaqobitrad.global_checkpoint import global_checkpoint

def setup():
    audit = AuditLog()
    retention = EvidenceRetentionGate(audit)
    assert retention.verify(RetentionPolicy(90, True, True, True)).valid
    sealer = CheckpointEvidenceSealer(audit)
    checkpoint = global_checkpoint()
    sealer.seal(checkpoint)
    release = EvidenceReleaseGate(audit, retention, sealer)
    assert release.authorize(checkpoint).allowed
    reconciliation = EvidenceReleaseReconciliationGate(audit, retention, release)
    finalization = EvidenceReleaseFinalizationGate(audit, reconciliation)
    commitment = EvidenceReleaseCommitmentGate(audit, finalization)
    publication = EvidenceReleasePublicationGate(audit, commitment)
    return audit, publication, checkpoint

def test_distribution_succeeds():
    audit, publication, checkpoint = setup()
    gate = EvidenceReleaseDistributionGate(audit, publication)
    result = gate.distribute(checkpoint)
    assert result.distributed
    assert result.reason == "EVIDENCE_RELEASE_DISTRIBUTED"
    assert gate.distributed
    assert audit.verify()

def test_invalid_audit_blocks_distribution():
    audit, publication, checkpoint = setup()
    audit.entries[0]["data"]["minimum_days"] = 1
    gate = EvidenceReleaseDistributionGate(audit, publication)
    result = gate.distribute(checkpoint)
    assert not result.distributed
    assert result.reason == "AUDIT_CHAIN_INVALID"
    assert not gate.distributed

def test_distribution_is_idempotent():
    audit, publication, checkpoint = setup()
    gate = EvidenceReleaseDistributionGate(audit, publication)
    first = gate.distribute(checkpoint)
    count = len(audit.entries)
    second = gate.distribute(checkpoint)
    assert first.distributed and second.distributed
    assert len(audit.entries) == count
