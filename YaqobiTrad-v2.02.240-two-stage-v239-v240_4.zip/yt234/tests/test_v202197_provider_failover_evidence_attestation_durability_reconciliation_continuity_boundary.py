from types import SimpleNamespace
import pytest
from yaqobitrad.v202197_provider_failover_evidence_attestation_durability_reconciliation_continuity_boundary import ProviderFailoverEvidenceAttestationDurabilityReconciliationContinuityBoundaryV197

def state(): return SimpleNamespace(activation_gate="LOCKED",live_trading="SAFE_OFF",fail_closed="ACTIVE")
def refs(): return dict(reconciliation_ref="evidence://v202.02.195/reconciliation",continuity_ref="evidence://v202.02.197/continuity",integrity_ref="evidence://v202.02.196/integrity",attestation_ref="evidence://v202.02.197/attestation")
def test_v202197_continuity_boundary():
 r=ProviderFailoverEvidenceAttestationDurabilityReconciliationContinuityBoundaryV197.verify(state(),**refs()); assert r.valid and r.checkpoint=="v2.02.197" and r.predecessor=="v2.02.196" and r.open_blocker_count==6
def test_v202197_safety_is_fail_closed():
 x=state(); x.activation_gate="OPEN"
 with pytest.raises(ValueError,match="V202197_SAFETY_STATE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationContinuityBoundaryV197.verify(x,**refs())
def test_v202197_refs_unique():
 r=refs(); r["attestation_ref"]=r["integrity_ref"]
 with pytest.raises(ValueError,match="V202197_REFERENCE_REUSE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationContinuityBoundaryV197.verify(state(),**r)
def test_v202197_rejects_secret():
 r=refs(); r["continuity_ref"]="evidence://v202.02.197/PRIVATE_KEY"
 with pytest.raises(ValueError,match="V202197_CONTINUITY_REF_SECRET_OR_ASSIGNMENT_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationContinuityBoundaryV197.verify(state(),**r)
def test_v202197_rejects_assignment():
 r=refs(); r["reconciliation_ref"]="evidence://v202.02.197/reconciliation=x"
 with pytest.raises(ValueError,match="V202197_RECONCILIATION_REF_SECRET_OR_ASSIGNMENT_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationContinuityBoundaryV197.verify(state(),**r)
