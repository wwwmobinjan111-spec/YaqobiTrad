from dataclasses import replace

from yaqobitrad.recovery import create_checkpoint
from yaqobitrad.restart_gate import RecoveryRestartGate


def test_restart_preserves_safe_boundary():
    result = RecoveryRestartGate().restart()
    assert result.status == "RESTART_REQUIRED"
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"


def test_valid_recovery_requires_reconciliation_before_resume():
    gate = RecoveryRestartGate()
    checkpoint = create_checkpoint(10, {"mode": "PAPER", "balance": 100})
    recovered = gate.recover(checkpoint, expected_sequence=10)
    assert recovered.status == "RECOVERED"
    blocked = gate.resume()
    assert blocked.status == "BLOCKED"
    assert blocked.reason == "RECONCILIATION_REQUIRED"
    assert blocked.live_trading == "SAFE_OFF"
    assert blocked.activation_gate == "LOCKED"


def test_reconciliation_failure_is_fail_closed():
    gate = RecoveryRestartGate()
    checkpoint = create_checkpoint(10, {"mode": "PAPER"})
    gate.recover(checkpoint, expected_sequence=10)
    result = gate.reconcile(False)
    assert result.status == "FAILED_SAFE"
    assert result.reason == "RECONCILIATION_FAILED"
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"


def test_valid_recovery_and_reconciliation_allows_paper_resume_only():
    gate = RecoveryRestartGate()
    checkpoint = create_checkpoint(10, {"mode": "PAPER"})
    gate.recover(checkpoint, expected_sequence=10)
    ready = gate.reconcile(True)
    assert ready.status == "READY_PAPER"
    resumed = gate.resume()
    assert resumed.status == "RESUMED_PAPER"
    assert resumed.live_trading == "SAFE_OFF"
    assert resumed.activation_gate == "LOCKED"
    assert resumed.fail_closed == "ACTIVE"
    assert "PAPER_RESUME_AUTHORIZED" in resumed.audit


def test_tampered_checkpoint_cannot_resume():
    gate = RecoveryRestartGate()
    checkpoint = create_checkpoint(10, {"balance": 100})
    tampered = replace(checkpoint, digest="0" * 64)
    recovered = gate.recover(tampered, expected_sequence=10)
    assert recovered.status == "FAILED_SAFE"
    assert recovered.reason == "checkpoint integrity failure"
    blocked = gate.resume()
    assert blocked.status == "BLOCKED"
    assert blocked.reason == "RECOVERY_NOT_COMPLETE"
    assert blocked.live_trading == "SAFE_OFF"


def test_sequence_mismatch_cannot_bypass_restart_gate():
    gate = RecoveryRestartGate()
    checkpoint = create_checkpoint(10, {"mode": "PAPER"})
    recovered = gate.recover(checkpoint, expected_sequence=11)
    assert recovered.status == "FAILED_SAFE"
    assert recovered.reason == "checkpoint sequence mismatch"
    assert gate.resume().status == "BLOCKED"
