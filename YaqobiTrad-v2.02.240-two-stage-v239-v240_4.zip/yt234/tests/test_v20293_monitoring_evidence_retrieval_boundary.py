"""v2.02.93 — monitoring evidence retrieval/recovery boundary tests."""
import json
import pytest

from yaqobitrad.evidence_retention import RetentionPolicy
from yaqobitrad.monitoring import MonitoringState
from yaqobitrad.monitoring_evidence_boundary import MonitoringEvidenceBoundary
from yaqobitrad.monitoring_evidence_retrieval_boundary import MonitoringEvidenceRetrievalBoundary
from yaqobitrad.production_blockers import open_production_blockers


def setup(tmp_path):
    state = MonitoringState()
    state.heartbeat(100.0)
    gate = MonitoringEvidenceRetrievalBoundary(MonitoringEvidenceBoundary(state))
    evidence = {"timestamp": 100.0, "healthy": True, "heartbeat": 100.0}
    policy = RetentionPolicy(minimum_days=90, immutable=True, remote=True, verified=True)
    path = tmp_path / "monitoring-evidence.json"
    path.write_text(json.dumps(gate.envelope(evidence, policy), sort_keys=True, separators=(",", ":")))
    return gate, path


def test_v20293_verified_retrieval(tmp_path):
    gate, path = setup(tmp_path)
    result = gate.retrieve(str(path), now=110.0, max_age=30.0)
    assert result.valid
    assert result.reason == "MONITORING_EVIDENCE_RETRIEVAL_RECOVERY_VERIFIED"
    assert result.evidence["healthy"] is True
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"


def test_v20293_digest_mismatch_fails_closed(tmp_path):
    gate, path = setup(tmp_path)
    payload = json.loads(path.read_text())
    payload["evidence"]["healthy"] = False
    path.write_text(json.dumps(payload, sort_keys=True, separators=(",", ":")))
    with pytest.raises(ValueError, match="MONITORING_EVIDENCE_RETRIEVAL_DIGEST_MISMATCH"):
        gate.retrieve(str(path), now=110.0, max_age=30.0)


def test_v20293_invalid_schema_fails_closed(tmp_path):
    gate, path = setup(tmp_path)
    payload = json.loads(path.read_text())
    payload.pop("retention")
    path.write_text(json.dumps(payload, sort_keys=True, separators=(",", ":")))
    with pytest.raises(ValueError, match="MONITORING_EVIDENCE_RETRIEVAL_SCHEMA_INVALID"):
        gate.retrieve(str(path), now=110.0, max_age=30.0)


def test_v20293_unverified_retention_fails_closed(tmp_path):
    gate, path = setup(tmp_path)
    payload = json.loads(path.read_text())
    payload["retention"]["verified"] = False
    body = {k: payload[k] for k in ("schema_version", "evidence", "retention")}
    import hashlib
    payload["envelope_digest"] = hashlib.sha256(
        json.dumps(body, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    path.write_text(json.dumps(payload, sort_keys=True, separators=(",", ":")))
    with pytest.raises(ValueError, match="MONITORING_RETENTION_NOT_VERIFIED"):
        gate.retrieve(str(path), now=110.0, max_age=30.0)


def test_v20293_stale_evidence_fails_closed(tmp_path):
    gate, path = setup(tmp_path)
    payload = json.loads(path.read_text())
    payload["evidence"]["heartbeat"] = 50.0
    body = {k: payload[k] for k in ("schema_version", "evidence", "retention")}
    import hashlib
    payload["envelope_digest"] = hashlib.sha256(
        json.dumps(body, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    path.write_text(json.dumps(payload, sort_keys=True, separators=(",", ":")))
    with pytest.raises(ValueError, match="MONITORING_HEARTBEAT_STALE"):
        gate.retrieve(str(path), now=110.0, max_age=30.0)


def test_v20293_retrieval_is_read_only_and_preserves_blockers(tmp_path):
    gate, path = setup(tmp_path)
    before_bytes = path.read_bytes()
    before = tuple(b.blocker_id for b in open_production_blockers())
    result = gate.retrieve(str(path), now=110.0, max_age=30.0)
    after_bytes = path.read_bytes()
    after = tuple(b.blocker_id for b in open_production_blockers())
    assert result.valid
    assert before_bytes == after_bytes
    assert before == after
    assert len(after) == 6
