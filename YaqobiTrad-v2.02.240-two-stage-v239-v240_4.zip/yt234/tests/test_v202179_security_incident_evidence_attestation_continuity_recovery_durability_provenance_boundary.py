from yaqobitrad.v202179_security_incident_evidence_attestation_continuity_recovery_durability_provenance_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityProvenanceBoundaryV179

class SafeState:
    activation_gate="LOCKED"
    live_trading="SAFE_OFF"
    fail_closed="ACTIVE"

def test_v202179_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityProvenanceBoundaryV179.verify(SafeState(), state_ref="evidence://state/v178", continuity_ref="evidence://continuity/v178", recovery_ref="evidence://recovery/v178", lineage_ref="evidence://lineage/v178", attestation_ref="evidence://attestation/v178")
    assert r.valid and r.checkpoint=="v2.02.179" and r.predecessor=="v2.02.178" and r.open_blocker_count==6

def test_v202179_rejects_reuse():
    try:
        SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityProvenanceBoundaryV179.verify(SafeState(), state_ref="evidence://same", continuity_ref="evidence://continuity", recovery_ref="evidence://recovery", lineage_ref="evidence://lineage", attestation_ref="evidence://same")
    except ValueError as e:
        assert str(e)=="V202179_REFERENCE_REUSE_INVALID"
    else:
        raise AssertionError("reference reuse was not rejected")
