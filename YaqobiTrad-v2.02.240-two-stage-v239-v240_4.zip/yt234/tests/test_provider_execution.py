from yaqobitrad.provider_execution import PaperExecutionProvider, LiveExecutionProvider

def test_paper_provider_submit_and_idempotency():
    p = PaperExecutionProvider()
    a = p.submit("c1", "BUY", 1, 100)
    b = p.submit("c1", "BUY", 1, 100)
    assert a == b
    assert a.status == "FILLED"
    assert a.provider_order_id == "PAPER-1"

def test_paper_provider_reconcile():
    p = PaperExecutionProvider()
    p.submit("c1", "BUY", 1, 100)
    p.submit("c2", "SELL", 1, 101)
    assert p.reconcile(["c1", "c2"])
    assert not p.reconcile(["c1"])

def test_live_provider_remains_fail_closed():
    result = LiveExecutionProvider().submit("BUY", 1, 100)
    assert result == {"status": "BLOCKED", "reason": "LIVE_PROVIDER_ADAPTER_NOT_VERIFIED"}


def test_provider_failure_after_create_recovers_without_duplicate():
    p = PaperExecutionProvider(fail_after_create_once=True)
    order, retries = p.submit_with_recovery("recover-1", "BUY", 1, 100, max_retries=1)
    assert retries == 1
    assert order.provider_order_id == "PAPER-1"
    assert len(p.orders) == 1
    replay = p.submit("recover-1", "BUY", 1, 100)
    assert replay.provider_order_id == order.provider_order_id
    assert len(p.orders) == 1


def test_provider_failure_recovery_is_bounded():
    p = PaperExecutionProvider(fail_after_create_once=True)
    import pytest
    with pytest.raises(Exception):
        p.submit_with_recovery("recover-2", "SELL", 1, 101, max_retries=0)
    assert len(p.orders) == 1
