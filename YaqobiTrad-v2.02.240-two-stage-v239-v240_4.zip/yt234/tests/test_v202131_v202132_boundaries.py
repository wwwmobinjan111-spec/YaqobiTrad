from types import SimpleNamespace
from yaqobitrad.v202131_production_readiness_evidence_boundary import ProductionReadinessEvidenceV131
from yaqobitrad.v202132_activation_preflight_boundary import ActivationPreflightV132

STATE=SimpleNamespace(activation_gate="LOCKED",live_trading="SAFE_OFF",fail_closed="ACTIVE")

def test_v131_readiness_evidence_preserves_safe_state():
    r=ProductionReadinessEvidenceV131.verify(STATE)
    assert r.valid and r.open_blocker_count==6

def test_v131_rejects_unsafe_state():
    bad=SimpleNamespace(activation_gate="OPEN",live_trading="SAFE_OFF",fail_closed="ACTIVE")
    try: ProductionReadinessEvidenceV131.verify(bad)
    except ValueError: pass
    else: raise AssertionError

def test_v132_activation_preflight_never_authorizes_live():
    r=ActivationPreflightV132.verify(STATE)
    assert r.valid and r.live_trading=="SAFE_OFF" and r.activation_gate=="LOCKED"
