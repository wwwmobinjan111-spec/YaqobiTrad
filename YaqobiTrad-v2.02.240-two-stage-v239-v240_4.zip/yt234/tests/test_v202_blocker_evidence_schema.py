def test_blocker_evidence_schema_requires_minimum_fields():
    required = {
        "blocker_id",
        "status",
        "evidence_id",
        "verified_at",
        "verified_by",
    }
    sample = {
        "blocker_id": "production_provider_execution",
        "status": "OPEN",
        "evidence_id": None,
        "verified_at": None,
        "verified_by": None,
    }
    assert required.issubset(sample.keys())
    assert sample["status"] in {"OPEN", "CLOSED"}

def test_missing_evidence_cannot_close_blocker():
    evidence_id = None
    status = "OPEN"
    assert evidence_id is None
    assert status == "OPEN"

def test_invalid_or_incomplete_evidence_is_fail_closed():
    evidence_valid = False
    activation_gate = "LOCKED"
    live_trading = "SAFE_OFF"
    fail_closed = "ACTIVE"
    assert not evidence_valid
    assert activation_gate == "LOCKED"
    assert live_trading == "SAFE_OFF"
    assert fail_closed == "ACTIVE"
