from types import SimpleNamespace
from yaqobitrad.v202155_security_incident_evidence_attestation_state_continuity_attestation_boundary import SecurityIncidentEvidenceAttestationStateContinuityAttestationBoundaryV155

STATE = SimpleNamespace(activation_gate="LOCKED", live_trading="SAFE_OFF", fail_closed="ACTIVE")

def test_v155_attestation_preserves_safe_state_and_blockers():
    r = SecurityIncidentEvidenceAttestationStateContinuityAttestationBoundaryV155.verify(
        STATE,
        state_ref="evidence://security-incident/attestation-state/2026-09",
        continuity_ref="evidence://security-incident/attestation-state-continuity/2026-09",
    )
    assert r.valid and r.open_blocker_count == 6
    assert r.predecessor == "v2.02.154"
    assert (r.live_trading, r.activation_gate, r.fail_closed) == ("SAFE_OFF", "LOCKED", "ACTIVE")

def test_v155_rejects_reference_reuse():
    ref = "evidence://security-incident/attestation-state/2026-09"
    try:
        SecurityIncidentEvidenceAttestationStateContinuityAttestationBoundaryV155.verify(STATE, state_ref=ref, continuity_ref=ref)
    except ValueError:
        pass
    else:
        raise AssertionError
