def test_production_blocker_registry_is_explicit_and_closed():
    blockers = {
        "production_provider_execution": "OPEN",
        "production_auth_authorization": "OPEN",
        "production_secret_management": "OPEN",
        "production_portfolio_persistence": "OPEN",
        "production_monitoring": "OPEN",
        "live_provider_e2e": "OPEN",
    }
    assert len(blockers) == 6
    assert all(state == "OPEN" for state in blockers.values())

def test_open_blocker_registry_keeps_activation_locked():
    blockers_open = True
    activation_gate = "LOCKED"
    live_trading = "SAFE_OFF"
    fail_closed = "ACTIVE"
    assert blockers_open
    assert activation_gate == "LOCKED"
    assert live_trading == "SAFE_OFF"
    assert fail_closed == "ACTIVE"

def test_blocker_registry_is_not_a_live_activation_command():
    registry_actions = {"REGISTER", "REVIEW", "CLOSE"}
    assert "ACTIVATE_LIVE" not in registry_actions
