from types import SimpleNamespace
from yaqobitrad.v202147_security_incident_evidence_attestation_continuity_boundary import SecurityIncidentEvidenceAttestationContinuityBoundaryV147

STATE = SimpleNamespace(activation_gate="LOCKED", live_trading="SAFE_OFF", fail_closed="ACTIVE")

def test_v147_continuity_boundary_preserves_safe_state_and_blockers():
    r = SecurityIncidentEvidenceAttestationContinuityBoundaryV147.verify(
        STATE,
        previous_attestation_ref="evidence://security-incident/recovery-verification-attestation/2026-09",
        continuity_ref="evidence://security-incident/attestation-continuity/2026-09",
    )
    assert r.valid and r.open_blocker_count == 6
    assert r.live_trading == "SAFE_OFF" and r.activation_gate == "LOCKED" and r.fail_closed == "ACTIVE"
    assert r.predecessor == "v2.02.146"

def test_v147_rejects_secret_or_assignment_material():
    for value in ("SECRET=plaintext", "evidence://security-incident/TOKEN/value"):
        try:
            SecurityIncidentEvidenceAttestationContinuityBoundaryV147.verify(
                STATE,
                previous_attestation_ref=value,
                continuity_ref="evidence://security-incident/attestation-continuity/2026-09",
            )
        except ValueError:
            pass
        else:
            raise AssertionError
