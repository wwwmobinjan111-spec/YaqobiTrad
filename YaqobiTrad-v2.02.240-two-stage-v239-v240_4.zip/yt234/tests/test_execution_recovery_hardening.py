from yaqobitrad.execution_recovery import ExecutionRecoveryManager, AmbiguousExecutionError, PermanentExecutionError
from yaqobitrad.provider_execution import PaperExecutionProvider, ProviderOrder


def test_ambiguous_after_create_reconciles_without_duplicate():
    p = PaperExecutionProvider(fail_after_create_once=True)
    r = ExecutionRecoveryManager(p, max_retries=2).execute("r-1", "BUY", 1, 100)
    assert r.status == "RECOVERED"
    assert r.provider_order_id == "PAPER-1"
    assert r.reconciled is True
    assert r.attempts == 0
    assert len(p.orders) == 1
    assert "RECONCILE_FOUND" in r.audit


def test_ambiguous_unknown_result_is_reconciled_before_retry():
    class UnknownProvider(PaperExecutionProvider):
        def submit(self, client_order_id, side, quantity, price):
            if not hasattr(self, "failed"):
                self.failed = True
                raise AmbiguousExecutionError("TIMEOUT")
            return super().submit(client_order_id, side, quantity, price)
    p = UnknownProvider()
    r = ExecutionRecoveryManager(p, max_retries=1).execute("r-2", "BUY", 1, 100)
    assert r.status == "EXECUTED"
    assert r.attempts == 1
    assert len(p.orders) == 1


def test_retry_exhaustion_fails_closed():
    class AlwaysUnknown(PaperExecutionProvider):
        def submit(self, *args):
            raise AmbiguousExecutionError("TIMEOUT")
    p = AlwaysUnknown()
    r = ExecutionRecoveryManager(p, max_retries=1).execute("r-3", "SELL", 1, 101)
    assert r.status == "BLOCKED"
    assert r.reason == "AMBIGUOUS_UNRESOLVED"
    assert r.attempts == 1
    assert r.reconciled is False


def test_permanent_failure_is_not_retried():
    class PermanentProvider(PaperExecutionProvider):
        def submit(self, *args):
            raise PermanentExecutionError("REJECTED")
    p = PermanentProvider()
    r = ExecutionRecoveryManager(p, max_retries=5).execute("r-4", "BUY", 1, 100)
    assert r.status == "BLOCKED"
    assert r.reason == "REJECTED"
    assert r.attempts == 0


def test_recovery_reuses_client_order_id_and_preserves_provider_id():
    p = PaperExecutionProvider(fail_after_create_once=True)
    manager = ExecutionRecoveryManager(p, max_retries=1)
    r = manager.execute("r-5", "BUY", 2, 200)
    replay = p.submit("r-5", "BUY", 2, 200)
    assert r.provider_order_id == replay.provider_order_id == "PAPER-1"
    assert len(p.orders) == 1
