from yaqobitrad.v202172_security_incident_evidence_attestation_continuity_recovery_durability_recovery_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryAttestationBoundaryV172
class SafeState:
    activation_gate="LOCKED"; live_trading="SAFE_OFF"; fail_closed="ACTIVE"
def test_v202171_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryAttestationBoundaryV172.verify(SafeState(),state_ref="evidence://state/v171",continuity_ref="evidence://continuity/v171",recovery_ref="evidence://recovery/v171",lineage_ref="evidence://lineage/v171",attestation_ref="evidence://attestation/v171")
    assert r.valid and r.checkpoint=="v2.02.172" and r.predecessor=="v2.02.171" and r.open_blocker_count==6
def test_v202171_rejects_reuse():
    try: SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryAttestationBoundaryV172.verify(SafeState(),state_ref="evidence://same",continuity_ref="evidence://continuity",recovery_ref="evidence://recovery",lineage_ref="evidence://lineage",attestation_ref="evidence://same")
    except ValueError as e: assert str(e)=="V202172_REFERENCE_REUSE_INVALID"
    else: raise AssertionError("reference reuse was not rejected")
