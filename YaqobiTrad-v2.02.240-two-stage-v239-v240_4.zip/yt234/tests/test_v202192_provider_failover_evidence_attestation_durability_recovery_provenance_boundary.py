from types import SimpleNamespace
import pytest
from yaqobitrad.v202192_provider_failover_evidence_attestation_durability_recovery_provenance_boundary import ProviderFailoverEvidenceAttestationDurabilityRecoveryProvenanceBoundaryV192

def state(): return SimpleNamespace(activation_gate="LOCKED", live_trading="SAFE_OFF", fail_closed="ACTIVE")
def refs(): return dict(provenance_ref="evidence://v202.02.191/provenance", recovery_ref="evidence://v202.02.192/recovery", attestation_ref="evidence://v202.02.192/attestation", durability_ref="evidence://v202.02.190/durability")

def test_v202192_recovery_provenance_boundary():
    r=ProviderFailoverEvidenceAttestationDurabilityRecoveryProvenanceBoundaryV192.verify(state(),**refs())
    assert r.valid and r.checkpoint=="v2.02.192" and r.predecessor=="v2.02.191" and r.open_blocker_count==6

def test_v202192_safety_is_fail_closed():
    x=state(); x.live_trading="ON"
    with pytest.raises(ValueError,match="V202192_SAFETY_STATE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityRecoveryProvenanceBoundaryV192.verify(x,**refs())

def test_v202192_refs_must_be_unique():
    r=refs(); r["attestation_ref"]=r["provenance_ref"]
    with pytest.raises(ValueError,match="V202192_REFERENCE_REUSE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityRecoveryProvenanceBoundaryV192.verify(state(),**r)

def test_v202192_rejects_secret_material():
    r=refs(); r["recovery_ref"]="evidence://v202.02.192/PASSWORD"
    with pytest.raises(ValueError,match="V202192_RECOVERY_REF_SECRET_OR_ASSIGNMENT_INVALID"): ProviderFailoverEvidenceAttestationDurabilityRecoveryProvenanceBoundaryV192.verify(state(),**r)

def test_v202192_rejects_assignment():
    r=refs(); r["attestation_ref"]="evidence://v202.02.192/attestation=x"
    with pytest.raises(ValueError,match="V202192_ATTESTATION_REF_SECRET_OR_ASSIGNMENT_INVALID"): ProviderFailoverEvidenceAttestationDurabilityRecoveryProvenanceBoundaryV192.verify(state(),**r)
