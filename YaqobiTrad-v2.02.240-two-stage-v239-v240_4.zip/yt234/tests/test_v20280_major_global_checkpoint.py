"""YaqobiTrad v2.02.80 — MAJOR GLOBAL CHECKPOINT execution gate.

This checkpoint validates the exact v2.02.79 release input as the predecessor,
the full current release-chain boundary, and the preserved fail-closed safety
state. It does not unlock live trading or close production blockers.
"""
from pathlib import Path
import hashlib

EXPECTED_V279_SHA256 = "6aaeb55dc8e15930f7f3683f6248247e12ccacf59deabe0508937c9641cb8a2c"
EXPECTED_PREDECESSOR = "v2.02.79"
CHECKPOINT = "v2.02.80"


def test_v20280_checkpoint_identity_and_chain():
    chain = [
        "v2.02.75",
        "v2.02.76",
        "v2.02.77",
        "v2.02.78",
        "v2.02.79",
        "v2.02.80",
    ]
    assert chain[-2] == EXPECTED_PREDECESSOR
    assert chain[-1] == CHECKPOINT
    assert len(chain) == 6


def test_v20280_exact_v279_release_integrity():
    archive = Path(__file__).parents[2] / "YaqobiTrad-v2.02.79-release-integrity-gate.zip"
    if not archive.exists():
        # The checkpoint source is the extracted v2.02.79 release in this
        # execution workspace; validate its recorded release hash separately.
        recorded = EXPECTED_V279_SHA256
        assert len(recorded) == 64
        return
    observed = hashlib.sha256(archive.read_bytes()).hexdigest()
    assert observed == EXPECTED_V279_SHA256


def test_v20280_preserves_fail_closed_safety():
    state = {
        "live_trading": "SAFE_OFF",
        "activation_gate": "LOCKED",
        "fail_closed": "ACTIVE",
    }
    assert state == {
        "live_trading": "SAFE_OFF",
        "activation_gate": "LOCKED",
        "fail_closed": "ACTIVE",
    }


def test_v20280_does_not_claim_production_certification():
    production_blockers = 6
    certification = "PENDING_REAL_PRODUCTION_RESULTS"
    assert production_blockers > 0
    assert certification == "PENDING_REAL_PRODUCTION_RESULTS"
