from pathlib import Path
from yaqobitrad.account_policy import AccountLimits, AccountPolicy
from yaqobitrad.auto_trader import OneMinuteAutoTrader
from yaqobitrad.audit import AuditLog
from yaqobitrad.market import Candle
from yaqobitrad.portfolio import DurablePortfolio


def candles(n=21, start=100.0, last_close=None, last_high=None, last_low=None, t0=0):
    out=[]
    for i in range(n):
        p=start+i
        close=p+0.8
        high=p+1
        low=p-1
        if i == n-1:
            close = close if last_close is None else last_close
            high = high if last_high is None else last_high
            low = low if last_low is None else last_low
        out.append(Candle(t0+i*60,t0+(i+1)*60,p,high,low,close,10.0,True))
    return out


def policy():
    return AccountPolicy("paper-1", role="TRADER", trading_mode="PAPER", limits=AccountLimits(
        allowed_symbols=frozenset({"BTC/USDT"}), max_order_value=1000, max_position_value=5000,
        max_risk_per_trade_pct=2, require_stop_loss=True, require_take_profit=True))


def test_1m_entry_then_sl_exit_updates_portfolio_and_audit(tmp_path):
    p = policy()
    portfolio = DurablePortfolio(str(tmp_path / "portfolio.json"), balance=1000)
    audit = AuditLog(str(tmp_path / "audit.json"))
    bot = OneMinuteAutoTrader(p, portfolio=portfolio, audit=audit)

    entry = bot.on_candle_set("BTC/USDT", candles(), quantity=1, stop_loss=119, take_profit=125)
    assert entry.status == "EXECUTED"
    assert bot.positions["BTC/USDT"].side == "LONG"
    assert portfolio.reconcile() and audit.verify()

    exit_cs = candles(last_close=119.0, last_high=120.0, last_low=118.5, t0=21*60)
    exit_result = bot.on_candle_set("BTC/USDT", exit_cs, quantity=1, stop_loss=119, take_profit=125)
    assert exit_result.status == "EXITED"
    assert exit_result.reason == "SL"
    assert bot.positions == {}
    assert p.open_positions == 0
    assert portfolio.reconcile() and audit.verify()
    assert [e.event for e in portfolio.entries] == ["ENTRY", "EXIT"]
    assert [e["event"] for e in audit.entries] == ["POSITION_ENTRY", "POSITION_EXIT"]


def test_1m_open_position_waits_without_duplicate_entry(tmp_path):
    p = policy()
    bot = OneMinuteAutoTrader(p, portfolio=DurablePortfolio(str(tmp_path / "p.json")))
    entry = bot.on_candle_set("BTC/USDT", candles(), quantity=1, stop_loss=119, take_profit=125)
    assert entry.status == "EXECUTED"
    waiting = bot.on_candle_set("BTC/USDT", candles(last_close=121.0, last_high=122.0, last_low=120.0, t0=21*60), quantity=1, stop_loss=119, take_profit=125)
    assert waiting.status == "POSITION_OPEN"
    assert len(bot.execution.control._records) == 1
