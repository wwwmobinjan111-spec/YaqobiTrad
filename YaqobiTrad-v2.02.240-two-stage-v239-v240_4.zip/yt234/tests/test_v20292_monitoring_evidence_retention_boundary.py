"""v2.02.92 — monitoring evidence retention boundary tests."""
import pytest
from yaqobitrad.monitoring import MonitoringState
from yaqobitrad.monitoring_evidence_boundary import MonitoringEvidenceBoundary
from yaqobitrad.monitoring_evidence_retention_boundary import MonitoringEvidenceRetentionBoundary
from yaqobitrad.evidence_retention import RetentionPolicy
from yaqobitrad.production_blockers import open_production_blockers


def setup():
    state = MonitoringState()
    state.heartbeat(100.0)
    return MonitoringEvidenceRetentionBoundary(MonitoringEvidenceBoundary(state))


def evidence(healthy=True):
    return {"timestamp": 100.0, "healthy": healthy, "heartbeat": 100.0}


def policy(verified=True):
    return RetentionPolicy(minimum_days=90, immutable=True, remote=True, verified=verified)


def test_v20292_verified_monitoring_retention_boundary():
    gate = setup()
    result = gate.verify(evidence(), now=110.0, max_age=30.0, policy=policy())
    assert result.valid
    assert result.reason == "MONITORING_EVIDENCE_RETENTION_BOUNDARY_VERIFIED"
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"


def test_v20292_unverified_retention_fails_closed():
    gate = setup()
    with pytest.raises(ValueError, match="MONITORING_RETENTION_NOT_VERIFIED"):
        gate.verify(evidence(), now=110.0, max_age=30.0, policy=policy(False))


def test_v20292_stale_monitoring_fails_closed_even_with_retention():
    gate = setup()
    with pytest.raises(ValueError, match="MONITORING_HEARTBEAT_STALE"):
        gate.verify(evidence(), now=140.1, max_age=40.0, policy=policy())


def test_v20292_unhealthy_monitoring_fails_closed():
    gate = setup()
    with pytest.raises(ValueError, match="MONITORING_UNHEALTHY_FAIL_CLOSED"):
        gate.verify(evidence(False), now=110.0, max_age=30.0, policy=policy())


def test_v20292_invalid_policy_type_fails_closed():
    gate = setup()
    with pytest.raises(ValueError, match="MONITORING_RETENTION_POLICY_INVALID"):
        gate.verify(evidence(), now=110.0, max_age=30.0, policy={})


def test_v20292_preserves_all_open_production_blockers():
    gate = setup()
    before = tuple(b.blocker_id for b in open_production_blockers())
    result = gate.verify(evidence(), now=110.0, max_age=30.0, policy=policy())
    after = tuple(b.blocker_id for b in open_production_blockers())
    assert result.valid
    assert before == after
    assert len(after) == 6
