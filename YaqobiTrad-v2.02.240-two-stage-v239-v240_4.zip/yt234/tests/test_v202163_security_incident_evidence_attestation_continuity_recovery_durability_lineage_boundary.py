from yaqobitrad.v202163_security_incident_evidence_attestation_continuity_recovery_durability_lineage_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityLineageBoundaryV163

class SafeState:
    activation_gate="LOCKED"
    live_trading="SAFE_OFF"
    fail_closed="ACTIVE"

def test_v202163_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityLineageBoundaryV163.verify(SafeState(), state_ref="evidence://state/v162", continuity_ref="evidence://continuity/v162", recovery_ref="evidence://recovery/v162")
    assert r.valid and r.checkpoint=="v2.02.163" and r.predecessor=="v2.02.162" and r.open_blocker_count==6

def test_v202163_rejects_reuse():
    try:
        SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityLineageBoundaryV163.verify(SafeState(), state_ref="evidence://same", continuity_ref="evidence://same", recovery_ref="evidence://recovery")
    except ValueError as e:
        assert str(e)=="V202163_REFERENCE_REUSE_INVALID"
    else:
        raise AssertionError("reference reuse was not rejected")
