"""v2.02.87 — Audit Durability Evidence Gate tests."""
import json
from pathlib import Path

import pytest

from yaqobitrad.audit import AuditLog
from yaqobitrad.evidence_integrity_attestation import EvidenceIntegrityAttestationGate
from yaqobitrad.evidence_integrity_attestation_persistence import serialize_attestation
from yaqobitrad.audit_durability_evidence_gate import (
    SCHEMA_VERSION,
    persist_audit_evidence,
    recover_audit_evidence,
    verify_recovered_evidence,
)
from yaqobitrad.production_blockers import open_production_blockers


def setup():
    audit = AuditLog()
    audit.append("EVIDENCE_CREATED", {"checkpoint": "v2.02.86"})
    audit.append("EVIDENCE_ATTESTED", {"source": "v2.02.86"})
    gate = EvidenceIntegrityAttestationGate(audit)
    attestation, result = gate.attest()
    assert result.valid
    return audit, gate, attestation


def test_v20287_restart_recovery_preserves_chain_and_attestation(tmp_path):
    audit, gate, attestation = setup()
    path = tmp_path / "evidence.json"
    persist_audit_evidence(audit, attestation, str(path))
    recovered, restored_att = recover_audit_evidence(str(path))
    assert recovered.verify()
    assert recovered.entries == audit.entries
    assert recovered.prev_hash == audit.prev_hash
    assert serialize_attestation(restored_att) == serialize_attestation(attestation)
    result, _, _ = verify_recovered_evidence(gate, str(path))
    assert result.valid
    assert result.reason == "EVIDENCE_INTEGRITY_ATTESTATION_VERIFIED"


def test_v20287_corruption_is_detected_fail_closed(tmp_path):
    audit, gate, attestation = setup()
    path = tmp_path / "evidence.json"
    persist_audit_evidence(audit, attestation, str(path))
    data = json.loads(path.read_text())
    data["audit"]["entries"][0]["event"] = "MUTATED"
    path.write_text(json.dumps(data))
    with pytest.raises(ValueError, match="EVIDENCE_ENVELOPE_DIGEST_MISMATCH"):
        recover_audit_evidence(str(path))
    assert gate.verify(attestation).valid


def test_v20287_truncation_is_detected_fail_closed(tmp_path):
    audit, _, attestation = setup()
    path = tmp_path / "evidence.json"
    persist_audit_evidence(audit, attestation, str(path))
    data = json.loads(path.read_text())
    data["audit"]["entries"] = data["audit"]["entries"][:-1]
    path.write_text(json.dumps(data))
    with pytest.raises(ValueError, match="EVIDENCE_ENVELOPE_DIGEST_MISMATCH"):
        recover_audit_evidence(str(path))


def test_v20287_blockers_and_safety_state_remain_unchanged(tmp_path):
    audit, gate, attestation = setup()
    before = tuple(b.blocker_id for b in open_production_blockers())
    path = tmp_path / "evidence.json"
    persist_audit_evidence(audit, attestation, str(path))
    result, _, _ = verify_recovered_evidence(gate, str(path))
    after = tuple(b.blocker_id for b in open_production_blockers())
    assert result.valid
    assert before == after
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"


def test_v20287_schema_version_and_unknown_fields_rejected(tmp_path):
    audit, _, attestation = setup()
    path = tmp_path / "evidence.json"
    persist_audit_evidence(audit, attestation, str(path))
    data = json.loads(path.read_text())
    data["schema_version"] = "v2.02.86"
    path.write_text(json.dumps(data))
    with pytest.raises(ValueError, match="EVIDENCE_SCHEMA_VERSION_INVALID"):
        recover_audit_evidence(str(path))
    data["schema_version"] = SCHEMA_VERSION
    data["extra"] = "x"
    path.write_text(json.dumps(data))
    with pytest.raises(ValueError, match="EVIDENCE_SCHEMA_INVALID"):
        recover_audit_evidence(str(path))
