from types import SimpleNamespace
import pytest

from yaqobitrad.v202183_provider_failover_verification import ProviderFailoverVerificationV183


class SafeState:
    activation_gate = "LOCKED"
    live_trading = "SAFE_OFF"
    fail_closed = "ACTIVE"


class Provider:
    def __init__(self, candle=None, error=None):
        self.candle = candle
        self.error = error
        self.calls = 0

    def fetch_latest_closed_candle(self, symbol, interval):
        self.calls += 1
        if self.error:
            raise self.error
        return self.candle


def closed_candle():
    return SimpleNamespace(closed=True, close_time=1700000059999)


def test_v202183_primary_provider_is_selected_without_failover():
    primary = Provider(closed_candle())
    secondary = Provider(closed_candle())
    r = ProviderFailoverVerificationV183.verify(
        SafeState(), [("primary", primary), ("secondary", secondary)]
    )
    assert r.valid and r.checkpoint == "v2.02.183" and r.predecessor == "v2.02.182"
    assert r.selected_provider == "primary" and r.failover_used is False
    assert r.attempted_providers == ("primary",)
    assert primary.calls == 1 and secondary.calls == 0


def test_v202183_fails_over_deterministically_and_stays_safe_off():
    primary = Provider(error=ConnectionError("primary unavailable"))
    secondary = Provider(closed_candle())
    r = ProviderFailoverVerificationV183.verify(
        SafeState(), [("primary", primary), ("secondary", secondary)]
    )
    assert r.valid and r.selected_provider == "secondary"
    assert r.failover_used is True and r.attempted_providers == ("primary", "secondary")
    assert (r.live_trading, r.activation_gate, r.fail_closed) == ("SAFE_OFF", "LOCKED", "ACTIVE")


def test_v202183_blocks_when_all_providers_fail():
    with pytest.raises(RuntimeError, match="V202183_ALL_PROVIDERS_FAILED"):
        ProviderFailoverVerificationV183.verify(
            SafeState(),
            [("primary", Provider(error=ConnectionError("x"))),
             ("secondary", Provider(error=TimeoutError("y")))],
        )
