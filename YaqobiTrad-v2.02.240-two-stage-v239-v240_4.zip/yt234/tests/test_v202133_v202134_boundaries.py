from types import SimpleNamespace
from yaqobitrad.v202133_production_evidence_completeness_boundary import ProductionEvidenceCompletenessV133
from yaqobitrad.v202134_activation_authorization_separation_boundary import ActivationAuthorizationSeparationV134

STATE=SimpleNamespace(activation_gate="LOCKED",live_trading="SAFE_OFF",fail_closed="ACTIVE")

def test_v133_evidence_completeness_preserves_safe_state():
    r=ProductionEvidenceCompletenessV133.verify(STATE)
    assert r.valid and r.open_blocker_count==6 and r.certification=="PENDING_REAL_PRODUCTION_RESULTS"

def test_v133_rejects_unsafe_state():
    bad=SimpleNamespace(activation_gate="OPEN",live_trading="SAFE_OFF",fail_closed="ACTIVE")
    try: ProductionEvidenceCompletenessV133.verify(bad)
    except ValueError: pass
    else: raise AssertionError

def test_v134_authorization_separation_never_opens_live():
    r=ActivationAuthorizationSeparationV134.verify(STATE)
    assert r.valid and r.live_trading=="SAFE_OFF" and r.activation_gate=="LOCKED"

def test_v134_rejects_fail_open_state():
    bad=SimpleNamespace(activation_gate="LOCKED",live_trading="LIVE",fail_closed="ACTIVE")
    try: ActivationAuthorizationSeparationV134.verify(bad)
    except ValueError: pass
    else: raise AssertionError
