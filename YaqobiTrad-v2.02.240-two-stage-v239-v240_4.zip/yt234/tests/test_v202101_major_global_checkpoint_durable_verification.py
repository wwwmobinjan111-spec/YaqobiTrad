import json
import pytest
from yaqobitrad.audit import AuditLog
from yaqobitrad.v202100_major_global_checkpoint import MajorGlobalCheckpoint
from yaqobitrad.v202101_major_global_checkpoint_durable_verification import MajorGlobalCheckpointDurableVerification
from yaqobitrad.production_blockers import open_production_blockers
import hashlib

def _build(path):
    a=AuditLog(str(path))
    a.append("MONITORING_EVIDENCE_RETRIEVAL_VERIFIED", {"schema_version":"v2.02.94","evidence_digest":"digest-1"}); b=a.entries[-1]
    a.append("MONITORING_EVIDENCE_RETRIEVAL_AUDIT_CONTINUITY_VERIFIED", {"schema_version":"v2.02.95","bound_audit_hash":b["hash"],"evidence_digest":"digest-1"}); c=a.entries[-1]
    a.append("MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED", {"schema_version":"v2.02.99","bound_audit_hash":b["hash"],"evidence_digest":"digest-1","continuity_hash":c["hash"]})
    return a.entries[-1]["hash"], b["hash"]

def _digest(path, ah, bh):
    a=AuditLog(str(path)); continuity=a.entries[-1]["prev_hash"]
    canonical={"checkpoint":"v2.02.101","predecessor":"v2.02.100","anchor_hash":ah,"bound_audit_hash":bh,"evidence_digest":"digest-1","continuity_hash":continuity,"blockers":[b.blocker_id for b in open_production_blockers()],"safety":{"live_trading":"SAFE_OFF","activation_gate":"LOCKED","fail_closed":"ACTIVE"},"certification":"PENDING_REAL_PRODUCTION_RESULTS"}
    return hashlib.sha256(json.dumps(canonical,sort_keys=True,separators=(",",":")).encode()).hexdigest()

def test_durable_reload_is_deterministic_and_safe(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p); d=_digest(p,ah,bh); v=MajorGlobalCheckpointDurableVerification()
    r1=v.verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_checkpoint_digest=d)
    r2=v.verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_checkpoint_digest=d)
    assert r1.valid and r1.checkpoint_digest==r2.checkpoint_digest==d
    assert (r1.checkpoint,r1.predecessor,r1.open_blocker_count,r1.certification)==('v2.02.101','v2.02.100',6,'PENDING_REAL_PRODUCTION_RESULTS')
    assert (r1.live_trading,r1.activation_gate,r1.fail_closed)==('SAFE_OFF','LOCKED','ACTIVE')

def test_wrong_checkpoint_digest_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p)
    with pytest.raises(ValueError,match='CHECKPOINT_DIGEST_MISMATCH'): MajorGlobalCheckpointDurableVerification().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_checkpoint_digest='wrong')

def test_wrong_anchor_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p); d=_digest(p,ah,bh)
    with pytest.raises(ValueError,match='ANCHOR_HASH_MISMATCH'): MajorGlobalCheckpointDurableVerification().verify(str(p),expected_anchor_hash='wrong',expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_checkpoint_digest=d)

def test_wrong_bound_hash_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p); d=_digest(p,ah,bh)
    with pytest.raises(ValueError,match='BOUND_AUDIT_HASH_MISMATCH'): MajorGlobalCheckpointDurableVerification().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash='wrong',expected_evidence_digest='digest-1',expected_checkpoint_digest=d)

def test_wrong_evidence_digest_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p); d=_digest(p,ah,bh)
    with pytest.raises(ValueError,match='EVIDENCE_DIGEST_MISMATCH'): MajorGlobalCheckpointDurableVerification().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest='wrong',expected_checkpoint_digest=d)

def test_tamper_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p); d=_digest(p,ah,bh); x=json.loads(p.read_text()); x['entries'][-1]['data']['evidence_digest']='tampered'; p.write_text(json.dumps(x,sort_keys=True))
    with pytest.raises(ValueError,match='audit ledger integrity failure'): MajorGlobalCheckpointDurableVerification().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_checkpoint_digest=d)
