import hashlib, json
import pytest
from yaqobitrad.audit import AuditLog
from yaqobitrad.production_blockers import open_production_blockers
from yaqobitrad.v202102_durable_verification_snapshot_isolation import DurableVerificationSnapshotIsolation

def _build(path):
    a=AuditLog(str(path))
    a.append("MONITORING_EVIDENCE_RETRIEVAL_VERIFIED", {"schema_version":"v2.02.94","evidence_digest":"digest-1"}); b=a.entries[-1]
    a.append("MONITORING_EVIDENCE_RETRIEVAL_AUDIT_CONTINUITY_VERIFIED", {"schema_version":"v2.02.95","bound_audit_hash":b["hash"],"evidence_digest":"digest-1"}); c=a.entries[-1]
    a.append("MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED", {"schema_version":"v2.02.99","bound_audit_hash":b["hash"],"evidence_digest":"digest-1","continuity_hash":c["hash"]})
    return a.entries[-1]["hash"], b["hash"]

def _digest(path):
    a=AuditLog(str(path)); snap={"entries":a.entries,"prev_hash":a.prev_hash}
    return hashlib.sha256(json.dumps(snap,sort_keys=True,separators=(",",":")).encode()).hexdigest()

def test_snapshot_is_deterministic_and_isolated(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p); d=_digest(p); v=DurableVerificationSnapshotIsolation()
    r1=v.verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_snapshot_digest=d)
    r2=v.verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_snapshot_digest=d)
    assert r1.valid and r1.snapshot_digest==r2.snapshot_digest==d
    assert (r1.checkpoint,r1.predecessor,r1.open_blocker_count)==('v2.02.102','v2.02.101',6)

def test_wrong_snapshot_digest_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p)
    with pytest.raises(ValueError,match='SNAPSHOT_DIGEST_MISMATCH'): DurableVerificationSnapshotIsolation().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_snapshot_digest='wrong')

def test_wrong_anchor_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p); d=_digest(p)
    with pytest.raises(ValueError,match='ANCHOR_HASH_MISMATCH'): DurableVerificationSnapshotIsolation().verify(str(p),expected_anchor_hash='wrong',expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_snapshot_digest=d)

def test_wrong_bound_hash_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p); d=_digest(p)
    with pytest.raises(ValueError,match='BOUND_AUDIT_HASH_MISMATCH'): DurableVerificationSnapshotIsolation().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash='wrong',expected_evidence_digest='digest-1',expected_snapshot_digest=d)

def test_wrong_evidence_digest_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p); d=_digest(p)
    with pytest.raises(ValueError,match='EVIDENCE_DIGEST_MISMATCH'): DurableVerificationSnapshotIsolation().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest='wrong',expected_snapshot_digest=d)

def test_persisted_tamper_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p); d=_digest(p); x=json.loads(p.read_text()); x['entries'][-1]['data']['evidence_digest']='tampered'; p.write_text(json.dumps(x,sort_keys=True))
    with pytest.raises(ValueError,match='audit ledger integrity failure'): DurableVerificationSnapshotIsolation().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_snapshot_digest=d)
