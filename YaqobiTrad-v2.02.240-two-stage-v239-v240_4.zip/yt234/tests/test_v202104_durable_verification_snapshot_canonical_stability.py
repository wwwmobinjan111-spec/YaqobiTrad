import hashlib,json,pytest
from yaqobitrad.audit import AuditLog
from yaqobitrad.v202104_durable_verification_snapshot_canonical_stability import DurableVerificationSnapshotCanonicalStability

def _build(path):
 a=AuditLog(str(path)); a.append('MONITORING_EVIDENCE_RETRIEVAL_VERIFIED',{'schema_version':'v2.02.94','evidence_digest':'digest-1'}); b=a.entries[-1]
 a.append('MONITORING_EVIDENCE_RETRIEVAL_AUDIT_CONTINUITY_VERIFIED',{'schema_version':'v2.02.95','bound_audit_hash':b['hash'],'evidence_digest':'digest-1'}); c=a.entries[-1]
 a.append('MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED',{'schema_version':'v2.02.99','bound_audit_hash':b['hash'],'evidence_digest':'digest-1','continuity_hash':c['hash']}); return a.entries[-1]['hash'],b['hash']
def _digest(p):
 a=AuditLog(str(p)); return hashlib.sha256(json.dumps({'entries':a.entries,'prev_hash':a.prev_hash},sort_keys=True,separators=(',',':')).encode()).hexdigest()
def test_stability(tmp_path):
 p=tmp_path/'a.json'; ah,bh=_build(p); d=_digest(p); r=DurableVerificationSnapshotCanonicalStability().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_snapshot_digest=d); assert r.valid and r.snapshot_digest==d and r.predecessor=='v2.02.103'
def test_wrong_snapshot(tmp_path):
 p=tmp_path/'a.json'; ah,bh=_build(p)
 with pytest.raises(ValueError,match='SNAPSHOT_DIGEST_MISMATCH'): DurableVerificationSnapshotCanonicalStability().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_snapshot_digest='wrong')
def test_wrong_anchor(tmp_path):
 p=tmp_path/'a.json'; ah,bh=_build(p); d=_digest(p)
 with pytest.raises(ValueError,match='ANCHOR_HASH_MISMATCH'): DurableVerificationSnapshotCanonicalStability().verify(str(p),expected_anchor_hash='wrong',expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_snapshot_digest=d)
def test_wrong_bound(tmp_path):
 p=tmp_path/'a.json'; ah,bh=_build(p); d=_digest(p)
 with pytest.raises(ValueError,match='BOUND_AUDIT_HASH_MISMATCH'): DurableVerificationSnapshotCanonicalStability().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash='wrong',expected_evidence_digest='digest-1',expected_snapshot_digest=d)
def test_wrong_evidence(tmp_path):
 p=tmp_path/'a.json'; ah,bh=_build(p); d=_digest(p)
 with pytest.raises(ValueError,match='EVIDENCE_DIGEST_MISMATCH'): DurableVerificationSnapshotCanonicalStability().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest='wrong',expected_snapshot_digest=d)
def test_tamper(tmp_path):
 p=tmp_path/'a.json'; ah,bh=_build(p); d=_digest(p); x=json.loads(p.read_text()); x['entries'][-1]['data']['evidence_digest']='tampered'; p.write_text(json.dumps(x,sort_keys=True))
 with pytest.raises(ValueError,match='audit ledger integrity failure'): DurableVerificationSnapshotCanonicalStability().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_snapshot_digest=d)
