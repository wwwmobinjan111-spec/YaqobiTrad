import hashlib,json,pytest
from yaqobitrad.audit import AuditLog
from yaqobitrad.v202118_durable_verification_snapshot_replay_certificate_lineage_continuity import DurableVerificationSnapshotReplayCertificateLineageContinuityV118 as V

def _build(path):
 a=AuditLog(str(path)); a.append("MONITORING_EVIDENCE_RETRIEVAL_VERIFIED",{"schema_version":"v2.02.94","evidence_digest":"digest-1"}); b=a.entries[-1]
 a.append("MONITORING_EVIDENCE_RETRIEVAL_AUDIT_CONTINUITY_VERIFIED",{"schema_version":"v2.02.95","bound_audit_hash":b["hash"],"evidence_digest":"digest-1"}); c=a.entries[-1]
 a.append("MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED",{"schema_version":"v2.02.99","bound_audit_hash":b["hash"],"evidence_digest":"digest-1","continuity_hash":c["hash"]}); return a.entries[-1]["hash"],b["hash"]
def _digest(p):
 a=AuditLog(str(p)); return hashlib.sha256(json.dumps({"entries":a.entries,"prev_hash":a.prev_hash},sort_keys=True,separators=(",",":")).encode()).hexdigest()
def _args(p):
 ah,bh=_build(p); d=_digest(p); pred="v117-certificate-digest"; ld=V.lineage_digest(predecessor_certificate_digest=pred,snapshot_digest=d); return ah,bh,d,pred,ld
def _run(p):
 ah,bh,d,pred,ld=_args(p); return V().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d,expected_predecessor_certificate_digest=pred,expected_lineage_digest=ld)

def test_v118_valid_lineage(tmp_path):
 r=_run(tmp_path/"a.json"); assert r.valid and r.checkpoint=="v2.02.118" and r.predecessor=="v2.02.117"
def test_v118_lineage_digest_stable(tmp_path):
 r=_run(tmp_path/"a.json"); assert r.lineage_digest

def test_v118_wrong_lineage_rejected(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d,pred,ld=_args(p)
 with pytest.raises(ValueError,match="LINEAGE_DIGEST_MISMATCH"): V().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d,expected_predecessor_certificate_digest=pred,expected_lineage_digest="wrong")
def test_v118_missing_predecessor_certificate_rejected(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d,pred,ld=_args(p)
 with pytest.raises(ValueError,match="PREDECESSOR_CERTIFICATE_MISSING"): V().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d,expected_predecessor_certificate_digest="",expected_lineage_digest=ld)
def test_v118_safety_preserved(tmp_path):
 r=_run(tmp_path/"a.json"); assert (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")
def test_v118_blockers_and_certification_preserved(tmp_path):
 r=_run(tmp_path/"a.json"); assert r.open_blocker_count==6 and r.certification=="PENDING_REAL_PRODUCTION_RESULTS"
