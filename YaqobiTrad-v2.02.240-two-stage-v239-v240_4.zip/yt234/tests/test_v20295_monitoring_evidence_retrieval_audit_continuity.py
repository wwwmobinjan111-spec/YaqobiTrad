"""v2.02.95 — monitoring evidence retrieval audit continuity tests."""
import json
import pytest

from yaqobitrad.audit import AuditLog
from yaqobitrad.evidence_retention import RetentionPolicy
from yaqobitrad.monitoring import MonitoringState
from yaqobitrad.monitoring_evidence_boundary import MonitoringEvidenceBoundary
from yaqobitrad.monitoring_evidence_retrieval_boundary import MonitoringEvidenceRetrievalBoundary
from yaqobitrad.monitoring_evidence_retrieval_audit_binding import MonitoringEvidenceRetrievalAuditBinding
from yaqobitrad.monitoring_evidence_retrieval_audit_continuity import MonitoringEvidenceRetrievalAuditContinuity
from yaqobitrad.production_blockers import open_production_blockers


def setup(tmp_path):
    state = MonitoringState()
    state.heartbeat(100.0)
    retrieval = MonitoringEvidenceRetrievalBoundary(MonitoringEvidenceBoundary(state))
    policy = RetentionPolicy(minimum_days=90, immutable=True, remote=True, verified=True)
    evidence = {"timestamp": 100.0, "healthy": True, "heartbeat": 100.0}
    evidence_path = tmp_path / "monitoring-evidence.json"
    evidence_path.write_text(json.dumps(retrieval.envelope(evidence, policy), sort_keys=True, separators=(",", ":")))
    binding = MonitoringEvidenceRetrievalAuditBinding(retrieval, AuditLog())
    return MonitoringEvidenceRetrievalAuditContinuity(binding), evidence_path


def test_v20295_durable_continuity_is_verified(tmp_path):
    gate, evidence_path = setup(tmp_path)
    audit_path = tmp_path / "audit.json"
    result = gate.bind_and_verify(str(evidence_path), str(audit_path), now=110.0, max_age=30.0)
    assert result.valid
    assert result.persisted
    assert result.reason == "MONITORING_EVIDENCE_RETRIEVAL_AUDIT_CONTINUITY_VERIFIED"
    assert AuditLog(str(audit_path)).verify()


def test_v20295_bound_hash_and_digest_survive_reload(tmp_path):
    gate, evidence_path = setup(tmp_path)
    audit_path = tmp_path / "audit.json"
    result = gate.bind_and_verify(str(evidence_path), str(audit_path), now=110.0, max_age=30.0)
    restored = AuditLog(str(audit_path))
    bound = restored.entries[-2]
    continuity = restored.entries[-1]
    assert bound["hash"] == result.audit_hash
    assert continuity["data"]["bound_audit_hash"] == result.audit_hash
    assert continuity["data"]["evidence_digest"] == result.evidence_digest


def test_v20295_corrupt_persisted_chain_fails_closed(tmp_path):
    gate, evidence_path = setup(tmp_path)
    audit_path = tmp_path / "audit.json"
    gate.bind_and_verify(str(evidence_path), str(audit_path), now=110.0, max_age=30.0)
    payload = json.loads(audit_path.read_text())
    payload["entries"][0]["event"] = "CORRUPTED"
    audit_path.write_text(json.dumps(payload, sort_keys=True, separators=(",", ":")))
    with pytest.raises(ValueError, match="audit ledger integrity failure"):
        AuditLog(str(audit_path))


def test_v20295_stale_evidence_does_not_create_audit_file(tmp_path):
    gate, evidence_path = setup(tmp_path)
    audit_path = tmp_path / "audit.json"
    with pytest.raises(ValueError, match="MONITORING_HEARTBEAT_STALE"):
        gate.bind_and_verify(str(evidence_path), str(audit_path), now=140.0, max_age=30.0)
    assert not audit_path.exists()


def test_v20295_evidence_remains_read_only(tmp_path):
    gate, evidence_path = setup(tmp_path)
    audit_path = tmp_path / "audit.json"
    before = evidence_path.read_bytes()
    gate.bind_and_verify(str(evidence_path), str(audit_path), now=110.0, max_age=30.0)
    assert evidence_path.read_bytes() == before


def test_v20295_blockers_and_safety_state_remain_open_and_fail_closed(tmp_path):
    gate, evidence_path = setup(tmp_path)
    audit_path = tmp_path / "audit.json"
    before = tuple(b.blocker_id for b in open_production_blockers())
    result = gate.bind_and_verify(str(evidence_path), str(audit_path), now=110.0, max_age=30.0)
    after = tuple(b.blocker_id for b in open_production_blockers())
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"
    assert before == after
    assert len(after) == 6
