from yaqobitrad.audit import AuditLog
from yaqobitrad.checkpoint_evidence_seal import CheckpointEvidenceSealer
from yaqobitrad.evidence_release_gate import EvidenceReleaseGate
from yaqobitrad.evidence_release_reconciliation_gate import EvidenceReleaseReconciliationGate
from yaqobitrad.evidence_release_finalization_gate import EvidenceReleaseFinalizationGate
from yaqobitrad.evidence_release_commitment_gate import EvidenceReleaseCommitmentGate
from yaqobitrad.evidence_release_publication_gate import EvidenceReleasePublicationGate
from yaqobitrad.evidence_retention import RetentionPolicy
from yaqobitrad.evidence_retention_gate import EvidenceRetentionGate
from yaqobitrad.global_checkpoint import global_checkpoint


def setup():
    audit = AuditLog()
    retention = EvidenceRetentionGate(audit)
    assert retention.verify(RetentionPolicy(90, True, True, True)).valid
    sealer = CheckpointEvidenceSealer(audit)
    checkpoint = global_checkpoint()
    sealer.seal(checkpoint)
    release = EvidenceReleaseGate(audit, retention, sealer)
    assert release.authorize(checkpoint).allowed
    reconciliation = EvidenceReleaseReconciliationGate(audit, retention, release)
    finalization = EvidenceReleaseFinalizationGate(audit, reconciliation)
    commitment = EvidenceReleaseCommitmentGate(audit, finalization)
    return audit, commitment, checkpoint


def test_publication_succeeds():
    audit, commitment, checkpoint = setup()
    gate = EvidenceReleasePublicationGate(audit, commitment)
    result = gate.publish(checkpoint)
    assert result.published
    assert result.reason == "EVIDENCE_RELEASE_PUBLISHED"
    assert gate.published
    assert audit.verify()


def test_invalid_audit_blocks_publication():
    audit, commitment, checkpoint = setup()
    audit.entries[0]["data"]["minimum_days"] = 1
    gate = EvidenceReleasePublicationGate(audit, commitment)
    result = gate.publish(checkpoint)
    assert not result.published
    assert result.reason == "AUDIT_CHAIN_INVALID"
    assert not gate.published


def test_publication_is_idempotent():
    audit, commitment, checkpoint = setup()
    gate = EvidenceReleasePublicationGate(audit, commitment)
    first = gate.publish(checkpoint)
    count = len(audit.entries)
    second = gate.publish(checkpoint)
    assert first.published and second.published
    assert len(audit.entries) == count
