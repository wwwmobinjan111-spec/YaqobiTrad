from yaqobitrad.audit import AuditLog
from yaqobitrad.checkpoint_evidence_seal import CheckpointEvidenceSealer
from yaqobitrad.evidence_release_gate import EvidenceReleaseGate
from yaqobitrad.evidence_release_reconciliation_gate import EvidenceReleaseReconciliationGate
from yaqobitrad.evidence_release_finalization_gate import EvidenceReleaseFinalizationGate
from yaqobitrad.evidence_release_commitment_gate import EvidenceReleaseCommitmentGate
from yaqobitrad.evidence_release_publication_gate import EvidenceReleasePublicationGate
from yaqobitrad.evidence_release_distribution_gate import EvidenceReleaseDistributionGate
from yaqobitrad.evidence_release_verification_gate import EvidenceReleaseVerificationGate
from yaqobitrad.evidence_retention import RetentionPolicy
from yaqobitrad.evidence_retention_gate import EvidenceRetentionGate
from yaqobitrad.global_checkpoint import global_checkpoint

def setup():
    audit = AuditLog()
    retention = EvidenceRetentionGate(audit)
    assert retention.verify(RetentionPolicy(90, True, True, True)).valid
    sealer = CheckpointEvidenceSealer(audit)
    checkpoint = global_checkpoint()
    sealer.seal(checkpoint)
    release = EvidenceReleaseGate(audit, retention, sealer)
    assert release.authorize(checkpoint).allowed
    reconciliation = EvidenceReleaseReconciliationGate(audit, retention, release)
    finalization = EvidenceReleaseFinalizationGate(audit, reconciliation)
    commitment = EvidenceReleaseCommitmentGate(audit, finalization)
    publication = EvidenceReleasePublicationGate(audit, commitment)
    distribution = EvidenceReleaseDistributionGate(audit, publication)
    return audit, distribution, checkpoint

def test_verification_succeeds():
    audit, distribution, checkpoint = setup()
    gate = EvidenceReleaseVerificationGate(audit, distribution)
    result = gate.verify_release(checkpoint)
    assert result.verified
    assert result.reason == "EVIDENCE_RELEASE_VERIFIED"
    assert gate.verified
    assert audit.verify()

def test_invalid_audit_blocks_verification():
    audit, distribution, checkpoint = setup()
    audit.entries[0]["data"]["minimum_days"] = 1
    gate = EvidenceReleaseVerificationGate(audit, distribution)
    result = gate.verify_release(checkpoint)
    assert not result.verified
    assert result.reason == "AUDIT_CHAIN_INVALID"
    assert not gate.verified

def test_verification_is_idempotent():
    audit, distribution, checkpoint = setup()
    gate = EvidenceReleaseVerificationGate(audit, distribution)
    first = gate.verify_release(checkpoint)
    count = len(audit.entries)
    second = gate.verify_release(checkpoint)
    assert first.verified and second.verified
    assert len(audit.entries) == count
