import json

import pytest

from yaqobitrad.audit import AuditLog
from yaqobitrad.monitoring_evidence_audit_continuity_anchor_recovery import MonitoringEvidenceAuditContinuityAnchorRecovery


def _build(path):
    audit = AuditLog(str(path))
    audit.append("MONITORING_EVIDENCE_RETRIEVAL_VERIFIED", {"schema_version": "v2.02.94", "evidence_digest": "digest-1"})
    bind = audit.entries[-1]
    audit.append("MONITORING_EVIDENCE_RETRIEVAL_AUDIT_CONTINUITY_VERIFIED", {"schema_version": "v2.02.95", "bound_audit_hash": bind["hash"], "evidence_digest": "digest-1"})
    continuity = audit.entries[-1]
    audit.append("MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED", {"schema_version": "v2.02.96", "bound_audit_hash": bind["hash"], "evidence_digest": "digest-1", "continuity_hash": continuity["hash"]})
    return audit.entries[-1]["hash"], bind["hash"]


def test_recovery_verifies_two_reloads_and_preserves_chain(tmp_path):
    path = tmp_path / "audit.json"
    anchor_hash, bound_hash = _build(path)
    before = json.loads(path.read_text())
    result = MonitoringEvidenceAuditContinuityAnchorRecovery().verify_recovery(
        str(path), expected_bound_audit_hash=bound_hash, expected_evidence_digest="digest-1", expected_anchor_hash=anchor_hash
    )
    assert result.valid is True
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"
    assert json.loads(path.read_text()) == before


def test_wrong_anchor_hash_fails_closed(tmp_path):
    path = tmp_path / "audit.json"
    anchor_hash, bound_hash = _build(path)
    with pytest.raises(ValueError, match="ANCHOR_HASH_MISMATCH"):
        MonitoringEvidenceAuditContinuityAnchorRecovery().verify_recovery(
            str(path), expected_bound_audit_hash=bound_hash, expected_evidence_digest="digest-1", expected_anchor_hash="wrong"
        )


def test_wrong_digest_fails_closed(tmp_path):
    path = tmp_path / "audit.json"
    anchor_hash, bound_hash = _build(path)
    with pytest.raises(ValueError, match="DIGEST_MISMATCH"):
        MonitoringEvidenceAuditContinuityAnchorRecovery().verify_recovery(
            str(path), expected_bound_audit_hash=bound_hash, expected_evidence_digest="wrong", expected_anchor_hash=anchor_hash
        )


def test_duplicate_anchor_fails_closed(tmp_path):
    path = tmp_path / "audit.json"
    anchor_hash, bound_hash = _build(path)
    audit = AuditLog(str(path))
    audit.append("MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED", {"schema_version": "v2.02.96", "bound_audit_hash": bound_hash, "evidence_digest": "digest-1", "continuity_hash": anchor_hash})
    with pytest.raises(ValueError, match="CARDINALITY_INVALID"):
        MonitoringEvidenceAuditContinuityAnchorRecovery().verify_recovery(
            str(path), expected_bound_audit_hash=bound_hash, expected_evidence_digest="digest-1", expected_anchor_hash=anchor_hash
        )


def test_tampered_persistence_fails_closed(tmp_path):
    path = tmp_path / "audit.json"
    anchor_hash, bound_hash = _build(path)
    payload = json.loads(path.read_text())
    payload["entries"][-1]["data"]["evidence_digest"] = "tampered"
    path.write_text(json.dumps(payload, sort_keys=True))
    with pytest.raises(ValueError, match="audit ledger integrity failure"):
        MonitoringEvidenceAuditContinuityAnchorRecovery().verify_recovery(
            str(path), expected_bound_audit_hash=bound_hash, expected_evidence_digest="digest-1", expected_anchor_hash=anchor_hash
        )


def test_empty_history_fails_closed(tmp_path):
    path = tmp_path / "audit.json"
    AuditLog(str(path))
    with pytest.raises(ValueError, match="CARDINALITY_INVALID"):
        MonitoringEvidenceAuditContinuityAnchorRecovery().verify_recovery(
            str(path), expected_bound_audit_hash="x", expected_evidence_digest="digest-1", expected_anchor_hash="y"
        )
