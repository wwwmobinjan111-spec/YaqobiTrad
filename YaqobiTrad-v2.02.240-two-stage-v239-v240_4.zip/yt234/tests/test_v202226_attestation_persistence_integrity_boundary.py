from types import SimpleNamespace
import pytest
from yaqobitrad.v202226_attestation_persistence_integrity_boundary import AttestationPersistenceIntegrityBoundaryV226 as V

def checkpoint():
    return SimpleNamespace(valid=True,checkpoint="v2.02.225",predecessor="v2.02.224",checkpoint_digest="a"*64,integrity_digest="b"*64,recovery_digest="c"*64,live_trading="SAFE_OFF",activation_gate="LOCKED",fail_closed="ACTIVE")

def test_v202226_persistence_integrity_verifies_chain_and_safety():
    r=V.verify(checkpoint()); assert r.valid and r.checkpoint=="v2.02.226" and r.predecessor=="v2.02.225" and r.open_blocker_count==6 and len(r.persistence_integrity_digest)==64 and len(r.checkpoint_digest)==64 and (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")

def test_v202226_digest_deterministic():
    a=V.verify(checkpoint()); b=V.verify(checkpoint()); assert a.persistence_integrity_digest==b.persistence_integrity_digest and a.checkpoint_digest==b.checkpoint_digest

def test_v202226_rejects_predecessor_digest_mismatch():
    with pytest.raises(ValueError,match="V202226_PREDECESSOR_DIGEST_MISMATCH"): V.verify(checkpoint(),expected_predecessor_digest="d"*64)

def test_v202226_rejects_lineage_mismatch():
    x=checkpoint(); x.predecessor="v2.02.220"
    with pytest.raises(ValueError,match="V202226_LINEAGE_INVALID"): V.verify(x)

def test_v202226_rejects_unsafe_state():
    x=checkpoint(); x.activation_gate="OPEN"
    with pytest.raises(ValueError,match="V202226_SAFETY_STATE_INVALID"): V.verify(x)
