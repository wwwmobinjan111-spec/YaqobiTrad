from types import SimpleNamespace
import pytest

from yaqobitrad.v202189_provider_failover_evidence_attestation_durability_continuity import (
    ProviderFailoverEvidenceAttestationDurabilityContinuityV189,
)


def durability():
    return SimpleNamespace(
        valid=True,
        checkpoint="v2.02.188",
        predecessor="v2.02.187",
        continuity_digest="b" * 64,
        durability_digest="c" * 64,
        live_trading="SAFE_OFF",
        activation_gate="LOCKED",
        fail_closed="ACTIVE",
    )


def test_v202189_carries_durability_and_preserves_safety():
    r = ProviderFailoverEvidenceAttestationDurabilityContinuityV189.carry_forward(
        durability(), expected_durability_digest="c" * 64
    )
    assert r.valid and r.checkpoint == "v2.02.189" and r.predecessor == "v2.02.188"
    assert r.durability_digest == "c" * 64 and len(r.continuity_digest) == 64
    assert (r.live_trading, r.activation_gate, r.fail_closed) == ("SAFE_OFF", "LOCKED", "ACTIVE")


def test_v202189_continuity_digest_is_deterministic():
    a = ProviderFailoverEvidenceAttestationDurabilityContinuityV189.carry_forward(durability())
    b = ProviderFailoverEvidenceAttestationDurabilityContinuityV189.carry_forward(durability())
    assert a.continuity_digest == b.continuity_digest


def test_v202189_rejects_digest_mismatch():
    with pytest.raises(ValueError, match="V202189_DURABILITY_DIGEST_MISMATCH"):
        ProviderFailoverEvidenceAttestationDurabilityContinuityV189.carry_forward(
            durability(), expected_durability_digest="d" * 64
        )


def test_v202189_rejects_lineage_mismatch():
    x = durability()
    x.predecessor = "v2.02.186"
    with pytest.raises(ValueError, match="V202189_DURABILITY_LINEAGE_INVALID"):
        ProviderFailoverEvidenceAttestationDurabilityContinuityV189.carry_forward(x)


def test_v202189_rejects_unsafe_state():
    x = durability()
    x.activation_gate = "UNLOCKED"
    with pytest.raises(ValueError, match="V202189_SAFETY_STATE_INVALID"):
        ProviderFailoverEvidenceAttestationDurabilityContinuityV189.carry_forward(x)
