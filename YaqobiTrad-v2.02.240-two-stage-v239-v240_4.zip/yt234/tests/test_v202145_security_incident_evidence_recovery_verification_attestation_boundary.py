from types import SimpleNamespace

from yaqobitrad.v202145_security_incident_evidence_recovery_verification_attestation_boundary import (
    SecurityIncidentEvidenceRecoveryVerificationAttestationBoundaryV145,
)

STATE = SimpleNamespace(activation_gate="LOCKED", live_trading="SAFE_OFF", fail_closed="ACTIVE")


def test_v145_attestation_preserves_recovery_verification_safe_state():
    r = SecurityIncidentEvidenceRecoveryVerificationAttestationBoundaryV145.verify(
        STATE,
        recovery_ref="evidence://security-incident/recovery/2026-09",
        verification_ref="evidence://security-incident/recovery-verification/2026-09",
        attestation_ref="evidence://security-incident/recovery-verification-attestation/2026-09",
    )
    assert r.valid and r.open_blocker_count == 6
    assert r.live_trading == "SAFE_OFF" and r.activation_gate == "LOCKED"
    assert r.fail_closed == "ACTIVE"
    assert r.predecessor == "v2.02.144"


def test_v145_rejects_plaintext_attestation_material():
    for kwargs in (
        {"recovery_ref": "evidence://security-incident/recovery/2026-09", "verification_ref": "evidence://security-incident/recovery-verification/2026-09", "attestation_ref": "TOKEN=plaintext"},
        {"recovery_ref": "SECRET=plaintext", "verification_ref": "evidence://security-incident/recovery-verification/2026-09", "attestation_ref": "evidence://security-incident/recovery-verification-attestation/2026-09"},
    ):
        try:
            SecurityIncidentEvidenceRecoveryVerificationAttestationBoundaryV145.verify(STATE, **kwargs)
        except ValueError:
            pass
        else:
            raise AssertionError
