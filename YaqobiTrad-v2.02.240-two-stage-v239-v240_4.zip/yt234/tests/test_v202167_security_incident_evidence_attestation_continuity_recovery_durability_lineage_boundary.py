from yaqobitrad.v202167_security_incident_evidence_attestation_continuity_recovery_durability_lineage_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityLineageBoundaryV167

class SafeState:
    activation_gate="LOCKED"
    live_trading="SAFE_OFF"
    fail_closed="ACTIVE"

def test_v202167_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityLineageBoundaryV167.verify(
        SafeState(), state_ref="evidence://state/v166", continuity_ref="evidence://continuity/v166",
        recovery_ref="evidence://recovery/v166", lineage_ref="evidence://lineage/v166")
    assert r.valid and r.checkpoint=="v2.02.167" and r.predecessor=="v2.02.166" and r.open_blocker_count==6

def test_v202167_rejects_reuse():
    try:
        SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityLineageBoundaryV167.verify(
            SafeState(), state_ref="evidence://same", continuity_ref="evidence://same",
            recovery_ref="evidence://recovery", lineage_ref="evidence://lineage")
    except ValueError as e:
        assert str(e)=="V202167_REFERENCE_REUSE_INVALID"
    else:
        raise AssertionError("reference reuse was not rejected")
