from dataclasses import dataclass
import pytest
from yaqobitrad.v202157_security_incident_evidence_attestation_continuity_recovery_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryBoundaryV157

@dataclass
class SafeState:
    activation_gate: str = "LOCKED"
    live_trading: str = "SAFE_OFF"
    fail_closed: str = "ACTIVE"

def test_v202157_accepts_three_distinct_refs():
    r = SecurityIncidentEvidenceAttestationContinuityRecoveryBoundaryV157.verify(SafeState(), state_ref="evidence://state/v156", continuity_ref="evidence://continuity/v156", recovery_ref="evidence://recovery/v156")
    assert r.valid is True
    assert r.checkpoint == "v2.02.157" and r.predecessor == "v2.02.156"
    assert r.open_blocker_count == 6

def test_v202157_rejects_reused_refs():
    with pytest.raises(ValueError, match="REFERENCE_REUSE_INVALID"):
        SecurityIncidentEvidenceAttestationContinuityRecoveryBoundaryV157.verify(SafeState(), state_ref="evidence://same", continuity_ref="evidence://same", recovery_ref="evidence://recovery")
