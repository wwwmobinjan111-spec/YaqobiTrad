from types import SimpleNamespace
from yaqobitrad.v202152_security_incident_evidence_attestation_state_boundary import SecurityIncidentEvidenceAttestationStateBoundaryV152

STATE = SimpleNamespace(activation_gate="LOCKED", live_trading="SAFE_OFF", fail_closed="ACTIVE")

def test_v152_state_boundary_preserves_safe_state_and_blockers():
    r = SecurityIncidentEvidenceAttestationStateBoundaryV152.verify(
        STATE,
        continuity_ref="evidence://security-incident/attestation-continuity/2026-09",
        state_ref="evidence://security-incident/attestation-state/2026-09",
    )
    assert r.valid and r.open_blocker_count == 6
    assert r.predecessor == "v2.02.151"
    assert (r.live_trading, r.activation_gate, r.fail_closed) == ("SAFE_OFF", "LOCKED", "ACTIVE")

def test_v152_rejects_secret_or_assignment_material():
    for value in ("PASSWORD=plaintext", "evidence://security-incident/SECRET/value"):
        try:
            SecurityIncidentEvidenceAttestationStateBoundaryV152.verify(
                STATE,
                continuity_ref=value,
                state_ref="evidence://security-incident/attestation-state/2026-09",
            )
        except ValueError:
            pass
        else:
            raise AssertionError
