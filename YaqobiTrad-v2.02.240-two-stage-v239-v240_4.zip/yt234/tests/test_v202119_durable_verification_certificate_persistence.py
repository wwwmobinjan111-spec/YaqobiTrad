import hashlib,json,pytest
from yaqobitrad.audit import AuditLog
from yaqobitrad.v202119_durable_verification_certificate_persistence import DurableVerificationCertificatePersistenceV119 as V

def _build(path):
 a=AuditLog(str(path)); a.append("MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED",{"schema_version":"v2.02.99","bound_audit_hash":"b","evidence_digest":"e","continuity_hash":"c"}); return a

def _snapshot_digest(p):
 a=AuditLog(str(p)); return hashlib.sha256(json.dumps({"entries":a.entries,"prev_hash":a.prev_hash},sort_keys=True,separators=(",",":")).encode()).hexdigest()
def _args(p):
 _build(p); sd=_snapshot_digest(p); ld="v118-lineage-digest"; cd=V.certificate_digest(snapshot_digest=sd,lineage_digest=ld); return sd,ld,cd
def _run(p):
 sd,ld,cd=_args(p); return V().verify(str(p),expected_snapshot_digest=sd,expected_lineage_digest=ld,expected_certificate_digest=cd)

def test_v119_valid_persistence(tmp_path):
 r=_run(tmp_path/"a.json"); assert r.valid and r.checkpoint=="v2.02.119" and r.predecessor=="v2.02.118"
def test_v119_certificate_digest_stable(tmp_path):
 r=_run(tmp_path/"a.json"); assert r.certificate_digest and r.persistence_digest==r.persistence_digest
def test_v119_wrong_certificate_rejected(tmp_path):
 p=tmp_path/"a.json"; sd,ld,cd=_args(p)
 with pytest.raises(ValueError,match="CERTIFICATE_DIGEST_MISMATCH"): V().verify(str(p),expected_snapshot_digest=sd,expected_lineage_digest=ld,expected_certificate_digest="wrong")
def test_v119_missing_lineage_rejected(tmp_path):
 p=tmp_path/"a.json"; sd,ld,cd=_args(p)
 with pytest.raises(ValueError,match="LINEAGE_DIGEST_MISSING"): V().verify(str(p),expected_snapshot_digest=sd,expected_lineage_digest="",expected_certificate_digest=cd)
def test_v119_safety_preserved(tmp_path):
 r=_run(tmp_path/"a.json"); assert (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")
def test_v119_blockers_and_certification_preserved(tmp_path):
 r=_run(tmp_path/"a.json"); assert r.open_blocker_count==6 and r.certification=="PENDING_REAL_PRODUCTION_RESULTS"
