from yaqobitrad.v202177_security_incident_evidence_attestation_continuity_recovery_durability_lineage_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityLineageBoundaryV177

class SafeState:
    activation_gate="LOCKED"
    live_trading="SAFE_OFF"
    fail_closed="ACTIVE"

def test_v202177_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityLineageBoundaryV177.verify(SafeState(), state_ref="evidence://state/v176", continuity_ref="evidence://continuity/v176", recovery_ref="evidence://recovery/v176", lineage_ref="evidence://lineage/v176", attestation_ref="evidence://attestation/v176")
    assert r.valid and r.checkpoint=="v2.02.177" and r.predecessor=="v2.02.176" and r.open_blocker_count==6

def test_v202177_rejects_reuse():
    try:
        SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityLineageBoundaryV177.verify(SafeState(), state_ref="evidence://same", continuity_ref="evidence://continuity", recovery_ref="evidence://recovery", lineage_ref="evidence://lineage", attestation_ref="evidence://same")
    except ValueError as e:
        assert str(e)=="V202177_REFERENCE_REUSE_INVALID"
    else:
        raise AssertionError("reference reuse was not rejected")
