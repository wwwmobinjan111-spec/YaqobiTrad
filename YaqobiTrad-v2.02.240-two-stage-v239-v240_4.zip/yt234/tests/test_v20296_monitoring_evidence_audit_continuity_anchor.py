"""v2.02.96 — monitoring evidence audit continuity anchor tests."""
import json
import pytest

from yaqobitrad.audit import AuditLog
from yaqobitrad.evidence_retention import RetentionPolicy
from yaqobitrad.monitoring import MonitoringState
from yaqobitrad.monitoring_evidence_boundary import MonitoringEvidenceBoundary
from yaqobitrad.monitoring_evidence_retrieval_boundary import MonitoringEvidenceRetrievalBoundary
from yaqobitrad.monitoring_evidence_retrieval_audit_binding import MonitoringEvidenceRetrievalAuditBinding
from yaqobitrad.monitoring_evidence_retrieval_audit_continuity import MonitoringEvidenceRetrievalAuditContinuity
from yaqobitrad.monitoring_evidence_audit_continuity_anchor import MonitoringEvidenceAuditContinuityAnchor


def setup(tmp_path):
    state = MonitoringState()
    state.heartbeat(100.0)
    retrieval = MonitoringEvidenceRetrievalBoundary(MonitoringEvidenceBoundary(state))
    policy = RetentionPolicy(minimum_days=90, immutable=True, remote=True, verified=True)
    evidence = {"timestamp": 100.0, "healthy": True, "heartbeat": 100.0}
    evidence_path = tmp_path / "monitoring-evidence.json"
    evidence_path.write_text(json.dumps(retrieval.envelope(evidence, policy), sort_keys=True, separators=(",", ":")))
    binding = MonitoringEvidenceRetrievalAuditBinding(retrieval, AuditLog())
    continuity = MonitoringEvidenceRetrievalAuditContinuity(binding)
    audit_path = tmp_path / "audit.json"
    result = continuity.bind_and_verify(str(evidence_path), str(audit_path), now=110.0, max_age=30.0)
    return MonitoringEvidenceAuditContinuityAnchor(), audit_path, result


def test_v20296_anchor_is_verified_and_persisted(tmp_path):
    anchor, audit_path, continuity = setup(tmp_path)
    result = anchor.anchor(str(audit_path), expected_bound_audit_hash=continuity.audit_hash, expected_evidence_digest=continuity.evidence_digest)
    assert result.valid
    assert result.reason == "MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED"
    assert AuditLog(str(audit_path)).verify()


def test_v20296_anchor_binds_exact_hash_and_digest(tmp_path):
    anchor, audit_path, continuity = setup(tmp_path)
    result = anchor.anchor(str(audit_path), expected_bound_audit_hash=continuity.audit_hash, expected_evidence_digest=continuity.evidence_digest)
    restored = AuditLog(str(audit_path))
    last = restored.entries[-1]
    assert last["hash"] == result.anchor_hash
    assert last["data"]["bound_audit_hash"] == continuity.audit_hash
    assert last["data"]["evidence_digest"] == continuity.evidence_digest


def test_v20296_duplicate_anchor_fails_closed(tmp_path):
    anchor, audit_path, continuity = setup(tmp_path)
    anchor.anchor(str(audit_path), expected_bound_audit_hash=continuity.audit_hash, expected_evidence_digest=continuity.evidence_digest)
    with pytest.raises(ValueError, match="MONITORING_EVIDENCE_AUDIT_ANCHOR_DUPLICATE"):
        anchor.anchor(str(audit_path), expected_bound_audit_hash=continuity.audit_hash, expected_evidence_digest=continuity.evidence_digest)


def test_v20296_tampered_continuity_reference_fails_closed(tmp_path):
    anchor, audit_path, continuity = setup(tmp_path)
    payload = json.loads(audit_path.read_text())
    payload["entries"][-1]["data"]["evidence_digest"] = "tampered"
    audit_path.write_text(json.dumps(payload, sort_keys=True, separators=(",", ":")))
    with pytest.raises(ValueError, match="audit ledger integrity failure"):
        anchor.anchor(str(audit_path), expected_bound_audit_hash=continuity.audit_hash, expected_evidence_digest=continuity.evidence_digest)


def test_v20296_wrong_expected_hash_fails_closed(tmp_path):
    anchor, audit_path, continuity = setup(tmp_path)
    with pytest.raises(ValueError, match="MONITORING_EVIDENCE_AUDIT_ANCHOR_BOUND_HASH_MISMATCH"):
        anchor.anchor(str(audit_path), expected_bound_audit_hash="0" * 64, expected_evidence_digest=continuity.evidence_digest)


def test_v20296_safety_state_is_preserved(tmp_path):
    anchor, audit_path, continuity = setup(tmp_path)
    result = anchor.anchor(str(audit_path), expected_bound_audit_hash=continuity.audit_hash, expected_evidence_digest=continuity.evidence_digest)
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"
