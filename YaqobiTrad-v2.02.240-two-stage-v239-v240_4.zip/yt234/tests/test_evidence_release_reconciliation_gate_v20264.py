from yaqobitrad.audit import AuditLog
from yaqobitrad.checkpoint_evidence_seal import CheckpointEvidenceSealer
from yaqobitrad.evidence_release_gate import EvidenceReleaseGate
from yaqobitrad.evidence_release_reconciliation_gate import EvidenceReleaseReconciliationGate
from yaqobitrad.evidence_retention import RetentionPolicy
from yaqobitrad.evidence_retention_gate import EvidenceRetentionGate
from yaqobitrad.global_checkpoint import global_checkpoint


def good_policy():
    return RetentionPolicy(90, True, True, True)


def setup():
    audit = AuditLog()
    retention = EvidenceRetentionGate(audit)
    assert retention.verify(good_policy()).valid
    sealer = CheckpointEvidenceSealer(audit)
    checkpoint = global_checkpoint()
    sealer.seal(checkpoint)
    release = EvidenceReleaseGate(audit, retention, sealer)
    assert release.authorize(checkpoint).allowed
    return audit, retention, release, checkpoint


def test_reconciliation_succeeds():
    audit, retention, release, checkpoint = setup()
    gate = EvidenceReleaseReconciliationGate(audit, retention, release)
    result = gate.reconcile(checkpoint)
    assert result.reconciled
    assert result.reason == "EVIDENCE_RELEASE_RECONCILED"
    assert gate.reconciled
    assert audit.verify()


def test_audit_mismatch_blocks_reconciliation():
    audit, retention, release, checkpoint = setup()
    audit.entries[0]["data"]["minimum_days"] = 1
    gate = EvidenceReleaseReconciliationGate(audit, retention, release)
    result = gate.reconcile(checkpoint)
    assert not result.reconciled
    assert result.reason == "AUDIT_CHAIN_INVALID"
    assert not gate.reconciled


def test_reconciliation_is_idempotent_for_same_checkpoint():
    audit, retention, release, checkpoint = setup()
    gate = EvidenceReleaseReconciliationGate(audit, retention, release)
    first = gate.reconcile(checkpoint)
    count = len(audit.entries)
    second = gate.reconcile(checkpoint)
    assert first.reconciled and second.reconciled
    assert len(audit.entries) == count
