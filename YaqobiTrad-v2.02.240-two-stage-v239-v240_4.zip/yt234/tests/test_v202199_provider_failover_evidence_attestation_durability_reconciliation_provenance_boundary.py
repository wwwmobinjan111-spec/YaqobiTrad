from types import SimpleNamespace
import pytest
from yaqobitrad.v202199_provider_failover_evidence_attestation_durability_reconciliation_provenance_boundary import ProviderFailoverEvidenceAttestationDurabilityReconciliationProvenanceBoundaryV199

def state(): return SimpleNamespace(activation_gate="LOCKED",live_trading="SAFE_OFF",fail_closed="ACTIVE")
def refs(): return dict(reconciliation_ref="evidence://v202.02.195/reconciliation",provenance_ref="evidence://v202.02.199/provenance",recovery_ref="evidence://v202.02.198/recovery",attestation_ref="evidence://v202.02.197/attestation")
def test_v202199_provenance_boundary():
 r=ProviderFailoverEvidenceAttestationDurabilityReconciliationProvenanceBoundaryV199.verify(state(),**refs()); assert r.valid and r.checkpoint=="v2.02.199" and r.predecessor=="v2.02.198" and r.open_blocker_count==6
def test_v202199_safety_is_fail_closed():
 x=state(); x.activation_gate="OPEN"
 with pytest.raises(ValueError,match="V202199_SAFETY_STATE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationProvenanceBoundaryV199.verify(x,**refs())
def test_v202199_refs_unique():
 r=refs(); r["attestation_ref"]=r["provenance_ref"]
 with pytest.raises(ValueError,match="V202199_REFERENCE_REUSE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationProvenanceBoundaryV199.verify(state(),**r)
def test_v202199_rejects_secret():
 r=refs(); r["provenance_ref"]="evidence://v202.02.199/PRIVATE_KEY"
 with pytest.raises(ValueError,match="V202199_PROVENANCE_REF_SECRET_OR_ASSIGNMENT_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationProvenanceBoundaryV199.verify(state(),**r)
def test_v202199_rejects_assignment():
 r=refs(); r["attestation_ref"]="evidence://v202.02.199/attestation=x"
 with pytest.raises(ValueError,match="V202199_ATTESTATION_REF_SECRET_OR_ASSIGNMENT_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationProvenanceBoundaryV199.verify(state(),**r)
