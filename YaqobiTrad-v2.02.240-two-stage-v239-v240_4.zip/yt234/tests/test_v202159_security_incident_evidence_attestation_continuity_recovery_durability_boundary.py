from dataclasses import dataclass
import pytest
from yaqobitrad.v202159_security_incident_evidence_attestation_continuity_recovery_durability_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityBoundaryV159
@dataclass
class SafeState:
    activation_gate: str="LOCKED"; live_trading: str="SAFE_OFF"; fail_closed: str="ACTIVE"
def test_v202159_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityBoundaryV159.verify(SafeState(), state_ref="evidence://state/v158", continuity_ref="evidence://continuity/v158", recovery_ref="evidence://recovery/v158")
    assert r.valid and r.checkpoint=="v2.02.159" and r.predecessor=="v2.02.158" and r.open_blocker_count==6
def test_v202159_rejects_reuse():
    with pytest.raises(ValueError, match="REFERENCE_REUSE_INVALID"):
        SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityBoundaryV159.verify(SafeState(), state_ref="evidence://same", continuity_ref="evidence://same", recovery_ref="evidence://recovery")
