from types import SimpleNamespace
import pytest
from yaqobitrad.v202195_provider_failover_evidence_attestation_durability_reconciliation_boundary import ProviderFailoverEvidenceAttestationDurabilityReconciliationBoundaryV195
def state(): return SimpleNamespace(activation_gate="LOCKED",live_trading="SAFE_OFF",fail_closed="ACTIVE")
def refs(): return dict(integrity_ref="evidence://v202.02.194/integrity",reconciliation_ref="evidence://v202.02.195/reconciliation",recovery_ref="evidence://v202.02.194/recovery",attestation_ref="evidence://v202.02.195/attestation")
def test_v202195_reconciliation_boundary():
 r=ProviderFailoverEvidenceAttestationDurabilityReconciliationBoundaryV195.verify(state(),**refs()); assert r.valid and r.checkpoint=="v2.02.195" and r.predecessor=="v2.02.194" and r.open_blocker_count==6
def test_v202195_safety_is_fail_closed():
 x=state(); x.activation_gate="OPEN"
 with pytest.raises(ValueError,match="V202195_SAFETY_STATE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationBoundaryV195.verify(x,**refs())
def test_v202195_refs_unique():
 r=refs(); r["attestation_ref"]=r["integrity_ref"]
 with pytest.raises(ValueError,match="V202195_REFERENCE_REUSE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationBoundaryV195.verify(state(),**r)
def test_v202195_rejects_secret():
 r=refs(); r["recovery_ref"]="evidence://v202.02.195/PRIVATE_KEY"
 with pytest.raises(ValueError,match="V202195_RECOVERY_REF_SECRET_OR_ASSIGNMENT_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationBoundaryV195.verify(state(),**r)
def test_v202195_rejects_assignment():
 r=refs(); r["reconciliation_ref"]="evidence://v202.02.195/reconciliation=x"
 with pytest.raises(ValueError,match="V202195_RECONCILIATION_REF_SECRET_OR_ASSIGNMENT_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationBoundaryV195.verify(state(),**r)
