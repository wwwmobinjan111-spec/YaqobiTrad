import hashlib,json,pytest
from yaqobitrad.audit import AuditLog
from yaqobitrad.v202117_durable_verification_snapshot_replay_certificate_lineage import DurableVerificationSnapshotReplayCertificateLineageV117

def _build(path):
 a=AuditLog(str(path)); a.append("MONITORING_EVIDENCE_RETRIEVAL_VERIFIED",{"schema_version":"v2.02.94","evidence_digest":"digest-1"}); b=a.entries[-1]
 a.append("MONITORING_EVIDENCE_RETRIEVAL_AUDIT_CONTINUITY_VERIFIED",{"schema_version":"v2.02.95","bound_audit_hash":b["hash"],"evidence_digest":"digest-1"}); c=a.entries[-1]
 a.append("MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED",{"schema_version":"v2.02.99","bound_audit_hash":b["hash"],"evidence_digest":"digest-1","continuity_hash":c["hash"]}); return a.entries[-1]["hash"],b["hash"]
def _digest(p):
 a=AuditLog(str(p)); return hashlib.sha256(json.dumps({"entries":a.entries,"prev_hash":a.prev_hash},sort_keys=True,separators=(",",":" )).encode()).hexdigest()
def _args(p): ah,bh=_build(p); return ah,bh,_digest(p)
def test_attestation(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.valid and r.snapshot_digest==d
def test_reconstruction_stable(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.predecessor=="v2.02.116"
def test_wrong_snapshot(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p)
 with pytest.raises(ValueError,match="SNAPSHOT_DIGEST_MISMATCH"): DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest="wrong")
def test_wrong_anchor(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p)
 with pytest.raises(ValueError,match="ANCHOR_HASH_MISMATCH"): DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash="wrong",expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d)
def test_wrong_bound(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p)
 with pytest.raises(ValueError,match="BOUND_AUDIT_HASH_MISMATCH"): DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash="wrong",expected_evidence_digest="digest-1",expected_snapshot_digest=d)
def test_tamper(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); x=json.loads(p.read_text()); x["entries"][-1]["data"]["evidence_digest"]="tampered"; p.write_text(json.dumps(x,sort_keys=True))
 with pytest.raises(ValueError,match="audit ledger integrity failure"): DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d)


def test_major_checkpoint_identity(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.valid and r.checkpoint=="v2.02.117"

def test_major_checkpoint_safety_state(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")

def test_major_checkpoint_blocker_count(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.open_blocker_count==6

def test_major_checkpoint_certification_pending(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.certification=="PENDING_REAL_PRODUCTION_RESULTS"

def test_major_checkpoint_wrong_evidence_digest(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p)
 with pytest.raises(ValueError,match="EVIDENCE_DIGEST_MISMATCH"): DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="wrong",expected_snapshot_digest=d)

def test_major_checkpoint_provenance_mutation_isolated(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.snapshot_digest==d and AuditLog(str(p)).entries[-1]["data"]["evidence_digest"]=="digest-1"


def test_certificate_roundtrip_is_canonical(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.valid and r.snapshot_digest==d

def test_certificate_status_requires_valid(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.valid

def test_certificate_checkpoint_predecessor(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert (r.checkpoint,r.predecessor)==("v2.02.117","v2.02.116")

def test_certificate_safety_remains_fail_closed(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.live_trading=="SAFE_OFF" and r.activation_gate=="LOCKED" and r.fail_closed=="ACTIVE"

def test_certificate_blockers_remain_open(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.open_blocker_count==6

def test_certificate_never_certifies_production(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.certification=="PENDING_REAL_PRODUCTION_RESULTS"


def test_certificate_persists_after_reload(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.valid and _digest(p)==d

def test_certificate_replay_fourth_digest_stable(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.snapshot_digest==d

def test_certificate_durability_does_not_close_blockers(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.open_blocker_count==6

def test_certificate_durability_preserves_safe_off(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.live_trading=="SAFE_OFF"

def test_certificate_durability_preserves_locked_gate(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.activation_gate=="LOCKED"

def test_certificate_durability_preserves_fail_closed(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.fail_closed=="ACTIVE"


def test_lineage_snapshot_replay_identity(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.checkpoint=="v2.02.117" and r.predecessor=="v2.02.116"

def test_lineage_replay_digest_matches_snapshot(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.snapshot_digest==d

def test_lineage_preserves_open_blockers(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.open_blocker_count==6

def test_lineage_preserves_fail_closed_state(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")

def test_lineage_keeps_certification_pending(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.certification=="PENDING_REAL_PRODUCTION_RESULTS"

def test_lineage_reload_preserves_digest(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert _digest(p)==d


def test_v117_lineage_terminal_attestation(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.valid

def test_v117_lineage_snapshot_digest_immutable(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.snapshot_digest==d

def test_v117_lineage_production_blockers_open(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.open_blocker_count==6

def test_v117_lineage_safety_locked(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")

def test_v117_lineage_certification_pending(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.certification=="PENDING_REAL_PRODUCTION_RESULTS"

def test_v117_lineage_predecessor_is_v116(tmp_path):
 p=tmp_path/"a.json"; ah,bh,d=_args(p); r=DurableVerificationSnapshotReplayCertificateLineageV117().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest="digest-1",expected_snapshot_digest=d); assert r.predecessor=="v2.02.116"
