from types import SimpleNamespace
import pytest
from yaqobitrad.v202235_production_blocker_evidence_matrix_boundary import ProductionBlockerEvidenceMatrixBoundaryV235 as V

def cp(): return SimpleNamespace(valid=True,checkpoint='v2.02.234',predecessor='v2.02.233',live_trading='SAFE_OFF',activation_gate='LOCKED',fail_closed='ACTIVE')
def test_matrix():
 r=V.verify(cp()); assert r.valid and r.open_blocker_count==6 and r.evidence_required==V.REQUIRED
def test_safety():
 r=V.verify(cp()); assert (r.live_trading,r.activation_gate,r.fail_closed)==('SAFE_OFF','LOCKED','ACTIVE')
def test_lineage():
 x=cp(); x.checkpoint='v2.02.233'
 with pytest.raises(ValueError,match='V202235_LINEAGE_INVALID'): V.verify(x)
def test_safety_reject():
 x=cp(); x.activation_gate='UNLOCKED'
 with pytest.raises(ValueError,match='V202235_SAFETY_STATE_INVALID'): V.verify(x)
def test_six(): assert len(V.REQUIRED)==6
