from types import SimpleNamespace
import pytest
from yaqobitrad.v202185_provider_failover_evidence_continuity import ProviderFailoverEvidenceContinuityV185


def binding():
    return SimpleNamespace(valid=True, checkpoint="v2.02.184", predecessor="v2.02.183",
        evidence_ref="evidence://provider-failover/v183", evidence_digest="a"*64,
        selected_provider="secondary", attempted_providers=("primary","secondary"), failover_used=True,
        live_trading="SAFE_OFF", activation_gate="LOCKED", fail_closed="ACTIVE")

def test_v202185_replays_prior_evidence_and_preserves_safety():
    r=ProviderFailoverEvidenceContinuityV185.verify(binding(), expected_evidence_digest="a"*64)
    assert r.valid and r.checkpoint=="v2.02.185" and r.predecessor=="v2.02.184"
    assert r.evidence_digest=="a"*64 and len(r.continuity_digest)==64
    assert (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")

def test_v202185_continuity_digest_is_deterministic():
    assert ProviderFailoverEvidenceContinuityV185.verify(binding()).continuity_digest == ProviderFailoverEvidenceContinuityV185.verify(binding()).continuity_digest

def test_v202185_rejects_digest_mismatch():
    with pytest.raises(ValueError, match="V202185_EVIDENCE_DIGEST_MISMATCH"):
        ProviderFailoverEvidenceContinuityV185.verify(binding(), expected_evidence_digest="b"*64)

def test_v202185_rejects_lineage_mismatch():
    x=binding(); x.predecessor="v2.02.182"
    with pytest.raises(ValueError, match="V202185_BINDING_LINEAGE_INVALID"): ProviderFailoverEvidenceContinuityV185.verify(x)

def test_v202185_rejects_unsafe_state():
    x=binding(); x.live_trading="ENABLED"
    with pytest.raises(ValueError, match="V202185_SAFETY_STATE_INVALID"): ProviderFailoverEvidenceContinuityV185.verify(x)
