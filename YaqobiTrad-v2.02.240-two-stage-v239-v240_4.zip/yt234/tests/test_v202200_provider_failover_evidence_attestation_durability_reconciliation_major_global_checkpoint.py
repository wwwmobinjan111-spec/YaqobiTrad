from types import SimpleNamespace
import pytest
from yaqobitrad.v202200_provider_failover_evidence_attestation_durability_reconciliation_major_global_checkpoint import ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointV200

def provenance():
 return SimpleNamespace(valid=True,checkpoint="v2.02.199",predecessor="v2.02.198",reconciliation_ref="evidence://v202.02.195/reconciliation",provenance_ref="evidence://v202.02.199/provenance",recovery_ref="evidence://v202.02.198/recovery",attestation_ref="evidence://v202.02.197/attestation",live_trading="SAFE_OFF",activation_gate="LOCKED",fail_closed="ACTIVE")
def test_v202200_major_checkpoint_verifies_chain_and_safety():
 r=ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointV200.verify(provenance()); assert r.valid and r.checkpoint=="v2.02.200" and r.predecessor=="v2.02.199" and r.open_blocker_count==6 and len(r.checkpoint_digest)==64
 assert (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")
def test_v202200_checkpoint_digest_deterministic():
 a=ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointV200.verify(provenance()); b=ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointV200.verify(provenance()); assert a.checkpoint_digest==b.checkpoint_digest

def test_v202200_rejects_digest_mismatch():
 with pytest.raises(ValueError,match="V202200_PROVENANCE_DIGEST_MISMATCH"): ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointV200.verify(provenance(),expected_provenance_digest="d"*64)
def test_v202200_rejects_lineage_mismatch():
 x=provenance(); x.predecessor="v2.02.197"
 with pytest.raises(ValueError,match="V202200_PROVENANCE_LINEAGE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointV200.verify(x)
def test_v202200_rejects_unsafe_state():
 x=provenance(); x.activation_gate="OPEN"
 with pytest.raises(ValueError,match="V202200_SAFETY_STATE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointV200.verify(x)
