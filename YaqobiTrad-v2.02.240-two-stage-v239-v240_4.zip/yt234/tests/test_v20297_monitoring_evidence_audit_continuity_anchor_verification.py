"""v2.02.97 — monitoring evidence audit continuity anchor verification tests."""
import json
import pytest

from yaqobitrad.audit import AuditLog
from yaqobitrad.evidence_retention import RetentionPolicy
from yaqobitrad.monitoring import MonitoringState
from yaqobitrad.monitoring_evidence_boundary import MonitoringEvidenceBoundary
from yaqobitrad.monitoring_evidence_retrieval_boundary import MonitoringEvidenceRetrievalBoundary
from yaqobitrad.monitoring_evidence_retrieval_audit_binding import MonitoringEvidenceRetrievalAuditBinding
from yaqobitrad.monitoring_evidence_retrieval_audit_continuity import MonitoringEvidenceRetrievalAuditContinuity
from yaqobitrad.monitoring_evidence_audit_continuity_anchor import MonitoringEvidenceAuditContinuityAnchor
from yaqobitrad.monitoring_evidence_audit_continuity_anchor_verification import MonitoringEvidenceAuditContinuityAnchorVerification


def setup(tmp_path):
    state = MonitoringState(); state.heartbeat(100.0)
    retrieval = MonitoringEvidenceRetrievalBoundary(MonitoringEvidenceBoundary(state))
    policy = RetentionPolicy(minimum_days=90, immutable=True, remote=True, verified=True)
    evidence = {"timestamp": 100.0, "healthy": True, "heartbeat": 100.0}
    evidence_path = tmp_path / "monitoring-evidence.json"
    evidence_path.write_text(json.dumps(retrieval.envelope(evidence, policy), sort_keys=True, separators=(",", ":")))
    binding = MonitoringEvidenceRetrievalAuditBinding(retrieval, AuditLog())
    continuity = MonitoringEvidenceRetrievalAuditContinuity(binding)
    audit_path = tmp_path / "audit.json"
    result = continuity.bind_and_verify(str(evidence_path), str(audit_path), now=110.0, max_age=30.0)
    anchor = MonitoringEvidenceAuditContinuityAnchor()
    anchored = anchor.anchor(str(audit_path), expected_bound_audit_hash=result.audit_hash, expected_evidence_digest=result.evidence_digest)
    return MonitoringEvidenceAuditContinuityAnchorVerification(), audit_path, result, anchored


def test_v20297_read_only_anchor_verification(tmp_path):
    verifier, path, continuity, anchored = setup(tmp_path)
    before = path.read_bytes()
    result = verifier.verify(str(path), expected_bound_audit_hash=continuity.audit_hash, expected_evidence_digest=continuity.evidence_digest, expected_anchor_hash=anchored.anchor_hash)
    assert result.valid and result.anchor_hash == anchored.anchor_hash
    assert path.read_bytes() == before


def test_v20297_reload_preserves_anchor(tmp_path):
    verifier, path, continuity, anchored = setup(tmp_path)
    result = verifier.verify(str(path), expected_bound_audit_hash=continuity.audit_hash, expected_evidence_digest=continuity.evidence_digest)
    assert AuditLog(str(path)).entries[-1]["hash"] == result.anchor_hash


def test_v20297_wrong_digest_fails_closed(tmp_path):
    verifier, path, continuity, anchored = setup(tmp_path)
    with pytest.raises(ValueError, match="DIGEST_MISMATCH"):
        verifier.verify(str(path), expected_bound_audit_hash=continuity.audit_hash, expected_evidence_digest="0" * 64)


def test_v20297_duplicate_anchor_fails_closed(tmp_path):
    verifier, path, continuity, anchored = setup(tmp_path)
    payload = json.loads(path.read_text())
    payload["entries"].append(dict(payload["entries"][-1]))
    path.write_text(json.dumps(payload, sort_keys=True, separators=(",", ":")))
    with pytest.raises(ValueError, match="audit ledger integrity failure"):
        verifier.verify(str(path), expected_bound_audit_hash=continuity.audit_hash, expected_evidence_digest=continuity.evidence_digest)


def test_v20297_wrong_anchor_hash_fails_closed(tmp_path):
    verifier, path, continuity, anchored = setup(tmp_path)
    with pytest.raises(ValueError, match="ANCHOR_HASH_MISMATCH"):
        verifier.verify(str(path), expected_bound_audit_hash=continuity.audit_hash, expected_evidence_digest=continuity.evidence_digest, expected_anchor_hash="0" * 64)


def test_v20297_safety_state_preserved(tmp_path):
    verifier, path, continuity, anchored = setup(tmp_path)
    result = verifier.verify(str(path), expected_bound_audit_hash=continuity.audit_hash, expected_evidence_digest=continuity.evidence_digest)
    assert (result.live_trading, result.activation_gate, result.fail_closed) == ("SAFE_OFF", "LOCKED", "ACTIVE")
