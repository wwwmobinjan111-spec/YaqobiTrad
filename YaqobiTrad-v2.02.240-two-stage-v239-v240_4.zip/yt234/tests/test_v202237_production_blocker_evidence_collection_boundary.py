from types import SimpleNamespace
import pytest
from yaqobitrad.v202237_production_blocker_evidence_collection_boundary import ProductionBlockerEvidenceCollectionBoundaryV237 as V

def cp(): return SimpleNamespace(valid=True,checkpoint='v2.02.236',predecessor='v2.02.235',live_trading='SAFE_OFF',activation_gate='LOCKED',fail_closed='ACTIVE')
def test_collection_ready(): assert V.verify(cp()).valid and V.verify(cp()).evidence_collection_ready
def test_partial_collection(): r=V.verify(cp(),collected_blocker_ids=(V.REQUIRED[0],)); assert r.collected_blocker_count==1
def test_invalid_id():
 with pytest.raises(ValueError,match='V202237_EVIDENCE_COLLECTION_INVALID'): V.verify(cp(),collected_blocker_ids=('fake',))
def test_duplicate_rejected():
 with pytest.raises(ValueError,match='V202237_EVIDENCE_COLLECTION_INVALID'): V.verify(cp(),collected_blocker_ids=(V.REQUIRED[0],V.REQUIRED[0]))
def test_safety(): r=V.verify(cp()); assert (r.live_trading,r.activation_gate,r.fail_closed)==('SAFE_OFF','LOCKED','ACTIVE')
