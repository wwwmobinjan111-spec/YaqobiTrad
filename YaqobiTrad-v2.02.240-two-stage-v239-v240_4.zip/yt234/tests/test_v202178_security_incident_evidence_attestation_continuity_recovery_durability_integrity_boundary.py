from yaqobitrad.v202178_security_incident_evidence_attestation_continuity_recovery_durability_integrity_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityIntegrityBoundaryV178

class SafeState:
    activation_gate="LOCKED"
    live_trading="SAFE_OFF"
    fail_closed="ACTIVE"

def test_v202178_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityIntegrityBoundaryV178.verify(SafeState(), state_ref="evidence://state/v177", continuity_ref="evidence://continuity/v177", recovery_ref="evidence://recovery/v177", lineage_ref="evidence://lineage/v177", attestation_ref="evidence://attestation/v177")
    assert r.valid and r.checkpoint=="v2.02.178" and r.predecessor=="v2.02.177" and r.open_blocker_count==6

def test_v202178_rejects_reuse():
    try:
        SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityIntegrityBoundaryV178.verify(SafeState(), state_ref="evidence://same", continuity_ref="evidence://continuity", recovery_ref="evidence://recovery", lineage_ref="evidence://lineage", attestation_ref="evidence://same")
    except ValueError as e:
        assert str(e)=="V202178_REFERENCE_REUSE_INVALID"
    else:
        raise AssertionError("reference reuse was not rejected")
