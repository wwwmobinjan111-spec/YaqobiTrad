from types import SimpleNamespace
import pytest
from yaqobitrad.v202188_provider_failover_evidence_attestation_durability import ProviderFailoverEvidenceAttestationDurabilityV188

def attestation():
    return SimpleNamespace(valid=True, checkpoint="v2.02.187", predecessor="v2.02.186",
        continuity_digest="b"*64, attestation_digest="c"*64,
        live_trading="SAFE_OFF", activation_gate="LOCKED", fail_closed="ACTIVE")

def test_v202188_seals_and_preserves_safety():
    r=ProviderFailoverEvidenceAttestationDurabilityV188.seal(attestation(), expected_continuity_digest="b"*64)
    assert r.valid and r.checkpoint=="v2.02.188" and r.predecessor=="v2.02.187"
    assert r.continuity_digest=="b"*64 and len(r.durability_digest)==64
    assert (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")

def test_v202188_digest_is_deterministic():
    assert ProviderFailoverEvidenceAttestationDurabilityV188.seal(attestation()).durability_digest == ProviderFailoverEvidenceAttestationDurabilityV188.seal(attestation()).durability_digest

def test_v202188_rejects_digest_mismatch():
    with pytest.raises(ValueError, match="V202188_CONTINUITY_DIGEST_MISMATCH"):
        ProviderFailoverEvidenceAttestationDurabilityV188.seal(attestation(), expected_continuity_digest="d"*64)

def test_v202188_rejects_lineage_mismatch():
    x=attestation(); x.predecessor="v2.02.185"
    with pytest.raises(ValueError, match="V202188_CONTINUITY_LINEAGE_INVALID"):
        ProviderFailoverEvidenceAttestationDurabilityV188.seal(x)

def test_v202188_rejects_unsafe_state():
    x=attestation(); x.activation_gate="UNLOCKED"
    with pytest.raises(ValueError, match="V202188_SAFETY_STATE_INVALID"):
        ProviderFailoverEvidenceAttestationDurabilityV188.seal(x)
