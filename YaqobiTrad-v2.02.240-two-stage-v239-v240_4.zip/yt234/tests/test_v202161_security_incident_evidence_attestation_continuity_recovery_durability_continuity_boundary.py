from dataclasses import dataclass
import pytest
from yaqobitrad.v202161_security_incident_evidence_attestation_continuity_recovery_durability_continuity_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityContinuityBoundaryV161
@dataclass
class SafeState:
    activation_gate: str="LOCKED"; live_trading: str="SAFE_OFF"; fail_closed: str="ACTIVE"
def test_v202161_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityContinuityBoundaryV161.verify(SafeState(), state_ref="evidence://state/v160", continuity_ref="evidence://continuity/v160", recovery_ref="evidence://recovery/v160")
    assert r.valid and r.checkpoint=="v2.02.161" and r.predecessor=="v2.02.160" and r.open_blocker_count==6
def test_v202161_rejects_reuse():
    with pytest.raises(ValueError, match="REFERENCE_REUSE_INVALID"):
        SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityContinuityBoundaryV161.verify(SafeState(), state_ref="evidence://same", continuity_ref="evidence://same", recovery_ref="evidence://recovery")
