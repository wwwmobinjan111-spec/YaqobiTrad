def test_release_integrity_requires_expected_chain():
    chain = [
        "v2.02.75",
        "v2.02.76",
        "v2.02.77",
        "v2.02.78",
    ]
    assert chain[-1] == "v2.02.78"
    assert len(chain) == 4

def test_release_integrity_detects_mismatch():
    expected = "v2.02.78"
    observed = "v2.02.77"
    assert expected != observed
    integrity_ok = expected == observed
    assert integrity_ok is False

def test_integrity_failure_is_fail_closed():
    integrity_ok = False
    assert integrity_ok is False
    assert "LOCKED" == "LOCKED"
    assert "SAFE_OFF" == "SAFE_OFF"
    assert "ACTIVE" == "ACTIVE"
