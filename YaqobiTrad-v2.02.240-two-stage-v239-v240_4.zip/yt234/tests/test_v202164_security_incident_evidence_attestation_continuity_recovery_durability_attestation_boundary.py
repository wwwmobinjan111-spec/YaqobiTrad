from yaqobitrad.v202164_security_incident_evidence_attestation_continuity_recovery_durability_attestation_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityAttestationBoundaryV164

class SafeState:
    activation_gate="LOCKED"
    live_trading="SAFE_OFF"
    fail_closed="ACTIVE"

def test_v202164_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityAttestationBoundaryV164.verify(SafeState(), state_ref="evidence://state/v163", continuity_ref="evidence://continuity/v163", recovery_ref="evidence://recovery/v163")
    assert r.valid and r.checkpoint=="v2.02.164" and r.predecessor=="v2.02.163" and r.open_blocker_count==6

def test_v202164_rejects_reuse():
    try:
        SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityAttestationBoundaryV164.verify(SafeState(), state_ref="evidence://same", continuity_ref="evidence://same", recovery_ref="evidence://recovery")
    except ValueError as e:
        assert str(e)=="V202164_REFERENCE_REUSE_INVALID"
    else:
        raise AssertionError("reference reuse was not rejected")
