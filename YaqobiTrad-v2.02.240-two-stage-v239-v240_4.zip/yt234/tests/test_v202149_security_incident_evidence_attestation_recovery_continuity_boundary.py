from types import SimpleNamespace
from yaqobitrad.v202149_security_incident_evidence_attestation_recovery_continuity_boundary import SecurityIncidentEvidenceAttestationRecoveryContinuityBoundaryV149

STATE = SimpleNamespace(activation_gate="LOCKED", live_trading="SAFE_OFF", fail_closed="ACTIVE")

def test_v149_recovery_continuity_preserves_safe_state_and_blockers():
    r = SecurityIncidentEvidenceAttestationRecoveryContinuityBoundaryV149.verify(
        STATE,
        integrity_ref="evidence://security-incident/attestation-chain-integrity/2026-09",
        recovery_ref="evidence://security-incident/attestation-recovery-continuity/2026-09",
    )
    assert r.valid and r.open_blocker_count == 6
    assert r.live_trading == "SAFE_OFF" and r.activation_gate == "LOCKED" and r.fail_closed == "ACTIVE"
    assert r.predecessor == "v2.02.148"

def test_v149_rejects_secret_or_assignment_material():
    for value in ("PASSWORD=plaintext", "evidence://security-incident/PRIVATE_KEY/value"):
        try:
            SecurityIncidentEvidenceAttestationRecoveryContinuityBoundaryV149.verify(
                STATE,
                integrity_ref=value,
                recovery_ref="evidence://security-incident/attestation-recovery-continuity/2026-09",
            )
        except ValueError:
            pass
        else:
            raise AssertionError
