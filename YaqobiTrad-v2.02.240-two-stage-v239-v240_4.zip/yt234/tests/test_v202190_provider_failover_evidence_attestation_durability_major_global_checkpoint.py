from types import SimpleNamespace
import pytest

from yaqobitrad.v202190_provider_failover_evidence_attestation_durability_major_global_checkpoint import (
    ProviderFailoverEvidenceAttestationDurabilityMajorGlobalCheckpointV190,
)


def continuity():
    return SimpleNamespace(
        valid=True,
        checkpoint="v2.02.189",
        predecessor="v2.02.188",
        continuity_digest="b" * 64,
        durability_digest="c" * 64,
        live_trading="SAFE_OFF",
        activation_gate="LOCKED",
        fail_closed="ACTIVE",
    )


def test_v202190_major_checkpoint_verifies_chain_and_safety():
    r = ProviderFailoverEvidenceAttestationDurabilityMajorGlobalCheckpointV190.verify(
        continuity(), expected_durability_digest="c" * 64
    )
    assert r.valid and r.checkpoint == "v2.02.190" and r.predecessor == "v2.02.189"
    assert r.open_blocker_count == 6 and len(r.checkpoint_digest) == 64
    assert (r.live_trading, r.activation_gate, r.fail_closed) == ("SAFE_OFF", "LOCKED", "ACTIVE")


def test_v202190_checkpoint_digest_is_deterministic():
    a = ProviderFailoverEvidenceAttestationDurabilityMajorGlobalCheckpointV190.verify(continuity())
    b = ProviderFailoverEvidenceAttestationDurabilityMajorGlobalCheckpointV190.verify(continuity())
    assert a.checkpoint_digest == b.checkpoint_digest


def test_v202190_rejects_digest_mismatch():
    with pytest.raises(ValueError, match="V202190_DURABILITY_DIGEST_MISMATCH"):
        ProviderFailoverEvidenceAttestationDurabilityMajorGlobalCheckpointV190.verify(
            continuity(), expected_durability_digest="d" * 64
        )


def test_v202190_rejects_lineage_mismatch():
    x = continuity()
    x.predecessor = "v2.02.187"
    with pytest.raises(ValueError, match="V202190_CONTINUITY_LINEAGE_INVALID"):
        ProviderFailoverEvidenceAttestationDurabilityMajorGlobalCheckpointV190.verify(x)


def test_v202190_rejects_unsafe_state():
    x = continuity()
    x.activation_gate = "UNLOCKED"
    with pytest.raises(ValueError, match="V202190_SAFETY_STATE_INVALID"):
        ProviderFailoverEvidenceAttestationDurabilityMajorGlobalCheckpointV190.verify(x)
