from types import SimpleNamespace
import pytest
from yaqobitrad.v202230_provider_failover_evidence_attestation_durability_reconciliation_major_global_checkpoint import ProviderFailoverEvidenceAttestationDurabilityReconciliationMajorGlobalCheckpointV230 as V
def integrity(): return SimpleNamespace(valid=True,checkpoint="v2.02.229",predecessor="v2.02.228",checkpoint_digest="a"*64,integrity_ref="evidence://v2.02.229/integrity",recovery_ref="evidence://v2.02.228/recovery",live_trading="SAFE_OFF",activation_gate="LOCKED",fail_closed="ACTIVE")
def test_v202230_major_checkpoint_verifies_chain_and_safety():
 r=V.verify(integrity()); assert r.valid and r.checkpoint=="v2.02.230" and r.predecessor=="v2.02.229" and r.open_blocker_count==6 and len(r.checkpoint_digest)==64 and (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")
def test_v202230_checkpoint_digest_deterministic():
 a=V.verify(integrity()); b=V.verify(integrity()); assert a.checkpoint_digest==b.checkpoint_digest
def test_v202230_rejects_digest_mismatch():
 with pytest.raises(ValueError,match="V202230_INTEGRITY_DIGEST_MISMATCH"): V.verify(integrity(),expected_integrity_digest="d"*64)
def test_v202230_rejects_lineage_mismatch():
 x=integrity(); x.predecessor="v2.02.227"
 with pytest.raises(ValueError,match="V202230_INTEGRITY_LINEAGE_INVALID"): V.verify(x)
def test_v202230_rejects_unsafe_state():
 x=integrity(); x.activation_gate="OPEN"
 with pytest.raises(ValueError,match="V202230_SAFETY_STATE_INVALID"): V.verify(x)
