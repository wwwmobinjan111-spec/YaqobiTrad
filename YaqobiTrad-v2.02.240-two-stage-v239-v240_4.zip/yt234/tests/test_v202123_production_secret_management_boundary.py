from yaqobitrad.security import SecretVault
from yaqobitrad.v202123_production_secret_management_boundary import ProductionSecretManagementBoundaryV123

def test_valid(): assert ProductionSecretManagementBoundaryV123.verify(SecretVault()).valid
def test_invalid():
    try: ProductionSecretManagementBoundaryV123.verify(object())
    except ValueError as e: assert str(e)=="V202123_SECRET_VAULT_INTERFACE_INVALID"
def test_safety():
    r=ProductionSecretManagementBoundaryV123.verify(SecretVault()); assert (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")
