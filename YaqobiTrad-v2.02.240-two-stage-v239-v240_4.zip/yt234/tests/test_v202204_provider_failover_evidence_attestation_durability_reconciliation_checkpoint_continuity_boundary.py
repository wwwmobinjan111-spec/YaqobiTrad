from types import SimpleNamespace
import pytest
from yaqobitrad.v202204_provider_failover_evidence_attestation_durability_reconciliation_checkpoint_continuity_boundary import ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointContinuityBoundaryV204 as V
def s(): return SimpleNamespace(checkpoint="v2.02.204",predecessor="v2.02.203",live_trading="SAFE_OFF",activation_gate="LOCKED",fail_closed="ACTIVE",checkpoint_digest="c"*64)
def test_accept(): assert V.verify(s(),checkpoint_digest="c"*64,integrity_ref="evidence://i",continuity_ref="evidence://c").valid
def test_digest():
 with pytest.raises(ValueError,match="V202204_CHECKPOINT_DIGEST_MISMATCH"): V.verify(s(),checkpoint_digest="d"*64,integrity_ref="evidence://i",continuity_ref="evidence://c")
def test_lineage():
 x=s(); x.checkpoint="v2.02.203"
 with pytest.raises(ValueError,match="V202204_LINEAGE_INVALID"): V.verify(x,checkpoint_digest="c"*64,integrity_ref="evidence://i",continuity_ref="evidence://c")
def test_safety():
 x=s(); x.fail_closed="INACTIVE"
 with pytest.raises(ValueError,match="V202204_SAFETY_STATE_INVALID"): V.verify(x,checkpoint_digest="c"*64,integrity_ref="evidence://i",continuity_ref="evidence://c")
def test_reuse():
 with pytest.raises(ValueError,match="V202204_REFERENCE_REUSE_INVALID"): V.verify(s(),checkpoint_digest="c"*64,integrity_ref="evidence://x",continuity_ref="evidence://x")
