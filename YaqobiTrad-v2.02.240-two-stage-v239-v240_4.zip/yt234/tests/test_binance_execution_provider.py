from yaqobitrad.binance_execution_provider import BinanceExecutionProvider, ExchangeOrder

def test_live_adapter_fail_closed_when_safe_off():
    p = BinanceExecutionProvider("k", "s")
    assert p.submit("c1", "BUY", 1, 100) == {"status":"BLOCKED", "reason":"LIVE_TRADING_SAFE_OFF"}

def test_live_adapter_signs_request_and_preserves_idempotency():
    calls=[]
    def transport(method, path, headers):
        calls.append((method,path,headers))
        return {"orderId":123, "status":"NEW"}
    p=BinanceExecutionProvider("key", "secret", live_enabled=True, transport=transport)
    a=p.submit("c1","BUY",1,100)
    b=p.submit("c1","BUY",1,100)
    assert isinstance(a, ExchangeOrder) and a.provider_order_id=="123"
    assert a==b and len(calls)==1
    assert "signature=" in calls[0][1] and "newClientOrderId=c1" in calls[0][1]
    assert calls[0][2]["X-MBX-APIKEY"]=="key"

def test_live_adapter_reconcile_uses_provider_state():
    def transport(method,path,headers):
        return {"orderId":456,"status":"FILLED"}
    p=BinanceExecutionProvider("k","s",live_enabled=True,transport=transport)
    o=p.reconcile("c2")
    assert o.provider_order_id=="456" and o.status=="FILLED"
