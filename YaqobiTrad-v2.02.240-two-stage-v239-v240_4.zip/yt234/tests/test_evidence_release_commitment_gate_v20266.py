from yaqobitrad.audit import AuditLog
from yaqobitrad.checkpoint_evidence_seal import CheckpointEvidenceSealer
from yaqobitrad.evidence_release_gate import EvidenceReleaseGate
from yaqobitrad.evidence_release_reconciliation_gate import EvidenceReleaseReconciliationGate
from yaqobitrad.evidence_release_finalization_gate import EvidenceReleaseFinalizationGate
from yaqobitrad.evidence_release_commitment_gate import EvidenceReleaseCommitmentGate
from yaqobitrad.evidence_retention import RetentionPolicy
from yaqobitrad.evidence_retention_gate import EvidenceRetentionGate
from yaqobitrad.global_checkpoint import global_checkpoint


def setup():
    audit = AuditLog()
    retention = EvidenceRetentionGate(audit)
    assert retention.verify(RetentionPolicy(90, True, True, True)).valid
    sealer = CheckpointEvidenceSealer(audit)
    checkpoint = global_checkpoint()
    sealer.seal(checkpoint)
    release = EvidenceReleaseGate(audit, retention, sealer)
    assert release.authorize(checkpoint).allowed
    reconciliation = EvidenceReleaseReconciliationGate(audit, retention, release)
    finalization = EvidenceReleaseFinalizationGate(audit, reconciliation)
    return audit, finalization, checkpoint


def test_commitment_succeeds():
    audit, finalization, checkpoint = setup()
    gate = EvidenceReleaseCommitmentGate(audit, finalization)
    result = gate.commit(checkpoint)
    assert result.committed
    assert result.reason == "EVIDENCE_RELEASE_COMMITTED"
    assert gate.committed
    assert audit.verify()


def test_invalid_audit_blocks_commitment():
    audit, finalization, checkpoint = setup()
    audit.entries[0]["data"]["minimum_days"] = 1
    gate = EvidenceReleaseCommitmentGate(audit, finalization)
    result = gate.commit(checkpoint)
    assert not result.committed
    assert result.reason == "AUDIT_CHAIN_INVALID"
    assert not gate.committed


def test_commitment_is_idempotent():
    audit, finalization, checkpoint = setup()
    gate = EvidenceReleaseCommitmentGate(audit, finalization)
    first = gate.commit(checkpoint)
    count = len(audit.entries)
    second = gate.commit(checkpoint)
    assert first.committed and second.committed
    assert len(audit.entries) == count
