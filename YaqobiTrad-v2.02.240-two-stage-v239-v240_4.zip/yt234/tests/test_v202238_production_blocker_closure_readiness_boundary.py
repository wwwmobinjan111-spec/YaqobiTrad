from types import SimpleNamespace
import pytest
from yaqobitrad.v202238_production_blocker_closure_readiness_boundary import ProductionBlockerClosureReadinessBoundaryV238 as V

def cp(): return SimpleNamespace(valid=True,checkpoint='v2.02.237',predecessor='v2.02.236',live_trading='SAFE_OFF',activation_gate='LOCKED',fail_closed='ACTIVE')
def test_closure_not_ready_without_real_proof():
 r=V.verify(cp()); assert not r.closure_ready and r.real_production_evidence_required
def test_evidence_does_not_auto_close():
 r=V.verify(cp(),production_evidence=V.REQUIRED); assert not r.closure_ready and r.open_blocker_count==6
def test_invalid_evidence_id():
 with pytest.raises(ValueError,match='V202238_EVIDENCE_ID_INVALID'): V.verify(cp(),production_evidence=('fake',))
def test_duplicate_evidence_rejected():
 with pytest.raises(ValueError,match='V202238_EVIDENCE_DUPLICATE'): V.verify(cp(),production_evidence=(V.REQUIRED[0],V.REQUIRED[0]))
def test_safety(): r=V.verify(cp()); assert (r.live_trading,r.activation_gate,r.fail_closed)==('SAFE_OFF','LOCKED','ACTIVE')
