def test_major_global_checkpoint_safety_state():
    state = {
        "live_trading": "SAFE_OFF",
        "activation_gate": "LOCKED",
        "fail_closed": "ACTIVE",
    }
    assert state == {
        "live_trading": "SAFE_OFF",
        "activation_gate": "LOCKED",
        "fail_closed": "ACTIVE",
    }

from yaqobitrad.global_checkpoint import global_checkpoint

def test_major_global_checkpoint_version():
    assert global_checkpoint().checkpoint == "v2.02.90"

def test_major_global_checkpoint_release_chain():
    chain = [
        "v2.02.77",
        "v2.02.78",
        "v2.02.79",
        "v2.02.90",
    ]
    assert chain[-1] == "v2.02.90"
    assert len(chain) == 4
