"""v2.02.88 — Audit durability continuity verification tests."""
import json
import pytest

from yaqobitrad.audit import AuditLog
from yaqobitrad.audit_durability_evidence_gate import persist_audit_evidence
from yaqobitrad.durability_continuity_gate import DurabilityContinuityGate
from yaqobitrad.evidence_integrity_attestation import EvidenceIntegrityAttestationGate
from yaqobitrad.production_blockers import open_production_blockers


def setup():
    audit = AuditLog()
    audit.append("EVIDENCE_CREATED", {"checkpoint": "v2.02.87"})
    audit.append("AUDIT_DURABILITY_VERIFIED", {"checkpoint": "v2.02.87"})
    gate = EvidenceIntegrityAttestationGate(audit)
    attestation, result = gate.attest()
    assert result.valid
    return audit, gate, attestation


def test_v20288_repeated_recovery_is_deterministic(tmp_path):
    audit, gate, attestation = setup()
    path = tmp_path / "evidence.json"
    persist_audit_evidence(audit, attestation, str(path))
    result = DurabilityContinuityGate(gate).verify(str(path), audit, attestation)
    assert result.valid
    assert result.reason == "AUDIT_DURABILITY_CONTINUITY_VERIFIED"
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"


def test_v20288_recovery_detects_attestation_drift(tmp_path):
    audit, gate, attestation = setup()
    path = tmp_path / "evidence.json"
    persist_audit_evidence(audit, attestation, str(path))
    data = json.loads(path.read_text())
    data["attestation"]["checkpoint"] = "forged"
    path.write_text(json.dumps(data))
    with pytest.raises(ValueError, match="EVIDENCE_ENVELOPE_DIGEST_MISMATCH"):
        DurabilityContinuityGate(gate).verify(str(path), audit, attestation)


def test_v20288_recovery_detects_audit_drift(tmp_path):
    audit, gate, attestation = setup()
    path = tmp_path / "evidence.json"
    persist_audit_evidence(audit, attestation, str(path))
    data = json.loads(path.read_text())
    data["audit"]["prev_hash"] = "GENESIS"
    path.write_text(json.dumps(data))
    with pytest.raises(ValueError, match="EVIDENCE_ENVELOPE_DIGEST_MISMATCH"):
        DurabilityContinuityGate(gate).verify(str(path), audit, attestation)


def test_v20288_blockers_preserved_after_repeated_recovery(tmp_path):
    audit, gate, attestation = setup()
    before = tuple(b.blocker_id for b in open_production_blockers())
    path = tmp_path / "evidence.json"
    persist_audit_evidence(audit, attestation, str(path))
    result = DurabilityContinuityGate(gate).verify(str(path), audit, attestation)
    after = tuple(b.blocker_id for b in open_production_blockers())
    assert result.valid
    assert before == after


def test_v20288_missing_artifact_fails_closed(tmp_path):
    audit, gate, attestation = setup()
    path = tmp_path / "missing.json"
    with pytest.raises(ValueError, match="EVIDENCE_PERSISTENCE_INVALID"):
        DurabilityContinuityGate(gate).verify(str(path), audit, attestation)
