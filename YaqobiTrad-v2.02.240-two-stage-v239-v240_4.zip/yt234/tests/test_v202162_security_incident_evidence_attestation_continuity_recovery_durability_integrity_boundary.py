from yaqobitrad.v202162_security_incident_evidence_attestation_continuity_recovery_durability_integrity_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityIntegrityBoundaryV162

class SafeState:
    activation_gate="LOCKED"
    live_trading="SAFE_OFF"
    fail_closed="ACTIVE"

def test_v202162_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityIntegrityBoundaryV162.verify(SafeState(), state_ref="evidence://state/v161", continuity_ref="evidence://continuity/v161", recovery_ref="evidence://recovery/v161")
    assert r.valid and r.checkpoint=="v2.02.162" and r.predecessor=="v2.02.161" and r.open_blocker_count==6

def test_v202162_rejects_reuse():
    try:
        SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityIntegrityBoundaryV162.verify(SafeState(), state_ref="evidence://same", continuity_ref="evidence://same", recovery_ref="evidence://recovery")
    except ValueError as e:
        assert str(e)=="V202162_REFERENCE_REUSE_INVALID"
    else:
        raise AssertionError("reference reuse was not rejected")
