from yaqobitrad.v202128_release_readiness_boundary import ReleaseReadinessBoundaryV128
class G:
    def validate(self): return True
    def is_ready(self): return False

def test_release_readiness_boundary_valid():
    assert ReleaseReadinessBoundaryV128.verify(G()).valid

def test_ready_without_production_evidence_rejected():
    class Ready(G):
        def is_ready(self): return True
    try: ReleaseReadinessBoundaryV128.verify(Ready())
    except ValueError as e: assert str(e)=="V202128_READY_REQUIRES_PRODUCTION_EVIDENCE"
    else: assert False

def test_release_readiness_preserves_safety():
    r=ReleaseReadinessBoundaryV128.verify(G())
    assert (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")
