from types import SimpleNamespace
import pytest
from yaqobitrad.v202186_provider_failover_evidence_attestation import ProviderFailoverEvidenceAttestationV186

def continuity():
    return SimpleNamespace(valid=True, checkpoint="v2.02.185", predecessor="v2.02.184",
        evidence_ref="evidence://provider-failover/v183", evidence_digest="a"*64,
        continuity_digest="b"*64, live_trading="SAFE_OFF", activation_gate="LOCKED", fail_closed="ACTIVE")

def test_v202186_attests_continuity_and_preserves_safety():
    r=ProviderFailoverEvidenceAttestationV186.attest(continuity(), expected_continuity_digest="b"*64)
    assert r.valid and r.checkpoint=="v2.02.186" and r.predecessor=="v2.02.185"
    assert r.continuity_digest=="b"*64 and len(r.attestation_digest)==64
    assert (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")

def test_v202186_attestation_is_deterministic():
    assert ProviderFailoverEvidenceAttestationV186.attest(continuity()).attestation_digest == ProviderFailoverEvidenceAttestationV186.attest(continuity()).attestation_digest

def test_v202186_rejects_digest_mismatch():
    with pytest.raises(ValueError, match="V202186_CONTINUITY_DIGEST_MISMATCH"):
        ProviderFailoverEvidenceAttestationV186.attest(continuity(), expected_continuity_digest="c"*64)

def test_v202186_rejects_lineage_mismatch():
    x=continuity(); x.predecessor="v2.02.183"
    with pytest.raises(ValueError, match="V202186_CONTINUITY_LINEAGE_INVALID"): ProviderFailoverEvidenceAttestationV186.attest(x)

def test_v202186_rejects_unsafe_state():
    x=continuity(); x.activation_gate="UNLOCKED"
    with pytest.raises(ValueError, match="V202186_SAFETY_STATE_INVALID"): ProviderFailoverEvidenceAttestationV186.attest(x)
