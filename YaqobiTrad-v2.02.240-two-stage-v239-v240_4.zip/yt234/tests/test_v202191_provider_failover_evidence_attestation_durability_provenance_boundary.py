from types import SimpleNamespace
import pytest
from yaqobitrad.v202191_provider_failover_evidence_attestation_durability_provenance_boundary import ProviderFailoverEvidenceAttestationDurabilityProvenanceBoundaryV191

def state(): return SimpleNamespace(activation_gate="LOCKED", live_trading="SAFE_OFF", fail_closed="ACTIVE")
def refs(): return dict(continuity_ref="evidence://v202.02.189/continuity", durability_ref="evidence://v202.02.190/durability", checkpoint_ref="evidence://v202.02.190/checkpoint", provenance_ref="evidence://v202.02.191/provenance")

def test_v202191_provenance_boundary():
    r=ProviderFailoverEvidenceAttestationDurabilityProvenanceBoundaryV191.verify(state(),**refs())
    assert r.valid and r.checkpoint=="v2.02.191" and r.predecessor=="v2.02.190" and r.open_blocker_count==6

def test_v202191_safety_is_fail_closed():
    x=state(); x.activation_gate="UNLOCKED"
    with pytest.raises(ValueError,match="V202191_SAFETY_STATE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityProvenanceBoundaryV191.verify(x,**refs())

def test_v202191_refs_must_be_unique():
    r=refs(); r["provenance_ref"]=r["continuity_ref"]
    with pytest.raises(ValueError,match="V202191_REFERENCE_REUSE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityProvenanceBoundaryV191.verify(state(),**r)

def test_v202191_rejects_secret_material():
    r=refs(); r["provenance_ref"]="evidence://v202.02.191/SECRET"
    with pytest.raises(ValueError,match="V202191_PROVENANCE_REF_SECRET_OR_ASSIGNMENT_INVALID"): ProviderFailoverEvidenceAttestationDurabilityProvenanceBoundaryV191.verify(state(),**r)

def test_v202191_rejects_assignment():
    r=refs(); r["checkpoint_ref"]="evidence://v202.02.190/checkpoint=x"
    with pytest.raises(ValueError,match="V202191_CHECKPOINT_REF_SECRET_OR_ASSIGNMENT_INVALID"): ProviderFailoverEvidenceAttestationDurabilityProvenanceBoundaryV191.verify(state(),**r)
