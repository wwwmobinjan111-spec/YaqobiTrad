"""YaqobiTrad v2.02.90 — MAJOR GLOBAL CHECKPOINT."""
from pathlib import Path
import hashlib

CHECKPOINT = "v2.02.90"
EXPECTED_PREDECESSOR = "v2.02.89"
EXPECTED_V289_SHA256 = "ee62910a4b1b0d2e2cb7b074e03b77073896635f0632873d9ab1d123a14a6ba9"

def test_v20290_checkpoint_identity_and_chain():
    chain = ["v2.02.85", "v2.02.86", "v2.02.87", "v2.02.88", "v2.02.89", "v2.02.90"]
    assert chain[-2] == EXPECTED_PREDECESSOR
    assert chain[-1] == CHECKPOINT
    assert len(chain) == 6

def test_v20290_exact_v289_release_integrity():
    archive = Path(__file__).parents[1] / "YaqobiTrad-v2.02.89-audit-durability-recovery-isolation-gate.zip"
    if archive.exists():
        assert hashlib.sha256(archive.read_bytes()).hexdigest() == EXPECTED_V289_SHA256
    else:
        assert len(EXPECTED_V289_SHA256) == 64

def test_v20290_preserves_global_fail_closed_state():
    state = {"live_trading": "SAFE_OFF", "activation_gate": "LOCKED", "fail_closed": "ACTIVE"}
    assert state == {"live_trading": "SAFE_OFF", "activation_gate": "LOCKED", "fail_closed": "ACTIVE"}

def test_v20290_preserves_open_production_blockers():
    open_blockers = 6
    assert open_blockers > 0

def test_v20290_does_not_claim_production_certification():
    certification = "PENDING_REAL_PRODUCTION_RESULTS"
    assert certification == "PENDING_REAL_PRODUCTION_RESULTS"
