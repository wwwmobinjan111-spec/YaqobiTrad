from types import SimpleNamespace
import pytest
from yaqobitrad.v202194_provider_failover_evidence_attestation_durability_integrity_boundary import ProviderFailoverEvidenceAttestationDurabilityIntegrityBoundaryV194
def state(): return SimpleNamespace(activation_gate="LOCKED",live_trading="SAFE_OFF",fail_closed="ACTIVE")
def refs(): return dict(recovery_ref="evidence://v202.02.193/recovery",provenance_ref="evidence://v202.02.193/provenance",attestation_ref="evidence://v202.02.194/attestation",integrity_ref="evidence://v202.02.194/integrity")
def test_v202194_integrity_boundary():
 r=ProviderFailoverEvidenceAttestationDurabilityIntegrityBoundaryV194.verify(state(),**refs()); assert r.valid and r.checkpoint=="v2.02.194" and r.predecessor=="v2.02.193" and r.open_blocker_count==6
def test_v202194_safety_is_fail_closed():
 x=state(); x.live_trading="ON"
 with pytest.raises(ValueError,match="V202194_SAFETY_STATE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityIntegrityBoundaryV194.verify(x,**refs())
def test_v202194_refs_unique():
 r=refs(); r["integrity_ref"]=r["recovery_ref"]
 with pytest.raises(ValueError,match="V202194_REFERENCE_REUSE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityIntegrityBoundaryV194.verify(state(),**r)
def test_v202194_rejects_secret():
 r=refs(); r["integrity_ref"]="evidence://v202.02.194/SECRET"
 with pytest.raises(ValueError,match="V202194_INTEGRITY_REF_SECRET_OR_ASSIGNMENT_INVALID"): ProviderFailoverEvidenceAttestationDurabilityIntegrityBoundaryV194.verify(state(),**r)
def test_v202194_rejects_assignment():
 r=refs(); r["attestation_ref"]="evidence://v202.02.194/attestation=x"
 with pytest.raises(ValueError,match="V202194_ATTESTATION_REF_SECRET_OR_ASSIGNMENT_INVALID"): ProviderFailoverEvidenceAttestationDurabilityIntegrityBoundaryV194.verify(state(),**r)
