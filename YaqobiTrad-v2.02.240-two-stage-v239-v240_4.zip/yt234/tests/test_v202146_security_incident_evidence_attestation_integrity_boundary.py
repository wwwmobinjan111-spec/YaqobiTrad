from types import SimpleNamespace
from yaqobitrad.v202146_security_incident_evidence_attestation_integrity_boundary import SecurityIncidentEvidenceAttestationIntegrityBoundaryV146

STATE = SimpleNamespace(activation_gate="LOCKED", live_trading="SAFE_OFF", fail_closed="ACTIVE")

def test_v146_integrity_boundary_preserves_safe_state_and_blockers():
    r = SecurityIncidentEvidenceAttestationIntegrityBoundaryV146.verify(
        STATE, integrity_ref="evidence://security-incident/attestation-integrity/2026-09"
    )
    assert r.valid and r.open_blocker_count == 6
    assert r.live_trading == "SAFE_OFF" and r.activation_gate == "LOCKED" and r.fail_closed == "ACTIVE"
    assert r.predecessor == "v2.02.145"

def test_v146_rejects_secret_or_assignment_material():
    for value in ("SECRET=plaintext", "evidence://TOKEN=plaintext", "evidence://security-incident/SECRET/value"):
        try:
            SecurityIncidentEvidenceAttestationIntegrityBoundaryV146.verify(STATE, integrity_ref=value)
        except ValueError:
            pass
        else:
            raise AssertionError
