"""v2.02.94 — monitoring evidence retrieval audit binding tests."""
import json
import pytest

from yaqobitrad.audit import AuditLog
from yaqobitrad.evidence_retention import RetentionPolicy
from yaqobitrad.monitoring import MonitoringState
from yaqobitrad.monitoring_evidence_boundary import MonitoringEvidenceBoundary
from yaqobitrad.monitoring_evidence_retrieval_boundary import MonitoringEvidenceRetrievalBoundary
from yaqobitrad.monitoring_evidence_retrieval_audit_binding import MonitoringEvidenceRetrievalAuditBinding
from yaqobitrad.production_blockers import open_production_blockers


def setup(tmp_path):
    state = MonitoringState()
    state.heartbeat(100.0)
    retrieval = MonitoringEvidenceRetrievalBoundary(MonitoringEvidenceBoundary(state))
    policy = RetentionPolicy(minimum_days=90, immutable=True, remote=True, verified=True)
    evidence = {"timestamp": 100.0, "healthy": True, "heartbeat": 100.0}
    path = tmp_path / "monitoring-evidence.json"
    path.write_text(json.dumps(retrieval.envelope(evidence, policy), sort_keys=True, separators=(",", ":")))
    return MonitoringEvidenceRetrievalAuditBinding(retrieval, AuditLog()), path


def test_v20294_verified_retrieval_is_audit_bound(tmp_path):
    gate, path = setup(tmp_path)
    result = gate.bind(str(path), now=110.0, max_age=30.0)
    assert result.valid
    assert result.reason == "MONITORING_EVIDENCE_RETRIEVAL_AUDIT_BOUND"
    assert len(gate.audit.entries) == 1
    assert gate.audit.verify()
    assert gate.audit.entries[0]["event"] == "MONITORING_EVIDENCE_RETRIEVAL_VERIFIED"
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"


def test_v20294_audit_record_binds_exact_evidence_digest(tmp_path):
    gate, path = setup(tmp_path)
    result = gate.bind(str(path), now=110.0, max_age=30.0)
    assert gate.audit.entries[0]["data"]["evidence_digest"] == result.evidence_digest


def test_v20294_invalid_existing_audit_fails_closed(tmp_path):
    gate, path = setup(tmp_path)
    gate.audit.entries.append({"corrupt": True})
    with pytest.raises(ValueError, match="MONITORING_RETRIEVAL_AUDIT_CHAIN_INVALID"):
        gate.bind(str(path), now=110.0, max_age=30.0)


def test_v20294_stale_retrieval_does_not_append_audit(tmp_path):
    gate, path = setup(tmp_path)
    with pytest.raises(ValueError, match="MONITORING_HEARTBEAT_STALE"):
        gate.bind(str(path), now=140.0, max_age=30.0)
    assert gate.audit.entries == []


def test_v20294_binding_preserves_retrieved_artifact_and_blockers(tmp_path):
    gate, path = setup(tmp_path)
    before_bytes = path.read_bytes()
    before = tuple(b.blocker_id for b in open_production_blockers())
    result = gate.bind(str(path), now=110.0, max_age=30.0)
    after_bytes = path.read_bytes()
    after = tuple(b.blocker_id for b in open_production_blockers())
    assert result.valid
    assert before_bytes == after_bytes
    assert before == after
    assert len(after) == 6


def test_v20294_persistent_audit_chain_round_trip(tmp_path):
    gate, path = setup(tmp_path)
    audit_path = tmp_path / "audit.json"
    gate.audit.path = str(audit_path)
    result = gate.bind(str(path), now=110.0, max_age=30.0)
    restored = AuditLog(str(audit_path))
    assert result.audit_hash == restored.entries[-1]["hash"]
    assert restored.verify()
