from types import SimpleNamespace
import pytest
from yaqobitrad.v202233_production_blocker_evidence_readiness_boundary import ProductionBlockerEvidenceReadinessBoundaryV233 as V

def cp(): return SimpleNamespace(valid=True,checkpoint='v2.02.232',predecessor='v2.02.231',live_trading='SAFE_OFF',activation_gate='LOCKED',fail_closed='ACTIVE')
def test_v202233_evidence_readiness():
 r=V.verify(cp()); assert r.valid and r.open_blocker_count==6 and r.required_blockers==V.REQUIRED

def test_v202233_preserves_safety():
 r=V.verify(cp()); assert (r.live_trading,r.activation_gate,r.fail_closed)==('SAFE_OFF','LOCKED','ACTIVE')

def test_v202233_rejects_lineage():
 x=cp(); x.checkpoint='v2.02.231'
 with pytest.raises(ValueError,match='V202233_LINEAGE_INVALID'): V.verify(x)

def test_v202233_rejects_unsafe():
 x=cp(); x.live_trading='ON'
 with pytest.raises(ValueError,match='V202233_SAFETY_STATE_INVALID'): V.verify(x)

def test_v202233_requires_all_six():
 assert len(V.REQUIRED)==6
