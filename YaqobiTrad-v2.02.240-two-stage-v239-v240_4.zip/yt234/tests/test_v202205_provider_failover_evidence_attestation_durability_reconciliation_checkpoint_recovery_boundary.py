from types import SimpleNamespace
import pytest
from yaqobitrad.v202205_provider_failover_evidence_attestation_durability_reconciliation_checkpoint_recovery_boundary import ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointRecoveryBoundaryV205 as V
def s(): return SimpleNamespace(checkpoint="v2.02.205",predecessor="v2.02.204",live_trading="SAFE_OFF",activation_gate="LOCKED",fail_closed="ACTIVE",checkpoint_digest="c"*64)
def test_accept(): assert V.verify(s(),checkpoint_digest="c"*64,recovery_ref="evidence://recovery",continuity_ref="evidence://continuity").valid
def test_digest():
 with pytest.raises(ValueError,match="V202205_CHECKPOINT_DIGEST_MISMATCH"): V.verify(s(),checkpoint_digest="d"*64,recovery_ref="evidence://r",continuity_ref="evidence://c")
def test_lineage():
 x=s(); x.predecessor="v2.02.203"
 with pytest.raises(ValueError,match="V202205_LINEAGE_INVALID"): V.verify(x,checkpoint_digest="c"*64,recovery_ref="evidence://r",continuity_ref="evidence://c")
def test_safety():
 x=s(); x.activation_gate="OPEN"
 with pytest.raises(ValueError,match="V202205_SAFETY_STATE_INVALID"): V.verify(x,checkpoint_digest="c"*64,recovery_ref="evidence://r",continuity_ref="evidence://c")
def test_reuse():
 with pytest.raises(ValueError,match="V202205_REFERENCE_REUSE_INVALID"): V.verify(s(),checkpoint_digest="c"*64,recovery_ref="evidence://x",continuity_ref="evidence://x")
