from yaqobitrad.v202171_security_incident_evidence_attestation_continuity_recovery_durability_continuity_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryAttestationBoundaryV171

class SafeState:
    activation_gate="LOCKED"
    live_trading="SAFE_OFF"
    fail_closed="ACTIVE"

def test_v202170_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryAttestationBoundaryV171.verify(
        SafeState(), state_ref="evidence://state/v170", continuity_ref="evidence://continuity/v170",
        recovery_ref="evidence://recovery/v170", lineage_ref="evidence://lineage/v170",
        attestation_ref="evidence://attestation/v170")
    assert r.valid and r.checkpoint=="v2.02.171" and r.predecessor=="v2.02.170" and r.open_blocker_count==6

def test_v202170_rejects_reuse():
    try:
        SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryAttestationBoundaryV171.verify(
            SafeState(), state_ref="evidence://same", continuity_ref="evidence://continuity",
            recovery_ref="evidence://recovery", lineage_ref="evidence://lineage",
            attestation_ref="evidence://same")
    except ValueError as e:
        assert str(e)=="V202171_REFERENCE_REUSE_INVALID"
    else:
        raise AssertionError("reference reuse was not rejected")
