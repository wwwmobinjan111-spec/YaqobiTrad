"""v2.02.84 — Evidence Integrity Gate tests."""
from yaqobitrad.audit import AuditLog
from yaqobitrad.evidence_integrity_gate import EvidenceIntegrityGate


def test_v20284_clean_evidence_is_verified_fail_closed():
    audit = AuditLog()
    audit.append("EVIDENCE_CREATED", {"checkpoint": "v2.02.83"})
    decision = EvidenceIntegrityGate(audit).verify()
    assert decision.valid is True
    assert decision.reason == "EVIDENCE_INTEGRITY_VERIFIED"
    assert decision.live_trading == "SAFE_OFF"
    assert decision.activation_gate == "LOCKED"
    assert decision.fail_closed == "ACTIVE"


def test_v20284_tampered_audit_is_rejected():
    audit = AuditLog()
    audit.append("EVIDENCE_CREATED", {"checkpoint": "v2.02.83"})
    gate = EvidenceIntegrityGate(audit)
    audit.entries[0]["data"]["checkpoint"] = "tampered"
    decision = gate.verify()
    assert decision.valid is False
    assert decision.reason == "AUDIT_CHAIN_INVALID"


def test_v20284_evidence_digest_detects_structurally_valid_mutation():
    audit = AuditLog()
    audit.append("EVIDENCE_CREATED", {"checkpoint": "v2.02.83"})
    gate = EvidenceIntegrityGate(audit)
    # Recompute the record hash to simulate an altered but internally consistent ledger.
    audit.entries[0]["data"]["checkpoint"] = "tampered"
    audit.entries[0]["hash"] = audit._digest(audit.entries[0])
    decision = gate.verify()
    assert decision.valid is False
    assert decision.reason == "EVIDENCE_DIGEST_MISMATCH"


def test_v20284_blocker_registry_remains_open_and_exact():
    audit = AuditLog()
    gate = EvidenceIntegrityGate(audit)
    assert gate.intact is True
