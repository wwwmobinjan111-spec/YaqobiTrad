from types import SimpleNamespace
import pytest
from yaqobitrad.v202214_provider_failover_evidence_attestation_durability_reconciliation_checkpoint_continuity_boundary import ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointContinuityBoundaryV214 as V

def s(): return SimpleNamespace(checkpoint="v2.02.214",predecessor="v2.02.213",live_trading="SAFE_OFF",activation_gate="LOCKED",fail_closed="ACTIVE",checkpoint_digest="e"*64)
def test_accept(): assert V.verify(s(),checkpoint_digest="e"*64,integrity_ref="evidence://integrity",continuity_ref="evidence://continuity").valid
def test_digest():
    with pytest.raises(ValueError,match="V202214_CHECKPOINT_DIGEST_MISMATCH"): V.verify(s(),checkpoint_digest="f"*64,integrity_ref="evidence://i",continuity_ref="evidence://c")
def test_lineage():
    x=s(); x.predecessor="v2.02.212"
    with pytest.raises(ValueError,match="V202214_LINEAGE_INVALID"): V.verify(x,checkpoint_digest="e"*64,integrity_ref="evidence://i",continuity_ref="evidence://c")
def test_safety():
    x=s(); x.activation_gate="OPEN"
    with pytest.raises(ValueError,match="V202214_SAFETY_STATE_INVALID"): V.verify(x,checkpoint_digest="e"*64,integrity_ref="evidence://i",continuity_ref="evidence://c")
def test_reuse():
    with pytest.raises(ValueError,match="V202214_REFERENCE_REUSE_INVALID"): V.verify(s(),checkpoint_digest="e"*64,integrity_ref="evidence://x",continuity_ref="evidence://x")
