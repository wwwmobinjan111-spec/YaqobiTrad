from types import SimpleNamespace
import pytest
from yaqobitrad.v202240_production_blocker_major_global_checkpoint import ProductionBlockerMajorGlobalCheckpointV240 as V

def cp(): return SimpleNamespace(valid=True,checkpoint='v2.02.239',predecessor='v2.02.238',live_trading='SAFE_OFF',activation_gate='LOCKED',fail_closed='ACTIVE')
def test_major_checkpoint(): assert V.verify(cp()).major_global_checkpoint
def test_all_six_remain_open(): r=V.verify(cp(),evidence_ids=V.REQUIRED); assert r.open_blocker_count==6 and not r.closure_authorized
def test_bad_lineage():
 with pytest.raises(ValueError,match='V202240_LINEAGE_INVALID'): V.verify(SimpleNamespace(valid=True,checkpoint='x',predecessor='y',live_trading='SAFE_OFF',activation_gate='LOCKED',fail_closed='ACTIVE'))
def test_bad_safety():
 with pytest.raises(ValueError,match='V202240_SAFETY_STATE_INVALID'): V.verify(SimpleNamespace(valid=True,checkpoint='v2.02.239',predecessor='v2.02.238',live_trading='ON',activation_gate='LOCKED',fail_closed='ACTIVE'))
def test_certification_pending(): assert V.verify(cp()).certification=='PENDING_REAL_PRODUCTION_RESULTS'
