from yaqobitrad.account_policy import AccountLimits, AccountPolicy


def limits(**overrides):
    base = dict(
        allowed_symbols=frozenset({"BTC/USDT"}),
        max_deposit_per_transaction=1000.0,
        max_deposit_daily=2000.0,
        max_withdrawal_per_transaction=500.0,
        max_withdrawal_daily=1000.0,
        max_pending_withdrawal=700.0,
    )
    base.update(overrides)
    return AccountLimits(**base)


def valid_live(**kwargs):
    data = dict(
        side="BUY", symbol="BTC/USDT", timeframe="1M", quantity=1,
        price=100, risk_pct=1, stop_loss=95, take_profit=110,
        activation_gate="LOCKED", live_trading=False,
    )
    data.update(kwargs)
    return data


def test_super_admin_cannot_bypass_locked_gate():
    p = AccountPolicy("a1", role="SUPER_ADMIN", trading_mode="LIVE", limits=limits())
    r = p.admit_order(**valid_live(activation_gate="LOCKED", live_trading=True))
    assert r == {"status": "BLOCKED", "reason": "ACTIVATION_GATE_LOCKED"}


def test_admin_cannot_bypass_safe_off():
    p = AccountPolicy("a1", role="ADMIN", trading_mode="LIVE", limits=limits())
    r = p.admit_order(**valid_live(activation_gate="OPEN", live_trading=False))
    assert r == {"status": "BLOCKED", "reason": "LIVE_TRADING_SAFE_OFF"}


def test_paper_order_can_pass_without_live_gate():
    p = AccountPolicy("a1", role="TRADER", trading_mode="PAPER", limits=limits())
    r = p.admit_order(**valid_live())
    assert r["status"] == "APPROVED"
    assert r["mode"] == "PAPER"


def test_account_limits_block_symbol_and_risk():
    p = AccountPolicy("a1", limits=limits(max_risk_per_trade_pct=1.0))
    assert p.admit_order(**valid_live(symbol="ETH/USDT"))["reason"] == "SYMBOL_NOT_ALLOWED"
    assert p.admit_order(**valid_live(risk_pct=2.0))["reason"] == "RISK_PER_TRADE_LIMIT"


def test_deposit_limits():
    p = AccountPolicy("a1", limits=limits())
    assert p.deposit(1000)["status"] == "APPROVED"
    assert p.deposit(1001)["reason"] == "DEPOSIT_TRANSACTION_LIMIT"
    assert p.deposit(1000)["status"] == "APPROVED"
    assert p.deposit(1)["reason"] == "DEPOSIT_DAILY_LIMIT"


def test_withdrawal_limits():
    p = AccountPolicy("a1", limits=limits())
    assert p.withdraw(500, 1000)["status"] == "APPROVED"
    assert p.withdraw(200, 1000)["status"] == "APPROVED"
    assert p.withdraw(1, 1000)["reason"] == "PENDING_WITHDRAWAL_LIMIT"


def test_execution_engine_routes_through_account_policy():
    from yaqobitrad.execution import ExecutionEngine
    from yaqobitrad.risk import RiskEngine
    p = AccountPolicy("a1", role="SUPER_ADMIN", trading_mode="LIVE", limits=limits())
    engine = ExecutionEngine(RiskEngine(), account_policy=p)
    r = engine.submit("BUY", 1, 100, symbol="BTC/USDT", timeframe="1M",
                      risk_pct=1, stop_loss=95, take_profit=110)
    assert r["status"] == "BLOCKED"
    assert r["reason"] == "ACTIVATION_GATE_LOCKED"
