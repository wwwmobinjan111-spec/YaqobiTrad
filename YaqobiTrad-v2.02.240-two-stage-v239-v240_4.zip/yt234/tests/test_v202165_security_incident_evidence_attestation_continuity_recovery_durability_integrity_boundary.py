from yaqobitrad.v202165_security_incident_evidence_attestation_continuity_recovery_durability_integrity_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityIntegrityBoundaryV165

class SafeState:
    activation_gate="LOCKED"
    live_trading="SAFE_OFF"
    fail_closed="ACTIVE"

def test_v202165_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityIntegrityBoundaryV165.verify(SafeState(), state_ref="evidence://state/v164", continuity_ref="evidence://continuity/v164", recovery_ref="evidence://recovery/v164")
    assert r.valid and r.checkpoint=="v2.02.165" and r.predecessor=="v2.02.164" and r.open_blocker_count==6

def test_v202165_rejects_reuse():
    try:
        SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityIntegrityBoundaryV165.verify(SafeState(), state_ref="evidence://same", continuity_ref="evidence://same", recovery_ref="evidence://recovery")
    except ValueError as e:
        assert str(e)=="V202165_REFERENCE_REUSE_INVALID"
    else:
        raise AssertionError("reference reuse was not rejected")
