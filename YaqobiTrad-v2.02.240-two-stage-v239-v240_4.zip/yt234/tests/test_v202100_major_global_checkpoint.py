"""YaqobiTrad v2.02.100 — MAJOR GLOBAL CHECKPOINT."""
import json
import pytest
from yaqobitrad.audit import AuditLog
from yaqobitrad.v202100_major_global_checkpoint import MajorGlobalCheckpoint


def _build(path):
    a=AuditLog(str(path))
    a.append("MONITORING_EVIDENCE_RETRIEVAL_VERIFIED", {"schema_version":"v2.02.94","evidence_digest":"digest-1"}); b=a.entries[-1]
    a.append("MONITORING_EVIDENCE_RETRIEVAL_AUDIT_CONTINUITY_VERIFIED", {"schema_version":"v2.02.95","bound_audit_hash":b["hash"],"evidence_digest":"digest-1"}); c=a.entries[-1]
    a.append("MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED", {"schema_version":"v2.02.99","bound_audit_hash":b["hash"],"evidence_digest":"digest-1","continuity_hash":c["hash"]})
    return a.entries[-1]["hash"], b["hash"]


def test_major_checkpoint_is_deterministic_and_safe(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p); v=MajorGlobalCheckpoint()
    r1=v.verify(str(p), expected_anchor_hash=ah, expected_bound_audit_hash=bh, expected_evidence_digest='digest-1')
    r2=v.verify(str(p), expected_anchor_hash=ah, expected_bound_audit_hash=bh, expected_evidence_digest='digest-1')
    assert r1.valid and r1.chain_digest == r2.chain_digest
    assert (r1.checkpoint,r1.predecessor,r1.open_blocker_count,r1.certification)==('v2.02.100','v2.02.99',6,'PENDING_REAL_PRODUCTION_RESULTS')
    assert (r1.live_trading,r1.activation_gate,r1.fail_closed)==('SAFE_OFF','LOCKED','ACTIVE')


def test_wrong_anchor_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p)
    with pytest.raises(ValueError,match='ANCHOR_HASH_MISMATCH'): MajorGlobalCheckpoint().verify(str(p),expected_anchor_hash='wrong',expected_bound_audit_hash=bh,expected_evidence_digest='digest-1')


def test_wrong_bound_hash_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p)
    with pytest.raises(ValueError,match='BOUND_AUDIT_HASH_MISMATCH'): MajorGlobalCheckpoint().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash='wrong',expected_evidence_digest='digest-1')


def test_wrong_evidence_digest_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p)
    with pytest.raises(ValueError,match='EVIDENCE_DIGEST_MISMATCH'): MajorGlobalCheckpoint().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest='wrong')


def test_duplicate_terminal_attestation_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p); a=AuditLog(str(p)); a.append('MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED',{'schema_version':'v2.02.99','bound_audit_hash':bh,'evidence_digest':'digest-1','continuity_hash':ah})
    with pytest.raises(ValueError,match='TERMINAL_ATTESTATION_INVALID'): MajorGlobalCheckpoint().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest='digest-1')


def test_tamper_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p); x=json.loads(p.read_text()); x['entries'][-1]['data']['evidence_digest']='tampered'; p.write_text(json.dumps(x,sort_keys=True))
    with pytest.raises(ValueError,match='audit ledger integrity failure'): MajorGlobalCheckpoint().verify(str(p),expected_anchor_hash=ah,expected_bound_audit_hash=bh,expected_evidence_digest='digest-1')
