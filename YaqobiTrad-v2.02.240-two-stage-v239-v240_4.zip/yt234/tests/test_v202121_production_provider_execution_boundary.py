import pytest
from yaqobitrad.binance_execution_provider import BinanceExecutionProvider
from yaqobitrad.v202121_production_provider_execution_boundary import ProductionProviderExecutionBoundaryV121 as V

def test_provider_boundary_validates_safe_off_provider():
    r=V.verify(BinanceExecutionProvider("k","s"))
    assert r.valid and r.production_provider_blocker=="OPEN" and r.open_blocker_count==6

def test_provider_boundary_rejects_live_enable_without_authorization():
    with pytest.raises(ValueError,match="LIVE_ENABLE"):
        V.verify(BinanceExecutionProvider("k","s",live_enabled=True,transport=lambda *a: {}))

def test_provider_boundary_preserves_fail_closed_state():
    r=V.verify(BinanceExecutionProvider("k","s"))
    assert (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")
