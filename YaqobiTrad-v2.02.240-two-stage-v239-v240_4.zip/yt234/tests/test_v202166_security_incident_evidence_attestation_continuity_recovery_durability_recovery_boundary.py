from yaqobitrad.v202166_security_incident_evidence_attestation_continuity_recovery_durability_recovery_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryBoundaryV166

class SafeState:
    activation_gate="LOCKED"
    live_trading="SAFE_OFF"
    fail_closed="ACTIVE"

def test_v202166_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryBoundaryV166.verify(SafeState(), state_ref="evidence://state/v165", continuity_ref="evidence://continuity/v165", recovery_ref="evidence://recovery/v165")
    assert r.valid and r.checkpoint=="v2.02.166" and r.predecessor=="v2.02.165" and r.open_blocker_count==6

def test_v202166_rejects_reuse():
    try:
        SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryBoundaryV166.verify(SafeState(), state_ref="evidence://same", continuity_ref="evidence://same", recovery_ref="evidence://recovery")
    except ValueError as e:
        assert str(e)=="V202166_REFERENCE_REUSE_INVALID"
    else:
        raise AssertionError("reference reuse was not rejected")
