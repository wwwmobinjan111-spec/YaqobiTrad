from types import SimpleNamespace
import pytest
from yaqobitrad.v202187_provider_failover_evidence_attestation_continuity import ProviderFailoverEvidenceAttestationContinuityV187

def attestation():
    return SimpleNamespace(valid=True, checkpoint="v2.02.186", predecessor="v2.02.185",
        continuity_digest="b"*64, attestation_digest="c"*64,
        live_trading="SAFE_OFF", activation_gate="LOCKED", fail_closed="ACTIVE")

def test_v202187_carries_attestation_and_preserves_safety():
    r=ProviderFailoverEvidenceAttestationContinuityV187.carry_forward(attestation(), expected_attestation_digest="c"*64)
    assert r.valid and r.checkpoint=="v2.02.187" and r.predecessor=="v2.02.186"
    assert r.attestation_digest=="c"*64 and len(r.continuity_digest)==64
    assert (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")

def test_v202187_continuity_digest_is_deterministic():
    assert ProviderFailoverEvidenceAttestationContinuityV187.carry_forward(attestation()).continuity_digest == ProviderFailoverEvidenceAttestationContinuityV187.carry_forward(attestation()).continuity_digest

def test_v202187_rejects_digest_mismatch():
    with pytest.raises(ValueError, match="V202187_ATTESTATION_DIGEST_MISMATCH"):
        ProviderFailoverEvidenceAttestationContinuityV187.carry_forward(attestation(), expected_attestation_digest="d"*64)

def test_v202187_rejects_lineage_mismatch():
    x=attestation(); x.predecessor="v2.02.184"
    with pytest.raises(ValueError, match="V202187_ATTESTATION_LINEAGE_INVALID"): ProviderFailoverEvidenceAttestationContinuityV187.carry_forward(x)

def test_v202187_rejects_unsafe_state():
    x=attestation(); x.activation_gate="UNLOCKED"
    with pytest.raises(ValueError, match="V202187_SAFETY_STATE_INVALID"): ProviderFailoverEvidenceAttestationContinuityV187.carry_forward(x)
