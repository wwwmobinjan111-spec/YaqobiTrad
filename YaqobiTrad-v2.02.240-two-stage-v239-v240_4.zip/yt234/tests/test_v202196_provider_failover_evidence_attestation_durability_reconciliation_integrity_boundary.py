from types import SimpleNamespace
import pytest
from yaqobitrad.v202196_provider_failover_evidence_attestation_durability_reconciliation_integrity_boundary import ProviderFailoverEvidenceAttestationDurabilityReconciliationIntegrityBoundaryV196

def state(): return SimpleNamespace(activation_gate="LOCKED",live_trading="SAFE_OFF",fail_closed="ACTIVE")
def refs(): return dict(reconciliation_ref="evidence://v202.02.195/reconciliation",integrity_ref="evidence://v202.02.196/integrity",recovery_ref="evidence://v202.02.195/recovery",attestation_ref="evidence://v202.02.196/attestation")
def test_v202196_integrity_boundary():
 r=ProviderFailoverEvidenceAttestationDurabilityReconciliationIntegrityBoundaryV196.verify(state(),**refs()); assert r.valid and r.checkpoint=="v2.02.196" and r.predecessor=="v2.02.195" and r.open_blocker_count==6
def test_v202196_safety_is_fail_closed():
 x=state(); x.activation_gate="OPEN"
 with pytest.raises(ValueError,match="V202196_SAFETY_STATE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationIntegrityBoundaryV196.verify(x,**refs())
def test_v202196_refs_unique():
 r=refs(); r["attestation_ref"]=r["integrity_ref"]
 with pytest.raises(ValueError,match="V202196_REFERENCE_REUSE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationIntegrityBoundaryV196.verify(state(),**r)
def test_v202196_rejects_secret():
 r=refs(); r["recovery_ref"]="evidence://v202.02.196/PRIVATE_KEY"
 with pytest.raises(ValueError,match="V202196_RECOVERY_REF_SECRET_OR_ASSIGNMENT_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationIntegrityBoundaryV196.verify(state(),**r)
def test_v202196_rejects_assignment():
 r=refs(); r["integrity_ref"]="evidence://v202.02.196/integrity=x"
 with pytest.raises(ValueError,match="V202196_INTEGRITY_REF_SECRET_OR_ASSIGNMENT_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationIntegrityBoundaryV196.verify(state(),**r)
