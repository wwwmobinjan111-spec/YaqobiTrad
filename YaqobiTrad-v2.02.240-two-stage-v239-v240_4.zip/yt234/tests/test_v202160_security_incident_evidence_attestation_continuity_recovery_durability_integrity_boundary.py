from dataclasses import dataclass
import pytest
from yaqobitrad.v202160_security_incident_evidence_attestation_continuity_recovery_durability_integrity_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityIntegrityBoundaryV160
@dataclass
class SafeState:
    activation_gate: str="LOCKED"; live_trading: str="SAFE_OFF"; fail_closed: str="ACTIVE"
def test_v202160_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityIntegrityBoundaryV160.verify(SafeState(), state_ref="evidence://state/v159", continuity_ref="evidence://continuity/v159", recovery_ref="evidence://recovery/v159")
    assert r.valid and r.checkpoint=="v2.02.160" and r.predecessor=="v2.02.159" and r.open_blocker_count==6
def test_v202160_rejects_reuse():
    with pytest.raises(ValueError, match="REFERENCE_REUSE_INVALID"):
        SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityIntegrityBoundaryV160.verify(SafeState(), state_ref="evidence://same", continuity_ref="evidence://same", recovery_ref="evidence://recovery")
