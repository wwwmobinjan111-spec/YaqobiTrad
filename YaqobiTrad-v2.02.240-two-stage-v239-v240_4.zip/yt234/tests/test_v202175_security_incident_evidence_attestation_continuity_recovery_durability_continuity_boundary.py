from yaqobitrad.v202175_security_incident_evidence_attestation_continuity_recovery_durability_continuity_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityContinuityBoundaryV175

class SafeState:
    activation_gate="LOCKED"
    live_trading="SAFE_OFF"
    fail_closed="ACTIVE"

def test_v202175_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityContinuityBoundaryV175.verify(SafeState(), state_ref="evidence://state/v174", continuity_ref="evidence://continuity/v174", recovery_ref="evidence://recovery/v174", lineage_ref="evidence://lineage/v174", attestation_ref="evidence://attestation/v174")
    assert r.valid and r.checkpoint=="v2.02.175" and r.predecessor=="v2.02.174" and r.open_blocker_count==6

def test_v202175_rejects_reuse():
    try:
        SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityContinuityBoundaryV175.verify(SafeState(), state_ref="evidence://same", continuity_ref="evidence://continuity", recovery_ref="evidence://recovery", lineage_ref="evidence://lineage", attestation_ref="evidence://same")
    except ValueError as e:
        assert str(e)=="V202175_REFERENCE_REUSE_INVALID"
    else:
        raise AssertionError("reference reuse was not rejected")
