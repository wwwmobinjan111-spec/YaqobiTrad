from yaqobitrad.audit import AuditLog
from yaqobitrad.evidence_retention import RetentionPolicy
from yaqobitrad.evidence_retention_gate import EvidenceRetentionGate


def good_policy():
    return RetentionPolicy(minimum_days=90, immutable=True, remote=True, verified=True)


def test_verified_retention_allows_evidence_release():
    audit = AuditLog()
    gate = EvidenceRetentionGate(audit)
    result = gate.verify(good_policy())
    assert result.valid
    assert result.reason == "RETENTION_VERIFIED"
    assert gate.release_allowed()
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert audit.verify()


def test_unverified_retention_fails_closed():
    audit = AuditLog()
    gate = EvidenceRetentionGate(audit)
    result = gate.verify(RetentionPolicy(90, True, True, False))
    assert not result.valid
    assert result.reason == "RETENTION_POLICY_NOT_VERIFIED"
    assert not gate.release_allowed()
    assert result.fail_closed == "ACTIVE"


def test_tampered_audit_invalidates_retention():
    audit = AuditLog()
    gate = EvidenceRetentionGate(audit)
    assert gate.verify(good_policy()).valid
    audit.entries[0]["data"]["minimum_days"] = 1
    assert not gate.release_allowed()
