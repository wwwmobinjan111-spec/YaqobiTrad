"""v2.02.85 — Evidence Integrity Attestation Gate tests."""
from dataclasses import replace

from yaqobitrad.audit import AuditLog
from yaqobitrad.evidence_integrity_attestation import EvidenceIntegrityAttestationGate


def setup():
    audit = AuditLog()
    audit.append("EVIDENCE_CREATED", {"checkpoint": "v2.02.83"})
    gate = EvidenceIntegrityAttestationGate(audit)
    attestation, result = gate.attest()
    assert result.valid
    assert attestation is not None
    return audit, gate, attestation


def test_v20285_clean_evidence_can_be_attested_and_reverified():
    audit, gate, attestation = setup()
    result = gate.verify(attestation)
    assert result.valid
    assert result.reason == "EVIDENCE_INTEGRITY_ATTESTATION_VERIFIED"
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"
    assert gate.attested
    assert audit.verify()


def test_v20285_tampered_attestation_is_rejected():
    audit, gate, attestation = setup()
    tampered = replace(attestation, blocker_ids=attestation.blocker_ids + ("forged",))
    result = gate.verify(tampered)
    assert not result.valid
    assert result.reason == "ATTESTATION_DIGEST_MISMATCH"
    assert audit.verify()


def test_v20285_evidence_mutation_after_attestation_is_rejected():
    audit, gate, attestation = setup()
    audit.entries[0]["data"]["checkpoint"] = "tampered"
    audit.entries[0]["hash"] = audit._digest(audit.entries[0])
    result = gate.verify(attestation)
    assert not result.valid
    assert result.reason == "EVIDENCE_DIGEST_MISMATCH"


def test_v20285_missing_attestation_fails_closed():
    audit = AuditLog()
    gate = EvidenceIntegrityAttestationGate(audit)
    result = gate.verify()
    assert not result.valid
    assert result.reason == "ATTESTATION_MISSING"
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"
