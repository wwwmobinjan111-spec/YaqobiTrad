from yaqobitrad.v202180_security_incident_evidence_attestation_continuity_recovery_durability_major_global_checkpoint_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityMajorGlobalCheckpointBoundaryV180

class SafeState:
    activation_gate="LOCKED"
    live_trading="SAFE_OFF"
    fail_closed="ACTIVE"

def test_v202180_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityMajorGlobalCheckpointBoundaryV180.verify(SafeState(), state_ref="evidence://state/v179", continuity_ref="evidence://continuity/v179", recovery_ref="evidence://recovery/v179", lineage_ref="evidence://lineage/v179", attestation_ref="evidence://attestation/v179")
    assert r.valid and r.checkpoint=="v2.02.180" and r.predecessor=="v2.02.179" and r.open_blocker_count==6

def test_v202180_rejects_reuse():
    try:
        SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityMajorGlobalCheckpointBoundaryV180.verify(SafeState(), state_ref="evidence://same", continuity_ref="evidence://continuity", recovery_ref="evidence://recovery", lineage_ref="evidence://lineage", attestation_ref="evidence://same")
    except ValueError as e:
        assert str(e)=="V202180_REFERENCE_REUSE_INVALID"
    else:
        raise AssertionError("reference reuse was not rejected")
