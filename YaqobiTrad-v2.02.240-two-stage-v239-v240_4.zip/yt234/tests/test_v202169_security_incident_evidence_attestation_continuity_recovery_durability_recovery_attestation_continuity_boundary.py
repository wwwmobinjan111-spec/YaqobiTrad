from yaqobitrad.v202169_security_incident_evidence_attestation_continuity_recovery_durability_recovery_attestation_continuity_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryAttestationBoundaryV169

class SafeState:
    activation_gate="LOCKED"
    live_trading="SAFE_OFF"
    fail_closed="ACTIVE"

def test_v202169_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryAttestationBoundaryV169.verify(
        SafeState(), state_ref="evidence://state/v167", continuity_ref="evidence://continuity/v167",
        recovery_ref="evidence://recovery/v167", lineage_ref="evidence://lineage/v167",
        attestation_ref="evidence://attestation/v167")
    assert r.valid and r.checkpoint=="v2.02.169" and r.predecessor=="v2.02.168" and r.open_blocker_count==6

def test_v202169_rejects_reuse():
    try:
        SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryAttestationBoundaryV169.verify(
            SafeState(), state_ref="evidence://same", continuity_ref="evidence://continuity",
            recovery_ref="evidence://recovery", lineage_ref="evidence://lineage",
            attestation_ref="evidence://same")
    except ValueError as e:
        assert str(e)=="V202169_REFERENCE_REUSE_INVALID"
    else:
        raise AssertionError("reference reuse was not rejected")
