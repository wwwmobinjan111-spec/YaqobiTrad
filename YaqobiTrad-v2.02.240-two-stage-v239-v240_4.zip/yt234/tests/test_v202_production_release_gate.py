def test_release_requires_approved_blockers():
    blockers = {
        "production_provider_execution": "APPROVED",
        "production_auth_authorization": "APPROVED",
        "production_secret_management": "APPROVED",
        "production_portfolio_persistence": "APPROVED",
        "production_monitoring": "APPROVED",
        "live_provider_e2e": "APPROVED",
    }
    assert len(blockers) == 6
    assert all(v == "APPROVED" for v in blockers.values())

def test_unapproved_blocker_blocks_release():
    blockers = ["APPROVED", "OPEN"]
    release_allowed = all(v == "APPROVED" for v in blockers)
    assert release_allowed is False

def test_release_gate_does_not_unlock_live_trading():
    release_gate = "READY"
    live_trading = "SAFE_OFF"
    activation_gate = "LOCKED"
    fail_closed = "ACTIVE"
    assert release_gate == "READY"
    assert live_trading == "SAFE_OFF"
    assert activation_gate == "LOCKED"
    assert fail_closed == "ACTIVE"
