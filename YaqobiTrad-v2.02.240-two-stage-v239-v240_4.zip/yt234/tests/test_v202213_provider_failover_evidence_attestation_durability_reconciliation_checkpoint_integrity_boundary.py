from types import SimpleNamespace
import pytest
from yaqobitrad.v202213_provider_failover_evidence_attestation_durability_reconciliation_checkpoint_integrity_boundary import ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointIntegrityBoundaryV213 as V

def s(): return SimpleNamespace(checkpoint="v2.02.213",predecessor="v2.02.212",live_trading="SAFE_OFF",activation_gate="LOCKED",fail_closed="ACTIVE",checkpoint_digest="e"*64)
def test_accept(): assert V.verify(s(),checkpoint_digest="e"*64,recovery_ref="evidence://recovery",integrity_ref="evidence://integrity").valid
def test_digest():
    with pytest.raises(ValueError,match="V202213_CHECKPOINT_DIGEST_MISMATCH"): V.verify(s(),checkpoint_digest="f"*64,recovery_ref="evidence://r",integrity_ref="evidence://i")
def test_lineage():
    x=s(); x.predecessor="v2.02.211"
    with pytest.raises(ValueError,match="V202213_LINEAGE_INVALID"): V.verify(x,checkpoint_digest="e"*64,recovery_ref="evidence://r",integrity_ref="evidence://i")
def test_safety():
    x=s(); x.activation_gate="OPEN"
    with pytest.raises(ValueError,match="V202213_SAFETY_STATE_INVALID"): V.verify(x,checkpoint_digest="e"*64,recovery_ref="evidence://r",integrity_ref="evidence://i")
def test_reuse():
    with pytest.raises(ValueError,match="V202213_REFERENCE_REUSE_INVALID"): V.verify(s(),checkpoint_digest="e"*64,recovery_ref="evidence://x",integrity_ref="evidence://x")
