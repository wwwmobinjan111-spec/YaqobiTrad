from types import SimpleNamespace
from yaqobitrad.v202139_key_rotation_revocation_boundary import KeyRotationRevocationBoundaryV139

STATE = SimpleNamespace(activation_gate="LOCKED", live_trading="SAFE_OFF", fail_closed="ACTIVE")

def test_v139_rotation_and_revocation_refs_preserve_safe_state():
    r = KeyRotationRevocationBoundaryV139.verify(
        STATE,
        rotation_ref="vault://yaqobitrad/key-rotation/2026-09",
        revocation_ref="vault://yaqobitrad/key-revocation/2026-09",
    )
    assert r.valid and r.open_blocker_count == 6
    assert r.live_trading == "SAFE_OFF" and r.activation_gate == "LOCKED"

def test_v139_rejects_plaintext_rotation_or_revocation_reference():
    for kwargs in ({"rotation_ref": "API_KEY=plaintext"}, {"revocation_ref": "SECRET=plaintext"}):
        try:
            KeyRotationRevocationBoundaryV139.verify(STATE, **kwargs)
        except ValueError:
            pass
        else:
            raise AssertionError
