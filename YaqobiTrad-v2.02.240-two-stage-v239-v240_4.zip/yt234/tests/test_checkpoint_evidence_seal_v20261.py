from dataclasses import replace

from yaqobitrad.audit import AuditLog
from yaqobitrad.global_checkpoint import global_checkpoint
from yaqobitrad.checkpoint_evidence_seal import CheckpointEvidenceSealer


def test_checkpoint_evidence_seal_and_verify():
    audit = AuditLog()
    sealer = CheckpointEvidenceSealer(audit)
    checkpoint = global_checkpoint()
    seal = sealer.seal(checkpoint)
    assert seal.checkpoint == "v2.02.90"
    assert sealer.verify(checkpoint)
    assert audit.verify()


def test_checkpoint_evidence_tamper_is_rejected():
    audit = AuditLog()
    sealer = CheckpointEvidenceSealer(audit)
    checkpoint = global_checkpoint()
    sealer.seal(checkpoint)
    tampered = replace(checkpoint, open_blocker_count=0)
    assert not sealer.verify(tampered)


def test_sealing_same_checkpoint_is_idempotent():
    audit = AuditLog()
    sealer = CheckpointEvidenceSealer(audit)
    checkpoint = global_checkpoint()
    first = sealer.seal(checkpoint)
    second = sealer.seal(checkpoint)
    assert first == second
    assert len(audit.entries) == 1
