from yaqobitrad.v202125_production_monitoring_boundary import ProductionMonitoringBoundaryV125
class Monitor:
    def record(self,*a,**k): pass
    def health(self): return {"status":"ok"}
    def snapshot(self): return {}
def test_monitoring_boundary_accepts_required_interface():
    r=ProductionMonitoringBoundaryV125.verify(Monitor()); assert r.valid and r.monitoring_blocker=="OPEN"
def test_monitoring_boundary_rejects_invalid_interface():
    try: ProductionMonitoringBoundaryV125.verify(object())
    except ValueError as e: assert str(e)=="V202125_MONITORING_INTERFACE_INVALID"
    else: assert False
def test_monitoring_boundary_preserves_safety():
    r=ProductionMonitoringBoundaryV125.verify(Monitor()); assert (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")
