from yaqobitrad.audit import AuditLog
from yaqobitrad.checkpoint_evidence_seal import CheckpointEvidenceSealer
from yaqobitrad.evidence_release_gate import EvidenceReleaseGate
from yaqobitrad.evidence_retention import RetentionPolicy
from yaqobitrad.evidence_retention_gate import EvidenceRetentionGate
from yaqobitrad.global_checkpoint import global_checkpoint


def good_policy():
    return RetentionPolicy(90, True, True, True)


def setup():
    audit = AuditLog()
    retention = EvidenceRetentionGate(audit)
    assert retention.verify(good_policy()).valid
    sealer = CheckpointEvidenceSealer(audit)
    checkpoint = global_checkpoint()
    sealer.seal(checkpoint)
    return audit, retention, sealer, checkpoint


def test_release_requires_verified_retention_and_checkpoint_seal():
    audit, retention, sealer, checkpoint = setup()
    gate = EvidenceReleaseGate(audit, retention, sealer)
    result = gate.authorize(checkpoint)
    assert result.allowed
    assert result.reason == "EVIDENCE_RELEASE_AUTHORIZED"
    assert gate.authorized
    assert audit.verify()


def test_missing_checkpoint_seal_fails_closed():
    audit = AuditLog()
    retention = EvidenceRetentionGate(audit)
    assert retention.verify(good_policy()).valid
    sealer = CheckpointEvidenceSealer(audit)
    gate = EvidenceReleaseGate(audit, retention, sealer)
    result = gate.authorize(global_checkpoint())
    assert not result.allowed
    assert result.reason == "CHECKPOINT_EVIDENCE_INVALID"
    assert not gate.authorized


def test_audit_tamper_revokes_release_authorization():
    audit, retention, sealer, checkpoint = setup()
    gate = EvidenceReleaseGate(audit, retention, sealer)
    assert gate.authorize(checkpoint).allowed
    audit.entries[0]["data"]["minimum_days"] = 1
    assert not gate.authorized
