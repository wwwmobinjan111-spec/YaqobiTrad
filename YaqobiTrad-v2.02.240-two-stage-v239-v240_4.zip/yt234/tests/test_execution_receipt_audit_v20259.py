from yaqobitrad.audit import AuditLog
from yaqobitrad.provider_execution import PaperExecutionProvider
from yaqobitrad.execution_receipt_audit import ExecutionReceiptAuditBinder


def test_receipt_is_bound_to_audit_chain():
    p = PaperExecutionProvider()
    p.submit("c59", "BUY", 2, 100)
    receipt = p.receipt("c59")
    binder = ExecutionReceiptAuditBinder(AuditLog())
    binding = binder.bind(receipt)
    assert binding.provider_order_id == "PAPER-1"
    assert binder.verify(receipt)


def test_receipt_tampering_invalidates_binding():
    p = PaperExecutionProvider()
    p.submit("c59", "BUY", 2, 100)
    receipt = p.receipt("c59")
    binder = ExecutionReceiptAuditBinder(AuditLog())
    binder.bind(receipt)
    tampered = type(receipt)(receipt.client_order_id, receipt.provider_order_id, receipt.status,
                             "SELL", receipt.quantity, receipt.price)
    assert not binder.verify(tampered)


def test_rebinding_same_receipt_is_idempotent():
    p = PaperExecutionProvider()
    p.submit("c59", "BUY", 2, 100)
    receipt = p.receipt("c59")
    audit = AuditLog()
    binder = ExecutionReceiptAuditBinder(audit)
    a = binder.bind(receipt)
    b = binder.bind(receipt)
    assert a == b
    assert len(audit.entries) == 1
    assert audit.verify()
