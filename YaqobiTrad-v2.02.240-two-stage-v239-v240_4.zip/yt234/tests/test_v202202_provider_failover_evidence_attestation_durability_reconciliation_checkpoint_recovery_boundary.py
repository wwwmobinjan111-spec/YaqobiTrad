from types import SimpleNamespace
import pytest
from yaqobitrad.v202202_provider_failover_evidence_attestation_durability_reconciliation_checkpoint_recovery_boundary import ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointRecoveryBoundaryV202

def state(): return SimpleNamespace(checkpoint="v2.02.202",predecessor="v2.02.201",live_trading="SAFE_OFF",activation_gate="LOCKED",fail_closed="ACTIVE",checkpoint_digest="c"*64)
def test_v202202_accepts_recovery():
 r=ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointRecoveryBoundaryV202.verify(state(),recovery_ref="evidence://v202.02.202/recovery",checkpoint_digest="c"*64); assert r.valid and r.checkpoint=="v2.02.202" and r.predecessor=="v2.02.201"
def test_v202202_rejects_digest_mismatch():
 with pytest.raises(ValueError,match="V202202_CHECKPOINT_DIGEST_MISMATCH"): ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointRecoveryBoundaryV202.verify(state(),recovery_ref="evidence://recovery",checkpoint_digest="d"*64)
def test_v202202_rejects_lineage():
 s=state(); s.predecessor="v2.02.200"
 with pytest.raises(ValueError,match="V202202_LINEAGE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointRecoveryBoundaryV202.verify(s,recovery_ref="evidence://recovery",checkpoint_digest="c"*64)
def test_v202202_rejects_unsafe_state():
 s=state(); s.live_trading="ON"
 with pytest.raises(ValueError,match="V202202_SAFETY_STATE_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointRecoveryBoundaryV202.verify(s,recovery_ref="evidence://recovery",checkpoint_digest="c"*64)
def test_v202202_rejects_secret_ref():
 with pytest.raises(ValueError,match="V202202_RECOVERY_REF_INVALID"): ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointRecoveryBoundaryV202.verify(state(),recovery_ref="evidence://SECRET",checkpoint_digest="c"*64)
