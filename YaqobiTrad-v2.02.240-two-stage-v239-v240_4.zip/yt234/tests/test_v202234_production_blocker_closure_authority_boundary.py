from types import SimpleNamespace
import pytest
from yaqobitrad.v202234_production_blocker_closure_authority_boundary import ProductionBlockerClosureAuthorityBoundaryV234 as V

def cp(): return SimpleNamespace(valid=True,checkpoint='v2.02.233',predecessor='v2.02.232',live_trading='SAFE_OFF',activation_gate='LOCKED',fail_closed='ACTIVE')
def test_v202234_requires_real_evidence_for_closure():
 r=V.verify(cp()); assert r.valid and r.closure_authority=='PRODUCTION_EVIDENCE_REQUIRED' and r.open_blocker_count==6

def test_v202234_does_not_close_without_evidence(): assert V.verify(cp()).open_blocker_count==6

def test_v202234_rejects_fake_closure():
 with pytest.raises(ValueError,match='V202234_REAL_PRODUCTION_EVIDENCE_REQUIRED'): V.verify(cp(),production_evidence=True)

def test_v202234_rejects_lineage():
 x=cp(); x.predecessor='v2.02.231'
 with pytest.raises(ValueError,match='V202234_LINEAGE_INVALID'): V.verify(x)

def test_v202234_preserves_safety():
 r=V.verify(cp()); assert (r.live_trading,r.activation_gate,r.fail_closed)==('SAFE_OFF','LOCKED','ACTIVE')
