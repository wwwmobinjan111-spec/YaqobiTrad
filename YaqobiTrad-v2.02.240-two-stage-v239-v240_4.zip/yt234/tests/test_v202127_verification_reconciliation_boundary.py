from yaqobitrad.v202127_verification_reconciliation_boundary import VerificationReconciliationBoundaryV127
class R:
    def verify(self): pass
    def reconcile(self): pass

def test_reconciliation_boundary_valid():
    assert VerificationReconciliationBoundaryV127.verify(R()).valid

def test_reconciliation_invalid_interface_rejected():
    try: VerificationReconciliationBoundaryV127.verify(object())
    except ValueError as e: assert str(e)=="V202127_RECONCILIATION_INTERFACE_INVALID"
    else: assert False

def test_reconciliation_preserves_fail_closed_state():
    r=VerificationReconciliationBoundaryV127.verify(R())
    assert (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")
