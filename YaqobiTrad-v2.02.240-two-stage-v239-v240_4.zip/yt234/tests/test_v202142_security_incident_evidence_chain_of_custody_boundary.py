from types import SimpleNamespace
from yaqobitrad.v202142_security_incident_evidence_chain_of_custody_boundary import SecurityIncidentEvidenceChainOfCustodyBoundaryV142

STATE = SimpleNamespace(activation_gate="LOCKED", live_trading="SAFE_OFF", fail_closed="ACTIVE")

def test_v142_evidence_and_custody_refs_preserve_safe_state():
    r = SecurityIncidentEvidenceChainOfCustodyBoundaryV142.verify(
        STATE,
        evidence_ref="evidence://security-incident/evidence/2026-09",
        custody_ref="evidence://security-incident/custody/2026-09",
    )
    assert r.valid and r.open_blocker_count == 6
    assert r.live_trading == "SAFE_OFF" and r.activation_gate == "LOCKED"
    assert r.fail_closed == "ACTIVE"

def test_v142_rejects_plaintext_evidence_or_custody_reference():
    for kwargs in ({"evidence_ref": "TOKEN=plaintext"}, {"custody_ref": "SECRET=plaintext"}):
        try:
            SecurityIncidentEvidenceChainOfCustodyBoundaryV142.verify(STATE, **kwargs)
        except ValueError:
            pass
        else:
            raise AssertionError
