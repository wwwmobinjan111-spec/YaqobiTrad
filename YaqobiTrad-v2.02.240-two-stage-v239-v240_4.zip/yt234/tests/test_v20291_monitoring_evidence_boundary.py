"""v2.02.91 — Production monitoring evidence boundary tests."""
import pytest
from yaqobitrad.monitoring import MonitoringState
from yaqobitrad.monitoring_evidence_boundary import MonitoringEvidenceBoundary
from yaqobitrad.production_blockers import open_production_blockers

def setup():
    state = MonitoringState()
    state.heartbeat(100.0)
    return state, MonitoringEvidenceBoundary(state)

def evidence(healthy=True):
    return {"timestamp": 100.0, "healthy": healthy, "heartbeat": 100.0}

def test_v20291_valid_monitoring_evidence():
    state, gate = setup()
    result = gate.verify(evidence(), now=110.0, max_age=30.0)
    assert result.valid
    assert result.reason == "MONITORING_EVIDENCE_BOUNDARY_VERIFIED"
    assert result.live_trading == "SAFE_OFF"
    assert result.activation_gate == "LOCKED"
    assert result.fail_closed == "ACTIVE"

def test_v20291_missing_evidence_fails_closed():
    state, gate = setup()
    with pytest.raises(ValueError, match="MONITORING_EVIDENCE_INVALID"):
        gate.verify({}, now=110.0, max_age=30.0)

def test_v20291_stale_heartbeat_fails_closed():
    state, gate = setup()
    with pytest.raises(ValueError, match="MONITORING_HEARTBEAT_STALE"):
        gate.verify(evidence(), now=140.1, max_age=40.0)

def test_v20291_unhealthy_evidence_fails_closed():
    state, gate = setup()
    with pytest.raises(ValueError, match="MONITORING_UNHEALTHY_FAIL_CLOSED"):
        gate.verify(evidence(False), now=110.0, max_age=30.0)

def test_v20291_preserves_open_production_blockers():
    state, gate = setup()
    before = tuple(b.blocker_id for b in open_production_blockers())
    result = gate.verify(evidence(), now=110.0, max_age=30.0)
    after = tuple(b.blocker_id for b in open_production_blockers())
    assert result.valid
    assert before == after
    assert len(after) == 6
