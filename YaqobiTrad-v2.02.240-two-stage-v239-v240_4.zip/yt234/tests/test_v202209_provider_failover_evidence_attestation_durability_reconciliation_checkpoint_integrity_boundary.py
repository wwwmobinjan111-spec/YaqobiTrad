from types import SimpleNamespace
import pytest
from yaqobitrad.v202209_provider_failover_evidence_attestation_durability_reconciliation_checkpoint_integrity_boundary import ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointIntegrityBoundaryV209 as V

def s(): return SimpleNamespace(checkpoint="v2.02.209",predecessor="v2.02.208",live_trading="SAFE_OFF",activation_gate="LOCKED",fail_closed="ACTIVE",checkpoint_digest="c"*64)
def test_accept(): assert V.verify(s(),checkpoint_digest="c"*64,integrity_ref="evidence://integrity",recovery_ref="evidence://recovery").valid
def test_digest():
 with pytest.raises(ValueError,match="V202209_CHECKPOINT_DIGEST_MISMATCH"): V.verify(s(),checkpoint_digest="d"*64,integrity_ref="evidence://i",recovery_ref="evidence://r")
def test_lineage():
 x=s(); x.checkpoint="v2.02.208"
 with pytest.raises(ValueError,match="V202209_LINEAGE_INVALID"): V.verify(x,checkpoint_digest="c"*64,integrity_ref="evidence://i",recovery_ref="evidence://r")
def test_safety():
 x=s(); x.fail_closed="INACTIVE"
 with pytest.raises(ValueError,match="V202209_SAFETY_STATE_INVALID"): V.verify(x,checkpoint_digest="c"*64,integrity_ref="evidence://i",recovery_ref="evidence://r")
def test_reuse():
 with pytest.raises(ValueError,match="V202209_REFERENCE_REUSE_INVALID"): V.verify(s(),checkpoint_digest="c"*64,integrity_ref="evidence://x",recovery_ref="evidence://x")
