import json
import pytest
from yaqobitrad.audit import AuditLog
from yaqobitrad.monitoring_evidence_audit_continuity_anchor_attestation import MonitoringEvidenceAuditContinuityAnchorAttestation

def _build(path):
    a=AuditLog(str(path)); a.append("MONITORING_EVIDENCE_RETRIEVAL_VERIFIED", {"schema_version":"v2.02.94","evidence_digest":"digest-1"}); b=a.entries[-1]
    a.append("MONITORING_EVIDENCE_RETRIEVAL_AUDIT_CONTINUITY_VERIFIED", {"schema_version":"v2.02.95","bound_audit_hash":b["hash"],"evidence_digest":"digest-1"}); c=a.entries[-1]
    a.append("MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED", {"schema_version":"v2.02.96","bound_audit_hash":b["hash"],"evidence_digest":"digest-1","continuity_hash":c["hash"]}); return a.entries[-1]["hash"],b["hash"]

def test_attestation_is_deterministic_and_read_only(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p); before=p.read_bytes()
    v=MonitoringEvidenceAuditContinuityAnchorAttestation(); r1=v.attest(str(p),expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_anchor_hash=ah); r2=v.attest(str(p),expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_anchor_hash=ah)
    assert r1.valid and r1.attestation_digest==r2.attestation_digest and p.read_bytes()==before
    assert (r1.live_trading,r1.activation_gate,r1.fail_closed)==('SAFE_OFF','LOCKED','ACTIVE')

def test_wrong_bound_hash_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p)
    with pytest.raises(ValueError,match='BOUND_HASH_MISMATCH'): MonitoringEvidenceAuditContinuityAnchorAttestation().attest(str(p),expected_bound_audit_hash='wrong',expected_evidence_digest='digest-1',expected_anchor_hash=ah)

def test_wrong_digest_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p)
    with pytest.raises(ValueError,match='DIGEST_MISMATCH'): MonitoringEvidenceAuditContinuityAnchorAttestation().attest(str(p),expected_bound_audit_hash=bh,expected_evidence_digest='wrong',expected_anchor_hash=ah)

def test_wrong_anchor_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p)
    with pytest.raises(ValueError,match='ANCHOR_HASH_MISMATCH'): MonitoringEvidenceAuditContinuityAnchorAttestation().attest(str(p),expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_anchor_hash='wrong')

def test_duplicate_anchor_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p); a=AuditLog(str(p)); a.append('MONITORING_EVIDENCE_AUDIT_CONTINUITY_ANCHORED',{'schema_version':'v2.02.96','bound_audit_hash':bh,'evidence_digest':'digest-1','continuity_hash':ah})
    with pytest.raises(ValueError,match='ANCHOR_INVALID'): MonitoringEvidenceAuditContinuityAnchorAttestation().attest(str(p),expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_anchor_hash=ah)

def test_tamper_fails_closed(tmp_path):
    p=tmp_path/'a.json'; ah,bh=_build(p); x=json.loads(p.read_text()); x['entries'][-1]['data']['evidence_digest']='tampered'; p.write_text(json.dumps(x,sort_keys=True))
    with pytest.raises(ValueError,match='audit ledger integrity failure'): MonitoringEvidenceAuditContinuityAnchorAttestation().attest(str(p),expected_bound_audit_hash=bh,expected_evidence_digest='digest-1',expected_anchor_hash=ah)
