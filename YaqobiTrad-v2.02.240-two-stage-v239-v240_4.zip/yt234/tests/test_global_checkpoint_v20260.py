from yaqobitrad.global_checkpoint import global_checkpoint, checkpoint_is_fail_closed


def test_v20260_major_checkpoint_covers_current_domains():
    cp = global_checkpoint()
    assert cp.checkpoint == "v2.02.90"
    expected = {
        "source", "architecture", "data", "signal", "strategy", "risk",
        "execution", "portfolio", "audit", "security", "dependencies",
        "evidence_retention", "recovery", "restart", "activation_boundary",
        "execution_receipts",
    }
    assert set(cp.tested_domains) == expected


def test_v20260_major_checkpoint_preserves_open_activation_blockers():
    cp = global_checkpoint()
    assert cp.open_blocker_count == 6
    assert cp.certification == "PENDING_REAL_PRODUCTION_RESULTS"


def test_v20260_major_checkpoint_is_locked_and_safe_off():
    cp = global_checkpoint()
    assert cp.activation_gate == "LOCKED"
    assert cp.fail_closed == "ACTIVE"
    assert cp.live_trading == "SAFE_OFF"


def test_v20260_major_checkpoint_is_fail_closed():
    assert checkpoint_is_fail_closed() is True
