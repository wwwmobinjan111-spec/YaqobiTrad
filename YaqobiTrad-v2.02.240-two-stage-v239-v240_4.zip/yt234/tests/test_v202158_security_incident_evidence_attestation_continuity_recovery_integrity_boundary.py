from dataclasses import dataclass
import pytest
from yaqobitrad.v202158_security_incident_evidence_attestation_continuity_recovery_integrity_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryIntegrityBoundaryV158

@dataclass
class SafeState:
    activation_gate: str = "LOCKED"
    live_trading: str = "SAFE_OFF"
    fail_closed: str = "ACTIVE"

def test_v202158_accepts_three_distinct_refs():
    r = SecurityIncidentEvidenceAttestationContinuityRecoveryIntegrityBoundaryV158.verify(
        SafeState(),
        state_ref="evidence://state/v157",
        continuity_ref="evidence://continuity/v157",
        recovery_ref="evidence://recovery/v157",
    )
    assert r.valid is True
    assert r.checkpoint == "v2.02.158" and r.predecessor == "v2.02.157"
    assert r.open_blocker_count == 6
    assert r.certification == "PENDING_REAL_PRODUCTION_RESULTS"

def test_v202158_rejects_unsafe_state_and_reused_refs():
    with pytest.raises(ValueError, match="SAFETY_STATE_INVALID"):
        SecurityIncidentEvidenceAttestationContinuityRecoveryIntegrityBoundaryV158.verify(
            SafeState(live_trading="ON"),
            state_ref="evidence://state/a",
            continuity_ref="evidence://continuity/b",
            recovery_ref="evidence://recovery/c",
        )
    with pytest.raises(ValueError, match="REFERENCE_REUSE_INVALID"):
        SecurityIncidentEvidenceAttestationContinuityRecoveryIntegrityBoundaryV158.verify(
            SafeState(),
            state_ref="evidence://same",
            continuity_ref="evidence://same",
            recovery_ref="evidence://recovery",
        )
