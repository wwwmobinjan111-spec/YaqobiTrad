from dataclasses import dataclass
import pytest
from yaqobitrad.v202156_security_incident_evidence_attestation_continuity_integrity_boundary import SecurityIncidentEvidenceAttestationContinuityIntegrityBoundaryV156

@dataclass
class SafeState:
    activation_gate: str = "LOCKED"
    live_trading: str = "SAFE_OFF"
    fail_closed: str = "ACTIVE"

def test_v202156_accepts_safe_distinct_refs():
    r = SecurityIncidentEvidenceAttestationContinuityIntegrityBoundaryV156.verify(SafeState(), state_ref="evidence://state/v155", continuity_ref="evidence://continuity/v155")
    assert r.valid is True
    assert r.checkpoint == "v2.02.156" and r.predecessor == "v2.02.155"
    assert r.open_blocker_count == 6 and r.certification == "PENDING_REAL_PRODUCTION_RESULTS"

def test_v202156_rejects_unsafe_state_and_ref_reuse():
    with pytest.raises(ValueError, match="SAFETY_STATE_INVALID"):
        SecurityIncidentEvidenceAttestationContinuityIntegrityBoundaryV156.verify(SafeState(live_trading="ON"), state_ref="evidence://state/a", continuity_ref="evidence://continuity/b")
    with pytest.raises(ValueError, match="REFERENCE_REUSE_INVALID"):
        SecurityIncidentEvidenceAttestationContinuityIntegrityBoundaryV156.verify(SafeState(), state_ref="evidence://same", continuity_ref="evidence://same")
