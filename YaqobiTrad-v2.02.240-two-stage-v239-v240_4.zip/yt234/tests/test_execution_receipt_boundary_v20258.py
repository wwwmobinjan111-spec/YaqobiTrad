from yaqobitrad.provider_execution import PaperExecutionProvider

def test_receipt_matches_committed_order():
    p = PaperExecutionProvider()
    p.submit("c58", "BUY", 1, 100)
    r = p.receipt("c58")
    assert r and r.provider_order_id == "PAPER-1"
    assert p.verify_receipt("c58", "BUY", 1, 100)

def test_receipt_mismatch_fails_closed():
    p = PaperExecutionProvider()
    p.submit("c58", "BUY", 1, 100)
    assert not p.verify_receipt("c58", "SELL", 1, 100)

def test_unknown_receipt_is_not_valid():
    assert PaperExecutionProvider().receipt("missing") is None

def test_replay_preserves_receipt_identity():
    p = PaperExecutionProvider()
    a = p.submit("c58", "BUY", 1, 100)
    b = p.submit("c58", "BUY", 1, 100)
    assert a.provider_order_id == b.provider_order_id
    assert p.verify_receipt("c58", "BUY", 1, 100)
