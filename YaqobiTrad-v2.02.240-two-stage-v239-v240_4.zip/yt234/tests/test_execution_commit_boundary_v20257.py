from yaqobitrad.execution import ExecutionControl


def test_successful_paper_commit_clears_pending_marker():
    c = ExecutionControl()
    r = c.submit_paper("v257-1", "BUY", 1, 100)
    assert r["status"] == "PAPER_FILLED"
    assert c._pending == set()
    assert c.reconcile() is True


def test_pending_marker_blocks_reconciliation():
    c = ExecutionControl()
    c._pending.add("ambiguous-1")
    assert c.reconcile() is False


def test_idempotent_replay_does_not_create_pending_marker():
    c = ExecutionControl()
    first = c.submit_paper("v257-2", "BUY", 1, 100)
    second = c.submit_paper("v257-2", "BUY", 1, 100)
    assert first["status"] == "PAPER_FILLED"
    assert second["status"] == "IDEMPOTENT_REPLAY"
    assert c._pending == set()
    assert c.reconcile() is True
