from types import SimpleNamespace
import pytest
from yaqobitrad.v202222_provider_failover_evidence_attestation_durability_reconciliation_recovery_continuity_boundary import ProviderFailoverEvidenceAttestationDurabilityReconciliationRecoveryContinuityBoundaryV222 as V

def checkpoint():
    return SimpleNamespace(valid=True,checkpoint="v2.02.221",predecessor="v2.02.220",checkpoint_digest="a"*64,integrity_digest="b"*64,recovery_digest="c"*64,live_trading="SAFE_OFF",activation_gate="LOCKED",fail_closed="ACTIVE")

def test_v202222_recovery_continuity_verifies_chain_and_safety():
    r=V.verify(checkpoint())
    assert r.valid and r.checkpoint=="v2.02.222" and r.predecessor=="v2.02.221" and r.open_blocker_count==6 and len(r.continuity_digest)==64 and len(r.checkpoint_digest)==64 and (r.live_trading,r.activation_gate,r.fail_closed)==("SAFE_OFF","LOCKED","ACTIVE")

def test_v202222_recovery_continuity_digest_deterministic():
    a=V.verify(checkpoint()); b=V.verify(checkpoint()); assert a.continuity_digest==b.continuity_digest and a.checkpoint_digest==b.checkpoint_digest

def test_v202222_rejects_predecessor_digest_mismatch():
    with pytest.raises(ValueError,match="V202222_PREDECESSOR_DIGEST_MISMATCH"):
        V.verify(checkpoint(),expected_predecessor_digest="d"*64)

def test_v202222_rejects_lineage_mismatch():
    x=checkpoint(); x.predecessor="v2.02.219"
    with pytest.raises(ValueError,match="V202222_LINEAGE_INVALID"): V.verify(x)

def test_v202222_rejects_unsafe_state():
    x=checkpoint(); x.activation_gate="OPEN"
    with pytest.raises(ValueError,match="V202222_SAFETY_STATE_INVALID"): V.verify(x)
