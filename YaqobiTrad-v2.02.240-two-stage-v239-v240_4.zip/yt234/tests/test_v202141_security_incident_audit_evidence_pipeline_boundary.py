from types import SimpleNamespace
from yaqobitrad.v202141_security_incident_audit_evidence_pipeline_boundary import SecurityIncidentAuditEvidencePipelineBoundaryV141

STATE = SimpleNamespace(activation_gate="LOCKED", live_trading="SAFE_OFF", fail_closed="ACTIVE")

def test_v141_incident_and_audit_evidence_refs_preserve_safe_state():
    r = SecurityIncidentAuditEvidencePipelineBoundaryV141.verify(
        STATE,
        incident_ref="evidence://security-incident/2026-09",
        audit_evidence_ref="evidence://security-audit/2026-09",
    )
    assert r.valid and r.open_blocker_count == 6
    assert r.live_trading == "SAFE_OFF" and r.activation_gate == "LOCKED"
    assert r.fail_closed == "ACTIVE"

def test_v141_rejects_plaintext_incident_or_audit_reference():
    for kwargs in ({"incident_ref": "TOKEN=plaintext"}, {"audit_evidence_ref": "SECRET=plaintext"}):
        try:
            SecurityIncidentAuditEvidencePipelineBoundaryV141.verify(STATE, **kwargs)
        except ValueError:
            pass
        else:
            raise AssertionError
