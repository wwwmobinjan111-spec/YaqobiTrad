from types import SimpleNamespace
import pytest
from yaqobitrad.v202211_provider_failover_evidence_attestation_durability_reconciliation_checkpoint_continuity_boundary import ProviderFailoverEvidenceAttestationDurabilityReconciliationCheckpointContinuityBoundaryV207 as V
def s(): return SimpleNamespace(checkpoint="v2.02.211",predecessor="v2.02.210",live_trading="SAFE_OFF",activation_gate="LOCKED",fail_closed="ACTIVE",checkpoint_digest="c"*64)
def test_accept(): assert V.verify(s(),checkpoint_digest="c"*64,integrity_ref="evidence://integrity",continuity_ref="evidence://continuity").valid
def test_digest():
    with pytest.raises(ValueError,match="V202211_CHECKPOINT_DIGEST_MISMATCH"): V.verify(s(),checkpoint_digest="d"*64,integrity_ref="evidence://i",continuity_ref="evidence://c")
def test_lineage():
    x=s(); x.predecessor="v2.02.205"
    with pytest.raises(ValueError,match="V202211_LINEAGE_INVALID"): V.verify(x,checkpoint_digest="c"*64,integrity_ref="evidence://i",continuity_ref="evidence://c")
def test_safety():
    x=s(); x.activation_gate="OPEN"
    with pytest.raises(ValueError,match="V202211_SAFETY_STATE_INVALID"): V.verify(x,checkpoint_digest="c"*64,integrity_ref="evidence://i",continuity_ref="evidence://c")
def test_reuse():
    with pytest.raises(ValueError,match="V202211_REFERENCE_REUSE_INVALID"): V.verify(s(),checkpoint_digest="c"*64,integrity_ref="evidence://x",continuity_ref="evidence://x")
