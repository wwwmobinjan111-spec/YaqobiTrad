from yaqobitrad.v202176_security_incident_evidence_attestation_continuity_recovery_durability_recovery_boundary import SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryBoundaryV176

class SafeState:
    activation_gate="LOCKED"
    live_trading="SAFE_OFF"
    fail_closed="ACTIVE"

def test_v202176_accepts_distinct_refs():
    r=SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryBoundaryV176.verify(SafeState(), state_ref="evidence://state/v175", continuity_ref="evidence://continuity/v175", recovery_ref="evidence://recovery/v175", lineage_ref="evidence://lineage/v175", attestation_ref="evidence://attestation/v175")
    assert r.valid and r.checkpoint=="v2.02.176" and r.predecessor=="v2.02.175" and r.open_blocker_count==6

def test_v202176_rejects_reuse():
    try:
        SecurityIncidentEvidenceAttestationContinuityRecoveryDurabilityRecoveryBoundaryV176.verify(SafeState(), state_ref="evidence://same", continuity_ref="evidence://continuity", recovery_ref="evidence://recovery", lineage_ref="evidence://lineage", attestation_ref="evidence://same")
    except ValueError as e:
        assert str(e)=="V202176_REFERENCE_REUSE_INVALID"
    else:
        raise AssertionError("reference reuse was not rejected")
