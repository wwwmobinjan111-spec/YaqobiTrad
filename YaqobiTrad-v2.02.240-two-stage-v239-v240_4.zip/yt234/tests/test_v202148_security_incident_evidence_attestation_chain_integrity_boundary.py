from types import SimpleNamespace
from yaqobitrad.v202148_security_incident_evidence_attestation_chain_integrity_boundary import SecurityIncidentEvidenceAttestationChainIntegrityBoundaryV148

STATE = SimpleNamespace(activation_gate="LOCKED", live_trading="SAFE_OFF", fail_closed="ACTIVE")

def test_v148_chain_integrity_preserves_safe_state_and_blockers():
    r = SecurityIncidentEvidenceAttestationChainIntegrityBoundaryV148.verify(
        STATE,
        continuity_ref="evidence://security-incident/attestation-continuity/2026-09",
        integrity_ref="evidence://security-incident/attestation-chain-integrity/2026-09",
    )
    assert r.valid and r.open_blocker_count == 6
    assert r.live_trading == "SAFE_OFF" and r.activation_gate == "LOCKED" and r.fail_closed == "ACTIVE"
    assert r.predecessor == "v2.02.147"

def test_v148_rejects_secret_or_assignment_material():
    for value in ("SECRET=plaintext", "evidence://security-incident/TOKEN/value"):
        try:
            SecurityIncidentEvidenceAttestationChainIntegrityBoundaryV148.verify(
                STATE,
                continuity_ref=value,
                integrity_ref="evidence://security-incident/attestation-chain-integrity/2026-09",
            )
        except ValueError:
            pass
        else:
            raise AssertionError
