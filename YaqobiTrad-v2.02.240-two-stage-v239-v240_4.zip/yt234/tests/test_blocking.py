from yaqobitrad.blocking import activation_blocked, blocking_issues

def test_blocking_inventory_is_nonempty():
    issues = blocking_issues()
    assert issues
    assert any(issue.status == "OPEN" for issue in issues)
    assert any(issue.status == "RESOLVED" for issue in issues)

def test_each_issue_has_required_identity_and_area():
    for issue in blocking_issues():
        assert issue.issue_id.startswith("BLK-")
        assert issue.area
        assert issue.description

def test_activation_remains_blocked_until_open_blockers_are_resolved():
    assert activation_blocked() is True
